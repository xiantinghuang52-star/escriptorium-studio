# OCR, Cloud and Local Capacity Notes
# OCR、云端与本机承载说明

Checked: 2026-11-26. Provider prices change frequently; verify before purchase.

## 1. Umi-OCR integration

Umi-OCR is integrated as an optional local printed-text OCR sidecar. It is MIT
licensed and provides a local HTTP API, normally at:

```text
http://127.0.0.1:1224/api/ocr
```

The API accepts a base64 image and returns text, confidence and four-point
bounding boxes. The v1.9 Printed-text OCR module performs these steps:

1. Add an OCR-backend selector: `eScriptorium/Kraken` or `Umi-OCR`.
2. Add configurable Umi URL and language/model settings.
3. Send a rendered page image to Umi.
4. Match returned text boxes to existing ALTO/PAGE line boxes using IoU or
   center-point distance.
5. Feed matched text into the existing cleanse/translation pipeline.
6. Keep original page, line ID and coordinate information.

Umi is OCR-oriented, not a Kurrent HTR model. It is useful for printed Fraktur,
typescript and clean print, but it is not a substitute for a Kurrent-trained
Kraken model. For handwritten Kurrent, eScriptorium + Kraken remains the primary
engine. Umi-OCR remains an external local program and is not bundled inside the
installer; enable its HTTP service before using the module.

Umi repository: <https://github.com/hiroi-sora/Umi-OCR>

## 2. Cloud deployment

A practical eScriptorium VM:

```text
4–8 vCPU
8–16 GB RAM
80–160 GB SSD
Linux + Docker Compose
```

Approximate monthly compute costs, excluding LLM tokens and domain:

| Tier | Typical cost |
|---|---:|
| 4 vCPU / 8 GB | USD 15–60 |
| 8 vCPU / 16 GB | USD 30–120 |
| Backup/object storage | USD 2–15 |
| GPU training | USD 0.3–1.5+ per hour |

Low-cost providers such as Hetzner are normally at the low end; AWS, Azure and
larger regional providers are at the higher end. Mainland China public hosting
also requires domain/ICP and content-compliance work.

DeepSeek `deepseek-flash` list price is currently CNY 1–2 per million input
tokens and CNY 4–8 per million output tokens, depending on peak/off-peak time.
For a 100-page manuscript, cleansing and page-node translation will generally
cost only a few CNY in tokens, but provider billing should be monitored.

## 3. This computer

Observed on 2026-11-26:

```text
16 logical processors
About 13.8 GB RAM available during inspection
About 295 GB free on C:
Docker/WSL currently resident
eScriptorium homepage responds with HTTP 200
/health is absent in the current image
```

This is adequate for a short-term local pilot or small LAN site with one to three
users. It is not a production-grade public server.

For a temporary public demonstration:

- keep the computer powered and awake;
- use a Cloudflare Tunnel, Tailscale or another authenticated tunnel;
- back up Docker volumes;
- avoid HTR training while users are browsing;
- use Laptop mode (page concurrency 1);
- expect disruption from Windows updates or Docker restarts.

The current machine should not be treated as a permanent 24/7 public website.
