using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace EScriptoriumStudio
{
    internal sealed class AiPythonResult
    {
        public int Status { get; set; }
        public string Text { get; set; }
        public string Content { get; set; }
        public string Error { get; set; }

        public AiPythonResult()
        {
            Text = String.Empty;
            Content = String.Empty;
            Error = String.Empty;
        }
    }

    internal static class AiPythonFallback
    {
        private static readonly object DiscoveryLock = new object();
        private static string _pythonPath;
        private static bool _searched;

        private const string ScriptSource = @"import json
import sys

try:
    import requests
except Exception as exc:
    print(json.dumps({""status"": -2, ""error"": ""requests import failed: "" + str(exc)}, ensure_ascii=False))
    sys.exit(0)

try:
    payload = json.loads(sys.stdin.buffer.read().decode(""utf-8""))
    headers = {""Content-Type"": ""application/json""}
    key = payload.get(""api_key"") or """"
    if key:
        headers[""Authorization""] = ""Bearer "" + key
    response = requests.post(
        payload[""url""],
        headers=headers,
        data=payload[""body""].encode(""utf-8""),
        timeout=180,
    )
    chat_content = """"
    try:
        response_json = response.json()
        choices = response_json.get(""choices"") or []
        if choices:
            message = choices[0].get(""message"") or {}
            chat_content = message.get(""content"") or """"
    except Exception:
        pass
    result = {
        ""status"": response.status_code,
        ""text"": response.text,
        ""content"": chat_content,
        ""error"": """",
    }
except Exception as exc:
    result = {
        ""status"": -3,
        ""text"": """",
        ""content"": """",
        ""error"": type(exc).__name__ + "": "" + str(exc),
    }

print(json.dumps(result, ensure_ascii=False))
";

        public static async Task<AiPythonResult> PostAsync(
            AppSettings settings,
            string bodyJson,
            CancellationToken token)
        {
            string python = FindPython();
            if (String.IsNullOrEmpty(python))
            {
                throw AiErrors.Create(
                    AiErrorCode.PythonFallbackFailed,
                    "No python.exe with requests support was found in PATH or the standard Anaconda/CPython locations.");
            }

            AppPaths.EnsureDirectories();
            string scriptPath = Path.Combine(AppPaths.Root, "ai_https_fallback.py");
            try
            {
                File.WriteAllText(scriptPath, ScriptSource, new UTF8Encoding(false));
            }
            catch (Exception ex)
            {
                throw AiErrors.Create(
                    AiErrorCode.PythonFallbackFailed,
                    "Could not write fallback script: " + scriptPath,
                    ex);
            }

            Dictionary<string, object> input = new Dictionary<string, object>();
            input["url"] = settings.AiEndpoint.Trim();
            input["api_key"] = settings.GetAiApiKey();
            input["body"] = bodyJson;
            string inputJson = new JavaScriptSerializer().Serialize(input);

            string stdout = String.Empty;
            string stderr = String.Empty;
            int exitCode = -1;
            try
            {
                await Task.Run(() =>
                {
                    ProcessStartInfo start = new ProcessStartInfo();
                    start.FileName = python;
                    start.Arguments = "-u \"" + scriptPath + "\"";
                    start.UseShellExecute = false;
                    start.CreateNoWindow = true;
                    start.RedirectStandardInput = true;
                    start.RedirectStandardOutput = true;
                    start.RedirectStandardError = true;
                    start.StandardOutputEncoding = Encoding.UTF8;
                    start.StandardErrorEncoding = Encoding.UTF8;
                    start.EnvironmentVariables["PYTHONIOENCODING"] = "utf-8";

                    using (Process process = new Process())
                    {
                        process.StartInfo = start;
                        process.Start();
                        Task<string> outputTask = process.StandardOutput.ReadToEndAsync();
                        Task<string> errorTask = process.StandardError.ReadToEndAsync();
                        using (StreamWriter writer = new StreamWriter(
                            process.StandardInput.BaseStream,
                            new UTF8Encoding(false)))
                        {
                            writer.Write(inputJson);
                        }

                        DateTime deadline = DateTime.UtcNow.AddMinutes(4);
                        while (!process.HasExited && DateTime.UtcNow < deadline)
                        {
                            if (token.IsCancellationRequested)
                            {
                                try { process.Kill(); } catch { }
                                token.ThrowIfCancellationRequested();
                            }
                            Thread.Sleep(100);
                        }
                        if (!process.HasExited)
                        {
                            try { process.Kill(); } catch { }
                            throw AiErrors.Create(
                                AiErrorCode.RequestTimeout,
                                "Python/OpenSSL fallback did not finish within four minutes.");
                        }
                        process.WaitForExit();
                        stdout = outputTask.Result;
                        stderr = errorTask.Result;
                        exitCode = process.ExitCode;
                    }
                }, token);
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (AiRequestException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw AiErrors.Create(
                    AiErrorCode.PythonFallbackFailed,
                    "Python executable: " + python + "\nScript: " + scriptPath,
                    ex);
            }

            if (exitCode != 0)
            {
                throw AiErrors.Create(
                    AiErrorCode.PythonFallbackFailed,
                    "Python exit code: " + exitCode + "\nSTDOUT:\n" + stdout + "\nSTDERR:\n" + stderr);
            }

            Dictionary<string, object> result;
            try
            {
                result = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(stdout.Trim());
            }
            catch (Exception ex)
            {
                throw AiErrors.Create(
                    AiErrorCode.PythonFallbackFailed,
                    "STDOUT:\n" + stdout + "\nSTDERR:\n" + stderr,
                    ex);
            }

            int status = Convert.ToInt32(result["status"]);
            string text = Convert.ToString(result["text"]);
            string error = result.ContainsKey("error") ? Convert.ToString(result["error"]) : String.Empty;
            if (status < 0)
            {
                throw AiErrors.Create(
                    AiErrorCode.PythonFallbackFailed,
                    error + "\nSTDERR:\n" + stderr);
            }
            if (status < 200 || status >= 300)
                throw AiErrors.FromHttpStatus((HttpStatusCode)status, text);
            return new AiPythonResult
            {
                Status = status,
                Text = text,
                Content = result.ContainsKey("content") ? Convert.ToString(result["content"]) : String.Empty,
                Error = error
            };
        }

        private static string FindPython()
        {
            lock (DiscoveryLock)
            {
                if (_searched)
                    return _pythonPath;
                _searched = true;
                List<string> candidates = new List<string>();
                string profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
                candidates.Add(Path.Combine(profile, "Anaconda3", "python.exe"));
                candidates.Add(Path.Combine(profile, "miniconda3", "python.exe"));
                candidates.Add(Path.Combine(profile, "anaconda3", "python.exe"));
                AddPythonChildren(candidates,
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                        "Programs", "Python"));
                AddPythonChildren(candidates,
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Python"));

                string knownPython = candidates
                    .Where(File.Exists)
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .FirstOrDefault();
                if (!String.IsNullOrEmpty(knownPython))
                {
                    _pythonPath = knownPython;
                    return _pythonPath;
                }

                string path = Environment.GetEnvironmentVariable("PATH") ?? String.Empty;
                foreach (string directory in path.Split(Path.PathSeparator))
                {
                    try
                    {
                        string cleanDirectory = (directory ?? String.Empty).Trim().Trim('"');
                        if (String.IsNullOrWhiteSpace(cleanDirectory) ||
                            cleanDirectory.IndexOf("WindowsApps", StringComparison.OrdinalIgnoreCase) >= 0)
                            continue;
                        candidates.Add(Path.Combine(cleanDirectory, "python.exe"));
                        candidates.Add(Path.Combine(cleanDirectory, "python3.exe"));
                    }
                    catch
                    {
                    }
                }

                _pythonPath = candidates
                    .Where(File.Exists)
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .FirstOrDefault();
                return _pythonPath;
            }
        }

        private static void AddPythonChildren(List<string> candidates, string parent)
        {
            try
            {
                if (!Directory.Exists(parent))
                    return;
                foreach (string directory in Directory.GetDirectories(parent, "Python*"))
                {
                    candidates.Add(Path.Combine(directory, "python.exe"));
                }
            }
            catch
            {
            }
        }
    }
}
