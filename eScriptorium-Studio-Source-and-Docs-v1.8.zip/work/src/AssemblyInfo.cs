using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("eScriptorium Studio")]
[assembly: AssemblyDescription("Bilingual eScriptorium installer and coordinate-aware manuscript workbench")]
[assembly: AssemblyProduct("eScriptorium Studio")]
[assembly: AssemblyCompany("Local Research Tools")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyVersion("1.8.0.0")]
[assembly: AssemblyFileVersion("1.8.0.0")]
[assembly: ComVisible(false)]
