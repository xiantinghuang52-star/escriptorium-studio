using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace EScriptoriumStudio
{
    internal sealed class EscriptoriumModelInfo
    {
        public int Pk { get; set; }
        public string Name { get; set; }
        public string Job { get; set; }

        public override string ToString()
        {
            return Name + "  [#" + Pk + "]";
        }
    }

    internal sealed class EscriptoriumTranscriptionInfo
    {
        public int Pk { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return Name + "  [#" + Pk + "]";
        }
    }

    internal sealed class EscriptoriumApiClient
    {
        private const string BaseUrl = "http://localhost:8080/";
        private static readonly HttpClient Client = CreateClient();
        private readonly AppSettings _settings;
        private string _token;

        public EscriptoriumApiClient(AppSettings settings)
        {
            _settings = settings;
        }

        public static int? DocumentIdFromUrl(string url)
        {
            if (String.IsNullOrWhiteSpace(url))
                return null;
            Match match = Regex.Match(url, @"/document/(\d+)(?:/|$)",
                RegexOptions.IgnoreCase);
            int id;
            if (match.Success && Int32.TryParse(match.Groups[1].Value, out id))
                return id;
            return null;
        }

        public async Task<bool> TestAsync()
        {
            await EnsureTokenAsync().ConfigureAwait(false);
            using (HttpResponseMessage response = await SendAsync(
                HttpMethod.Get, "projects/", null).ConfigureAwait(false))
            {
                return response.IsSuccessStatusCode;
            }
        }

        public async Task<List<EscriptoriumModelInfo>> GetRecognitionModelsAsync()
        {
            await EnsureTokenAsync().ConfigureAwait(false);
            using (HttpResponseMessage response = await SendAsync(
                HttpMethod.Get, "models/?job=2", null).ConfigureAwait(false))
            {
                string content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                EnsureSuccess(response, content);
                List<object> rows = ExtractRows(content);
                return rows.Select(row => row as Dictionary<string, object>)
                    .Where(item => item != null)
                    .Select(item => new EscriptoriumModelInfo
                    {
                        Pk = ToInt(item, "pk"),
                        Name = ToText(item, "name"),
                        Job = ToText(item, "job")
                    })
                    .Where(item => item.Pk > 0)
                    .OrderBy(item => item.Name)
                    .ToList();
            }
        }

        public async Task<EscriptoriumModelInfo> UploadRecognitionModelAsync(
            string filePath,
            string name)
        {
            await EnsureTokenAsync().ConfigureAwait(false);
            using (MultipartFormDataContent form = new MultipartFormDataContent())
            {
                form.Add(new StringContent(name), "name");
                form.Add(new StringContent("2"), "job");
                FileStream stream = File.OpenRead(filePath);
                ByteArrayContent file = new ByteArrayContent(ReadAllBytes(stream));
                stream.Dispose();
                file.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                form.Add(file, "file", Path.GetFileName(filePath));
                using (HttpResponseMessage response = await SendAsync(
                    HttpMethod.Post, "models/", form).ConfigureAwait(false))
                {
                    string content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                    EnsureSuccess(response, content);
                    Dictionary<string, object> item =
                        new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(content);
                    return new EscriptoriumModelInfo
                    {
                        Pk = ToInt(item, "pk"),
                        Name = ToText(item, "name"),
                        Job = ToText(item, "job")
                    };
                }
            }
        }

        public async Task<List<EscriptoriumTranscriptionInfo>> GetTranscriptionsAsync(int documentId)
        {
            await EnsureTokenAsync().ConfigureAwait(false);
            string path = "documents/" + documentId + "/transcriptions/";
            using (HttpResponseMessage response = await SendAsync(
                HttpMethod.Get, path, null).ConfigureAwait(false))
            {
                string content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                EnsureSuccess(response, content);
                List<object> rows = ExtractRows(content);
                return rows.Select(row => row as Dictionary<string, object>)
                    .Where(item => item != null)
                    .Select(item => new EscriptoriumTranscriptionInfo
                    {
                        Pk = ToInt(item, "pk"),
                        Name = ToText(item, "name")
                    })
                    .Where(item => item.Pk > 0)
                    .ToList();
            }
        }

        public async Task SegmentDocumentAsync(
            int documentId,
            string steps,
            bool overrideExisting)
        {
            await EnsureTokenAsync().ConfigureAwait(false);
            Dictionary<string, object> payload = new Dictionary<string, object>();
            payload["steps"] = steps;
            payload["override"] = overrideExisting;
            payload["text_direction"] = "horizontal-lr";
            string json = new JavaScriptSerializer().Serialize(payload);
            using (HttpResponseMessage response = await SendAsync(
                HttpMethod.Post,
                "documents/" + documentId + "/segment/",
                new StringContent(json, Encoding.UTF8, "application/json")).ConfigureAwait(false))
            {
                string content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                EnsureSuccess(response, content);
            }
        }

        public async Task TranscribeDocumentAsync(
            int documentId,
            int transcriptionId,
            int modelId)
        {
            await EnsureTokenAsync().ConfigureAwait(false);
            Dictionary<string, object> payload = new Dictionary<string, object>();
            payload["model"] = modelId;
            payload["transcription"] = transcriptionId;
            string json = new JavaScriptSerializer().Serialize(payload);
            using (HttpResponseMessage response = await SendAsync(
                HttpMethod.Post,
                "documents/" + documentId + "/transcribe/",
                new StringContent(json, Encoding.UTF8, "application/json")).ConfigureAwait(false))
            {
                string content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                EnsureSuccess(response, content);
            }
        }

        private async Task EnsureTokenAsync()
        {
            if (!String.IsNullOrWhiteSpace(_token))
                return;
            Dictionary<string, object> credentials = new Dictionary<string, object>();
            credentials["username"] = _settings.AdminUser;
            credentials["password"] = _settings.GetEscriptoriumPassword();
            string json = new JavaScriptSerializer().Serialize(credentials);
            using (HttpRequestMessage request = new HttpRequestMessage(
                HttpMethod.Post, new Uri(new Uri(BaseUrl), "api/token-auth/")))
            {
                request.Content = new StringContent(json, Encoding.UTF8, "application/json");
                using (HttpResponseMessage response =
                    await Client.SendAsync(request).ConfigureAwait(false))
                {
                    string content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                    EnsureSuccess(response, content);
                    Dictionary<string, object> data =
                        new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(content);
                    _token = ToText(data, "token");
                }
            }
            if (String.IsNullOrWhiteSpace(_token))
                throw new InvalidOperationException(
                    L.T("eScriptorium did not return an API token.",
                        "eScriptorium 未返回 API Token。"));
        }

        private async Task<HttpResponseMessage> SendAsync(
            HttpMethod method,
            string relativePath,
            HttpContent content)
        {
            Uri uri = new Uri(new Uri(BaseUrl), "api/" + relativePath);
            HttpRequestMessage request = new HttpRequestMessage(method, uri);
            request.Headers.Authorization =
                new AuthenticationHeaderValue("Token", _token);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            if (content != null)
                request.Content = content;
            HttpResponseMessage response = await Client.SendAsync(request).ConfigureAwait(false);
            request.Dispose();
            return response;
        }

        private static void EnsureSuccess(HttpResponseMessage response, string content)
        {
            if (response.IsSuccessStatusCode)
                return;
            throw new InvalidOperationException(
                "eScriptorium API " + (int)response.StatusCode + " " +
                response.ReasonPhrase + "\n" + content);
        }

        private static List<object> ExtractRows(string json)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            object root = serializer.DeserializeObject(json);
            object[] direct = root as object[];
            if (direct != null)
                return direct.ToList();
            Dictionary<string, object> dict = root as Dictionary<string, object>;
            if (dict != null)
            {
                object results;
                if (dict.TryGetValue("results", out results))
                {
                    object[] rows = results as object[];
                    if (rows != null)
                        return rows.ToList();
                }
                return new List<object> { dict };
            }
            return new List<object>();
        }

        private static int ToInt(Dictionary<string, object> data, string key)
        {
            object value;
            int parsed;
            if (data != null && data.TryGetValue(key, out value) &&
                value != null && Int32.TryParse(Convert.ToString(value), out parsed))
                return parsed;
            return 0;
        }

        private static string ToText(Dictionary<string, object> data, string key)
        {
            object value;
            if (data != null && data.TryGetValue(key, out value) && value != null)
                return Convert.ToString(value);
            return String.Empty;
        }

        private static byte[] ReadAllBytes(Stream stream)
        {
            using (MemoryStream memory = new MemoryStream())
            {
                stream.CopyTo(memory);
                return memory.ToArray();
            }
        }

        private static HttpClient CreateClient()
        {
            HttpClient client = new HttpClient();
            client.Timeout = TimeSpan.FromMinutes(5);
            client.DefaultRequestHeaders.UserAgent.ParseAdd("eScriptorium-Studio/1.8");
            return client;
        }
    }
}
