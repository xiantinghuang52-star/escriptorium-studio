# Upload to GitHub / 上传到 GitHub

## Before upload / 上传前

1. Confirm the latest package is v1.8:

```powershell
Get-ChildItem .\outputs
```

2. Confirm that no API key, password, dialog log or local runtime setting will be
   committed:

```powershell
git status --short
```

`.gitignore` excludes `settings.json`, `variables.env`, `studio.log`, temporary
diagnostic files and `outputs/垃圾袋-旧版本/`.

## Create the repository / 创建仓库

1. Open <https://github.com/new>.
2. Enter a repository name, for example:

```text
escriptorium-studio
```

3. Choose Public or Private.
4. Do not initialize with another README because this project already contains
   one.
5. Select **Create repository**.

## First upload / 首次上传

Open PowerShell in the project directory:

```powershell
cd "C:\Users\huang\Documents\Codex\2026-11-25\exe-0-escriptorium-docker-localhost-8080"
git init -b main   # already initialized to main; safe to skip or rerun
git add .
git status --short
```

Inspect `git status` before committing. The following should not appear:

```text
settings.json
variables.env
studio.log
work/diag/
outputs/垃圾袋-旧版本/
```

Commit:

```powershell
git config user.name "YOUR NAME"
git config user.email "YOUR EMAIL"
git commit -m "Release eScriptorium Studio v1.8"
```

Connect and push:

```powershell
git remote add origin https://github.com/YOUR_USERNAME/escriptorium-studio.git
git push -u origin main
```

For later changes:

```powershell
git add .
git commit -m "Describe the change"
git push
```

## Recommended release format / 推荐发布方式

It is better to keep source code in the repository and attach the EXE/ZIP to a
GitHub Release.

1. Open the repository page.
2. Select **Releases → Draft a new release**.
3. Tag:

```text
v1.8
```

4. Title:

```text
eScriptorium Studio v1.8
```

5. Attach:

```text
outputs/eScriptorium-Studio-Setup-EN-ZH-v1.8.exe
outputs/eScriptorium-Studio-Bilingual-Windows-v1.8.zip
outputs/SHA256SUMS-v1.8.txt
```

6. Paste the contents of `outputs/RELEASE-NOTES-v1.8-EN-ZH.md`.
7. Select **Publish release**.

## Optional GitHub CLI

GitHub CLI is not installed on this machine. To install it:

```powershell
winget install --id GitHub.cli
gh auth login
```

Then create and push a repository with:

```powershell
gh repo create escriptorium-studio --private --source . --remote origin --push
```

## 上传前检查

- 不要上传 `%LOCALAPPDATA%\eScriptoriumStudio\settings.json`。
- 不要上传 `variables.env`，其中包含数据库和 eScriptorium 密码。
- 不要上传 `studio.log`、API 请求详情或诊断目录。
- `垃圾袋-旧版本` 只作本机备份，默认不进入 Git。
- EXE 未做商业代码签名，GitHub 页面应注明这一点，避免用户误以为是已签名发行版。
