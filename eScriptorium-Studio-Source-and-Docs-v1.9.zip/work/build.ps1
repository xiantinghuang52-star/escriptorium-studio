param(
    [switch]$SkipLaunch,
    [string]$OutputName = "eScriptorium-Studio-Setup-EN-ZH-v1.9.exe"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$project = Split-Path -Parent $root
$src = Join-Path $root "src"
$outDir = Join-Path $project "outputs"
$icon = Join-Path $root "assets\escriptorium-studio.ico"
if ([IO.Path]::GetFileName($OutputName) -ne $OutputName) {
    throw "OutputName must be a file name without a directory."
}
$exe = Join-Path $outDir $OutputName
$webViewRoot = Join-Path $root "third_party\webview2\extracted"
$webViewCore = Join-Path $webViewRoot "lib\net462\Microsoft.Web.WebView2.Core.dll"
$webViewForms = Join-Path $webViewRoot "lib\net462\Microsoft.Web.WebView2.WinForms.dll"
$webViewLoader = Join-Path $webViewRoot "build\native\x64\WebView2Loader.dll"
$csc = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"
$framework = Split-Path -Parent $csc

if (-not (Test-Path -LiteralPath $csc)) {
    throw "The .NET Framework C# compiler was not found: $csc"
}

New-Item -ItemType Directory -Force -Path $outDir | Out-Null

$sources = Get-ChildItem -LiteralPath $src -Filter "*.cs" | Sort-Object Name | ForEach-Object { $_.FullName }
$references = @(
    "System.dll",
    "System.Core.dll",
    "System.Drawing.dll",
    "System.Windows.Forms.dll",
    "System.Web.Extensions.dll",
    "System.Security.dll",
    "System.Net.Http.dll",
    "System.IO.Compression.dll",
    "System.IO.Compression.FileSystem.dll",
    "Microsoft.VisualBasic.dll"
) | ForEach-Object { Join-Path $framework $_ }
$references += @($webViewCore, $webViewForms)

$args = @(
    "/nologo",
    "/target:winexe",
    "/platform:anycpu",
    "/optimize+",
    "/codepage:65001",
    "/win32manifest:$root\app.manifest",
    "/out:$exe"
)

if (Test-Path -LiteralPath $icon) {
    $args += "/win32icon:$icon"
}

$args += $references | ForEach-Object { "/reference:" + $_ }
$args += "/resource:$webViewCore,EScriptoriumStudio.Resources.Microsoft.Web.WebView2.Core.dll"
$args += "/resource:$webViewForms,EScriptoriumStudio.Resources.Microsoft.Web.WebView2.WinForms.dll"
$args += "/resource:$webViewLoader,EScriptoriumStudio.Resources.WebView2Loader.dll"
$args += $sources

& $csc @args
if ($LASTEXITCODE -ne 0) {
    throw "C# compilation failed with exit code $LASTEXITCODE"
}

$hash = Get-FileHash -LiteralPath $exe -Algorithm SHA256
$size = [math]::Round((Get-Item -LiteralPath $exe).Length / 1MB, 2)
Write-Host ("Built {0} ({1} MB)" -f $exe, $size)
Write-Host ("SHA256 {0}" -f $hash.Hash)

if (-not $SkipLaunch) {
    $selfTest = Start-Process -FilePath $exe -ArgumentList "--self-test" -Wait -PassThru
    if ($selfTest.ExitCode -ne 0) {
        throw "Application self-test failed with exit code $($selfTest.ExitCode)"
    }
}
