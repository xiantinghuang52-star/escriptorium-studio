using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace EScriptoriumStudio
{
    internal static class AiErrorCode
    {
        public const string ConfigurationRequired = "AIC001";
        public const string InvalidEndpoint = "AIC002";
        public const string ConnectionFailed = "AIC003";
        public const string WindowsTlsCredentials = "AIC004";
        public const string RequestTimeout = "AIC005";
        public const string Unauthorized = "AIC006";
        public const string Forbidden = "AIC007";
        public const string EndpointOrModelNotFound = "AIC008";
        public const string RateLimitOrQuota = "AIC009";
        public const string HttpError = "AIC010";
        public const string InvalidResponseJson = "AIC011";
        public const string MissingChatChoices = "AIC012";
        public const string LineAlignmentFailed = "AIC013";
        public const string NoInputLines = "AIC014";
        public const string ProviderServerError = "AIC015";
        public const string TlsCertificateError = "AIC016";
        public const string PythonFallbackFailed = "AIC017";
    }

    internal sealed class AiRequestException : Exception
    {
        public string Code { get; private set; }
        public string EnglishExplanation { get; private set; }
        public string ChineseExplanation { get; private set; }
        public string TechnicalDetail { get; private set; }

        public AiRequestException(
            string code,
            string englishExplanation,
            string chineseExplanation,
            string technicalDetail,
            Exception innerException)
            : base(code + " " + englishExplanation + " / " + chineseExplanation, innerException)
        {
            Code = code;
            EnglishExplanation = englishExplanation;
            ChineseExplanation = chineseExplanation;
            TechnicalDetail = technicalDetail ?? String.Empty;
        }

        public string UserMessage
        {
            get
            {
                StringBuilder message = new StringBuilder();
                message.AppendLine("[" + Code + "] " + EnglishExplanation);
                message.AppendLine("中文：" + ChineseExplanation);
                if (!String.IsNullOrWhiteSpace(TechnicalDetail))
                {
                    message.AppendLine();
                    message.AppendLine("Details / 详情:");
                    message.AppendLine(Trim(TechnicalDetail, 1400));
                }
                return message.ToString().Trim();
            }
        }

        private static string Trim(string value, int maximum)
        {
            if (String.IsNullOrEmpty(value) || value.Length <= maximum)
                return value ?? String.Empty;
            return value.Substring(0, maximum) + "…";
        }
    }

    internal static class AiErrors
    {
        public static AiRequestException Create(string code, string detail)
        {
            return Create(code, detail, null);
        }

        public static AiRequestException Create(string code, string detail, Exception inner)
        {
            switch (code)
            {
                case AiErrorCode.ConfigurationRequired:
                    return Make(code,
                        "AI configuration is incomplete. Enter the endpoint, provider model and API key in Settings.",
                        "AI 配置不完整。请在“设置”中填写接口地址、服务商模型和 API Key。",
                        detail, inner);
                case AiErrorCode.InvalidEndpoint:
                    return Make(code,
                        "The AI endpoint is not a valid absolute HTTP/HTTPS URL. Use the complete Chat Completions endpoint.",
                        "AI 接口不是有效的 HTTP/HTTPS 绝对地址。请填写完整的 Chat Completions 接口地址。",
                        detail, inner);
                case AiErrorCode.ConnectionFailed:
                    return Make(code,
                        "The computer could not connect to the AI host. Check DNS, internet access, VPN, firewall and proxy settings.",
                        "电脑无法连接 AI 服务主机。请检查 DNS、网络、VPN、防火墙和代理设置。",
                        detail, inner);
                case AiErrorCode.WindowsTlsCredentials:
                    return Make(code,
                        "Windows TLS could not acquire a client credential. This is a Windows Schannel/session problem, not an API key problem.",
                        "Windows TLS 无法取得客户端凭证。这是 Windows Schannel 或会话环境问题，不是 API Key 错误。",
                        detail, inner);
                case AiErrorCode.RequestTimeout:
                    return Make(code,
                        "The AI request timed out before a response arrived. Check network stability, proxy latency and the provider status.",
                        "AI 请求在收到响应前超时。请检查网络稳定性、代理延迟及服务商状态。",
                        detail, inner);
                case AiErrorCode.Unauthorized:
                    return Make(code,
                        "HTTP 401: the API key is missing, invalid, expired, or issued by a different provider.",
                        "HTTP 401：API Key 缺失、无效、已过期，或并非当前服务商签发。",
                        detail, inner);
                case AiErrorCode.Forbidden:
                    return Make(code,
                        "HTTP 403: the key is not allowed to use this model, project, region or endpoint.",
                        "HTTP 403：该 Key 无权使用此模型、项目、地区或接口。",
                        detail, inner);
                case AiErrorCode.EndpointOrModelNotFound:
                    return Make(code,
                        "HTTP 404: the endpoint path or model name does not exist. Check the full /chat/completions URL and model spelling.",
                        "HTTP 404：接口路径或模型名不存在。请检查完整 /chat/completions 地址和模型拼写。",
                        detail, inner);
                case AiErrorCode.RateLimitOrQuota:
                    return Make(code,
                        "HTTP 429: the provider reports rate limiting, insufficient quota or exhausted balance.",
                        "HTTP 429：服务商返回频率限制、额度不足或余额耗尽。",
                        detail, inner);
                case AiErrorCode.HttpError:
                    return Make(code,
                        "The AI provider returned an unexpected HTTP error.",
                        "AI 服务商返回了未预期的 HTTP 错误。",
                        detail, inner);
                case AiErrorCode.InvalidResponseJson:
                    return Make(code,
                        "The AI response or its message content is not valid line-aligned JSON. Choose a model with reliable JSON output.",
                        "AI 响应或其消息内容不是有效的逐行 JSON。请改用 JSON 输出更稳定的模型。",
                        detail, inner);
                case AiErrorCode.MissingChatChoices:
                    return Make(code,
                        "The response is not OpenAI Chat Completions format: choices/message/content is missing or empty.",
                        "响应不符合 OpenAI Chat Completions 格式：缺少 choices、message 或 content。",
                        detail, inner);
                case AiErrorCode.LineAlignmentFailed:
                    return Make(code,
                        "The AI replied, but none of its line IDs matched the imported manuscript lines.",
                        "AI 已回复，但返回的行号没有任何一项与导入手稿的行号匹配。",
                        detail, inner);
                case AiErrorCode.NoInputLines:
                    return Make(code,
                        "There is no non-empty transcription text to process. Import an ALTO/PAGE file containing recognized text.",
                        "没有可处理的非空转录文字。请导入包含文字识别结果的 ALTO/PAGE 文件。",
                        detail, inner);
                case AiErrorCode.ProviderServerError:
                    return Make(code,
                        "HTTP 5xx: the AI provider service is unavailable or returned an internal error.",
                        "HTTP 5xx：AI 服务商服务不可用或返回内部错误。",
                        detail, inner);
                case AiErrorCode.TlsCertificateError:
                    return Make(code,
                        "HTTPS certificate validation failed. Check system date, proxy interception, VPN and the endpoint certificate.",
                        "HTTPS 证书验证失败。请检查系统日期、代理拦截、VPN 和接口证书。",
                        detail, inner);
                case AiErrorCode.PythonFallbackFailed:
                    return Make(code,
                        "Windows TLS failed and the automatic Python/OpenSSL fallback is unavailable or failed. Install Python with requests, or repair Windows TLS.",
                        "Windows TLS 失败，且自动 Python/OpenSSL 回退不可用或执行失败。请安装包含 requests 的 Python，或修复 Windows TLS。",
                        detail, inner);
                default:
                    return Make(code,
                        "An unexpected AI error occurred.",
                        "发生了未预期的 AI 错误。",
                        detail, inner);
            }
        }

        public static AiRequestException FromHttpStatus(HttpStatusCode status, string responseBody)
        {
            string detail = "HTTP " + (int)status + " " + status + "\n" + Trim(responseBody, 1200);
            int numeric = (int)status;
            if (numeric == 401)
                return Create(AiErrorCode.Unauthorized, detail);
            if (numeric == 403)
                return Create(AiErrorCode.Forbidden, detail);
            if (numeric == 404)
                return Create(AiErrorCode.EndpointOrModelNotFound, detail);
            if (numeric == 429)
                return Create(AiErrorCode.RateLimitOrQuota, detail);
            if (numeric >= 500)
                return Create(AiErrorCode.ProviderServerError, detail);
            return Create(AiErrorCode.HttpError, detail);
        }

        public static AiRequestException FromTransport(Exception exception, string endpoint)
        {
            string all = exception == null ? String.Empty : exception.ToString();
            string detail = "Endpoint: " + endpoint + "\n" + all;
            if (Contains(all, "SEC_E_NO_CREDENTIALS") ||
                Contains(all, "0x8009030E") ||
                Contains(all, "AcquireCredentialsHandle") ||
                Contains(all, "安全包中没有可用的凭证") ||
                Contains(all, "未能创建 SSL/TLS 安全通道") ||
                Contains(all, "Could not create SSL/TLS secure channel") ||
                Contains(all, "SSL/TLS secure channel") ||
                Contains(all, "security package does not have any credentials"))
                return Create(AiErrorCode.WindowsTlsCredentials, detail, exception);
            if (Contains(all, "certificate") ||
                Contains(all, "证书") ||
                Contains(all, "RemoteCertificate") ||
                Contains(all, "Authentication failed"))
                return Create(AiErrorCode.TlsCertificateError, detail, exception);
            return Create(AiErrorCode.ConnectionFailed, detail, exception);
        }

        public static string BilingualReference()
        {
            StringBuilder text = new StringBuilder();
            text.AppendLine();
            text.AppendLine("F. AI ERROR CODES / AI 报错码");
            text.AppendLine("AIC001  Missing endpoint/model/API key. / 缺少接口、模型或 API Key。");
            text.AppendLine("AIC002  Invalid endpoint URL. / 接口 URL 格式无效。");
            text.AppendLine("AIC003  DNS, network, VPN, proxy or firewall connection failure. / DNS、网络、VPN、代理或防火墙连接失败。");
            text.AppendLine("AIC004  Windows TLS/Schannel credential unavailable. / Windows TLS/Schannel 凭证不可用。");
            text.AppendLine("AIC005  Request timeout. / 请求超时。");
            text.AppendLine("AIC006  HTTP 401: invalid or mismatched API key. / HTTP 401：API Key 无效或不匹配。");
            text.AppendLine("AIC007  HTTP 403: model/project/region permission denied. / HTTP 403：模型、项目或地区无权限。");
            text.AppendLine("AIC008  HTTP 404: endpoint path or model not found. / HTTP 404：接口路径或模型不存在。");
            text.AppendLine("AIC009  HTTP 429: rate limit, quota or balance problem. / HTTP 429：限流、额度或余额问题。");
            text.AppendLine("AIC010  Other unexpected HTTP error. / 其他未预期 HTTP 错误。");
            text.AppendLine("AIC011  Invalid JSON in the AI response. / AI 响应 JSON 无效。");
            text.AppendLine("AIC012  Missing choices/message/content in Chat Completions response. / Chat Completions 响应缺少 choices/message/content。");
            text.AppendLine("AIC013  Returned line IDs do not match imported lines. / 返回行号与导入行号不匹配。");
            text.AppendLine("AIC014  No non-empty transcription text to process. / 没有可处理的非空转录文字。");
            text.AppendLine("AIC015  HTTP 5xx provider server error. / HTTP 5xx 服务商服务器错误。");
            text.AppendLine("AIC016  HTTPS certificate validation failed. / HTTPS 证书验证失败。");
            text.AppendLine("AIC017  Windows TLS failed and Python/OpenSSL fallback failed. / Windows TLS 失败且 Python/OpenSSL 回退失败。");
            return text.ToString();
        }

        private static AiRequestException Make(
            string code,
            string english,
            string chinese,
            string detail,
            Exception inner)
        {
            return new AiRequestException(code, english, chinese, detail, inner);
        }

        private static bool Contains(string value, string token)
        {
            return !String.IsNullOrEmpty(value) &&
                value.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static string Trim(string value, int maximum)
        {
            if (String.IsNullOrEmpty(value) || value.Length <= maximum)
                return value ?? String.Empty;
            return value.Substring(0, maximum) + "…";
        }
    }
}
