using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace EScriptoriumStudio
{
    internal static class DependencyInstaller
    {
        public const string UmiDownloadUrl =
            "https://github.com/hiroi-sora/Umi-OCR/releases/download/v2.1.5/Umi-OCR_Rapid_v2.1.5.7z.exe";
        public const string UmiSha256 =
            "659C55896C32A5E019DC7BDE1713D0E5C73186A2C653BED84C4480FA1795B722";
        public const string TesseractDownloadUrl =
            "https://github.com/tesseract-ocr/tesseract/releases/download/5.5.3/tesseract-ocr-w64-setup-5.5.3.20260724.exe";
        public const string TesseractSha256 =
            "BEE9E3434BD94FD65387D9BE28CD467A41F61B1275383B55B0F59A1331270AE4";

        private static readonly HttpClient Client = CreateClient();

        public static async Task<string> InstallUmiAsync(
            Action<string> progress,
            CancellationToken cancellationToken)
        {
            string existing = PrintedOcrClient.FindUmiOcr();
            if (!String.IsNullOrWhiteSpace(existing))
            {
                progress(L.T("Umi-OCR is already installed: ", "Umi-OCR 已安装：") + existing);
                return existing;
            }

            string download = Path.Combine(
                AppPaths.DownloadsDirectory, "Umi-OCR_Rapid_v2.1.5.7z.exe");
            await DownloadVerifiedAsync(
                UmiDownloadUrl,
                download,
                UmiSha256,
                progress,
                cancellationToken);

            string tools = Path.Combine(AppPaths.Root, "Tools");
            string installRoot = Path.Combine(tools, "Umi-OCR-Rapid-v2.1.5");
            Directory.CreateDirectory(installRoot);
            progress(L.T("Extracting Umi-OCR Rapid...", "正在解压 Umi-OCR Rapid..."));
            ProcessStartInfo extract = new ProcessStartInfo
            {
                FileName = download,
                Arguments = "-y -o\"" + installRoot + "\"",
                WorkingDirectory = installRoot,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };
            using (Process process = Process.Start(extract))
            {
                if (process == null)
                    throw new InvalidOperationException("Could not start the Umi-OCR installer.");
                Task<string> output = process.StandardOutput.ReadToEndAsync();
                Task<string> error = process.StandardError.ReadToEndAsync();
                while (!process.HasExited)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    await Task.Delay(100, cancellationToken);
                }
                string details = (await output) + Environment.NewLine + (await error);
                string executable = FindFileRecursive(installRoot, "Umi-OCR.exe");
                if (String.IsNullOrWhiteSpace(executable))
                    throw new InvalidOperationException(
                        L.T(
                            "Umi-OCR extraction completed but Umi-OCR.exe was not found. " +
                            "Run the downloaded installer and extract it to: ",
                            "Umi-OCR 解压完成，但未找到 Umi-OCR.exe。请运行已下载安装包并解压到：") +
                        installRoot + Environment.NewLine + details.Trim());
                progress(L.T("Umi-OCR installed: ", "Umi-OCR 已安装：") + executable);
                return executable;
            }
        }

        public static async Task<string> InstallTesseractAsync(
            IEnumerable<string> languages,
            Action<string> progress,
            CancellationToken cancellationToken)
        {
            string existing = PrintedOcrClient.FindTesseract();
            string executable = existing;
            if (String.IsNullOrWhiteSpace(existing))
            {
                string download = Path.Combine(
                    AppPaths.DownloadsDirectory, "tesseract-ocr-w64-setup-5.5.3.20260724.exe");
                await DownloadVerifiedAsync(
                    TesseractDownloadUrl,
                    download,
                    TesseractSha256,
                    progress,
                    cancellationToken);

                string target = Path.Combine(
                    AppPaths.Root, "Tools", "Tesseract-OCR");
                Directory.CreateDirectory(target);
                progress(L.T("Installing Tesseract 5.5.3...", "正在安装 Tesseract 5.5.3..."));
                ProcessStartInfo install = new ProcessStartInfo
                {
                    FileName = download,
                    Arguments = "/S /D=" + target,
                    WorkingDirectory = AppPaths.DownloadsDirectory,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };
                using (Process process = Process.Start(install))
                {
                    if (process == null)
                        throw new InvalidOperationException("Could not start the Tesseract installer.");
                    while (!process.HasExited)
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        await Task.Delay(120, cancellationToken);
                    }
                    if (process.ExitCode != 0)
                        throw new InvalidOperationException(
                            "Tesseract installer exited with code " +
                            process.ExitCode.ToString(CultureInfo.InvariantCulture));
                }
                executable = FindFileRecursive(target, "tesseract.exe");
                if (String.IsNullOrWhiteSpace(executable))
                    executable = PrintedOcrClient.FindTesseract();
                if (String.IsNullOrWhiteSpace(executable))
                    throw new InvalidOperationException(
                        L.T(
                            "Tesseract installation did not produce tesseract.exe.",
                            "Tesseract 安装后未找到 tesseract.exe。"));
            }

            string tessdata = Path.Combine(Path.GetDirectoryName(executable), "tessdata");
            Directory.CreateDirectory(tessdata);
            List<string> requested = (languages ?? new string[0])
                .SelectMany(value => (value ?? String.Empty).Split(new[] { ',', ';', ' ' },
                    StringSplitOptions.RemoveEmptyEntries))
                .Select(value => Regex.Replace(value.Trim(), "[^A-Za-z0-9_]", String.Empty))
                .Where(value => value.Length > 0)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
            if (requested.Count == 0)
                requested.Add("eng");
            foreach (string language in requested)
            {
                string targetFile = Path.Combine(tessdata, language + ".traineddata");
                if (File.Exists(targetFile) && new FileInfo(targetFile).Length > 100000)
                    continue;
                progress(L.T("Downloading Tesseract language data: ",
                    "正在下载 Tesseract 语言数据：") + language);
                string temporary = targetFile + ".download";
                await DownloadFileAsync(
                    "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/" +
                    language + ".traineddata",
                    temporary,
                    null,
                    cancellationToken);
                if (!File.Exists(temporary) || new FileInfo(temporary).Length < 100000)
                    throw new InvalidOperationException(
                        "Tesseract language download failed: " + language);
                if (File.Exists(targetFile))
                    File.Delete(targetFile);
                File.Move(temporary, targetFile);
            }
            progress(L.T("Tesseract installed: ", "Tesseract 已安装：") + executable);
            return executable;
        }

        private static async Task DownloadVerifiedAsync(
            string url,
            string destination,
            string expectedSha256,
            Action<string> progress,
            CancellationToken cancellationToken)
        {
            if (!File.Exists(destination) ||
                !String.Equals(Sha256(destination), expectedSha256,
                    StringComparison.OrdinalIgnoreCase))
            {
                await DownloadFileAsync(url, destination, progress, cancellationToken);
            }
            string actual = Sha256(destination);
            if (!String.Equals(actual, expectedSha256, StringComparison.OrdinalIgnoreCase))
            {
                try { File.Delete(destination); }
                catch { }
                throw new InvalidOperationException(
                    "Downloaded file SHA-256 mismatch. Expected " + expectedSha256 +
                    ", actual " + actual + ".");
            }
            progress(L.T("SHA-256 verified: ", "SHA-256 已验证：") +
                Path.GetFileName(destination));
        }

        private static async Task DownloadFileAsync(
            string url,
            string destination,
            Action<string> progress,
            CancellationToken cancellationToken)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(destination));
            string temporary = destination + ".part";
            try
            {
                Exception httpError = null;
                Exception pythonError = null;
                try
                {
                    await DownloadWithHttpClientAsync(
                        url, temporary, destination, progress, cancellationToken);
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception first)
                {
                    httpError = first;
                    if (File.Exists(temporary))
                    {
                        try { File.Delete(temporary); }
                        catch { }
                    }
                    progress(L.T(
                        "Windows HTTPS failed; retrying with Python/OpenSSL...",
                        "Windows HTTPS 失败，正在使用 Python/OpenSSL 重试..."));
                }

                if (httpError != null)
                {
                    try
                    {
                        await DownloadWithPythonAsync(
                            url, temporary, cancellationToken);
                    }
                    catch (Exception second)
                    {
                        pythonError = second;
                        if (File.Exists(temporary))
                        {
                            try { File.Delete(temporary); }
                            catch { }
                        }
                        progress(L.T(
                            "Python/OpenSSL failed; retrying with curl.exe...",
                            "Python/OpenSSL 失败，正在使用 curl.exe 重试..."));
                    }
                }
                if (pythonError != null)
                {
                    await DownloadWithCurlAsync(
                        url, temporary, cancellationToken);
                    if (!File.Exists(temporary))
                        throw new InvalidOperationException(
                            "All download fallbacks failed. HttpClient: " +
                            httpError.Message + " Python/OpenSSL: " + pythonError.Message);
                }
                if (File.Exists(destination))
                    File.Delete(destination);
                File.Move(temporary, destination);
            }
            finally
            {
                if (File.Exists(temporary))
                {
                    try { File.Delete(temporary); }
                    catch { }
                }
            }
        }

        private static async Task DownloadWithHttpClientAsync(
            string url,
            string temporary,
            string destination,
            Action<string> progress,
            CancellationToken cancellationToken)
        {
            using (HttpResponseMessage response = await Client.GetAsync(
                url, HttpCompletionOption.ResponseHeadersRead, cancellationToken))
            {
                response.EnsureSuccessStatusCode();
                long total = response.Content.Headers.ContentLength ?? -1;
                using (Stream input = await response.Content.ReadAsStreamAsync())
                using (FileStream output = new FileStream(
                    temporary, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    byte[] buffer = new byte[1024 * 128];
                    long received = 0;
                    int lastPercent = -1;
                    while (true)
                    {
                        int count = await input.ReadAsync(
                            buffer, 0, buffer.Length, cancellationToken);
                        if (count <= 0)
                            break;
                        await output.WriteAsync(buffer, 0, count, cancellationToken);
                        received += count;
                        if (total > 0)
                        {
                            int percent = (int)Math.Min(100,
                                received * 100L / total);
                            if (percent != lastPercent &&
                                (percent == 100 || percent - lastPercent >= 2))
                            {
                                lastPercent = percent;
                                progress(String.Format(
                                    L.T("Downloading {0}: {1}% ({2:0.0} / {3:0.0} MB)",
                                        "正在下载 {0}：{1}%（{2:0.0} / {3:0.0} MB）"),
                                    Path.GetFileName(destination), percent,
                                    received / 1048576.0, total / 1048576.0));
                            }
                        }
                    }
                }
            }
        }

        private static async Task DownloadWithPythonAsync(
            string url,
            string temporary,
            CancellationToken cancellationToken)
        {
            string python = AiPythonFallback.FindPython();
            if (String.IsNullOrWhiteSpace(python))
                throw new InvalidOperationException("No Python/OpenSSL runtime was found.");

            const string script = @"import json, sys
try:
    import requests
    payload = json.loads(sys.stdin.buffer.read().decode('utf-8'))
    with requests.get(payload['url'], stream=True, timeout=(30, 1800)) as response:
        response.raise_for_status()
        with open(payload['path'], 'wb') as output:
            for chunk in response.iter_content(131072):
                if chunk:
                    output.write(chunk)
    print('OK')
except Exception as exc:
    print(type(exc).__name__ + ': ' + str(exc), file=sys.stderr)
    sys.exit(2)
";
            string scriptPath = Path.Combine(AppPaths.Root, "download_https_fallback.py");
            File.WriteAllText(scriptPath, script, new UTF8Encoding(false));
            string input = new System.Web.Script.Serialization.JavaScriptSerializer()
                .Serialize(new Dictionary<string, object>
                {
                    { "url", url },
                    { "path", temporary }
                });

            ProcessStartInfo start = new ProcessStartInfo
            {
                FileName = python,
                Arguments = "-u \"" + scriptPath + "\"",
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8
            };
            using (Process process = new Process { StartInfo = start })
            {
                if (!process.Start())
                    throw new InvalidOperationException("Could not start Python download fallback.");
                Task<string> stdout = process.StandardOutput.ReadToEndAsync();
                Task<string> stderr = process.StandardError.ReadToEndAsync();
                using (StreamWriter writer = new StreamWriter(
                    process.StandardInput.BaseStream, new UTF8Encoding(false)))
                    await writer.WriteAsync(input);
                while (!process.HasExited)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    await Task.Delay(120, cancellationToken);
                }
                string output = await stdout;
                string error = await stderr;
                if (process.ExitCode != 0)
                    throw new InvalidOperationException(
                        "Python download failed: " + error.Trim());
            }
        }

        private static async Task DownloadWithCurlAsync(
            string url,
            string temporary,
            CancellationToken cancellationToken)
        {
            ProcessStartInfo start = new ProcessStartInfo
            {
                FileName = "curl.exe",
                Arguments = "-L --fail --retry 3 --connect-timeout 30 --output \"" +
                    temporary.Replace("\"", String.Empty) + "\" \"" +
                    url.Replace("\"", String.Empty) + "\"",
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };
            using (Process process = new Process { StartInfo = start })
            {
                if (!process.Start())
                    throw new InvalidOperationException("Could not start curl.exe.");
                Task<string> stdout = process.StandardOutput.ReadToEndAsync();
                Task<string> stderr = process.StandardError.ReadToEndAsync();
                while (!process.HasExited)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    await Task.Delay(120, cancellationToken);
                }
                string error = (await stderr).Trim();
                if (process.ExitCode != 0)
                    throw new InvalidOperationException(
                        "curl.exe download failed: " + error);
            }
        }

        private static string Sha256(string path)
        {
            using (SHA256 sha = SHA256.Create())
            using (FileStream stream = File.OpenRead(path))
                return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", String.Empty);
        }

        private static string FindFileRecursive(string root, string fileName)
        {
            if (String.IsNullOrWhiteSpace(root) || !Directory.Exists(root))
                return String.Empty;
            try
            {
                return Directory.GetFiles(root, fileName, SearchOption.AllDirectories)
                    .FirstOrDefault();
            }
            catch
            {
                return String.Empty;
            }
        }

        private static HttpClient CreateClient()
        {
            HttpClient client = new HttpClient();
            client.Timeout = TimeSpan.FromMinutes(30);
            client.DefaultRequestHeaders.UserAgent.ParseAdd("eScriptorium-Studio/1.9");
            return client;
        }
    }
}
