using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Xml;

namespace EScriptoriumStudio
{
    internal static class DocumentParser
    {
        public static List<TranscriptionLine> ReadFiles(IEnumerable<string> paths)
        {
            List<TranscriptionLine> all = new List<TranscriptionLine>();
            int pageOffset = 0;
            foreach (string path in paths)
            {
                List<TranscriptionLine> fileLines = ReadFile(path);
                if (fileLines.Count > 0)
                {
                    int minimumPage = fileLines.Min(line => line.Page);
                    int maximumPage = fileLines.Max(line => line.Page);
                    foreach (TranscriptionLine line in fileLines)
                        line.Page = pageOffset + Math.Max(1, line.Page - minimumPage + 1);
                    pageOffset += Math.Max(1, maximumPage - minimumPage + 1);
                }
                all.AddRange(fileLines);
            }
            for (int index = 0; index < all.Count; index++)
                all[index].Id = index + 1;
            return all;
        }

        public static List<TranscriptionLine> ReadFile(string path)
        {
            string extension = Path.GetExtension(path).ToLowerInvariant();
            if (extension == ".alto" || extension == ".xml" || extension == ".pagexml")
            {
                string head = ReadHead(path, 2048);
                if (head.IndexOf("PcGts", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    extension == ".pagexml")
                    return ParsePageXml(path);
                return ParseAlto(path);
            }
            if (extension == ".json")
                return ParseStudioJson(path);
            return ParseText(path);
        }

        private static string ReadHead(string path, int maxCharacters)
        {
            using (StreamReader reader = new StreamReader(path, Encoding.UTF8, true))
            {
                char[] buffer = new char[maxCharacters];
                int count = reader.Read(buffer, 0, buffer.Length);
                return new string(buffer, 0, count);
            }
        }

        private static List<TranscriptionLine> ParseAlto(string path)
        {
            XmlDocument doc = LoadXml(path);
            List<TranscriptionLine> lines = new List<TranscriptionLine>();
            int order = 0;
            int pageNumber = 0;
            XmlNodeList pages = doc.SelectNodes("//*[local-name()='Page']");
            foreach (XmlNode page in pages)
            {
                pageNumber++;
                XmlNodeList nodes = page.SelectNodes(".//*[local-name()='TextLine']");
                foreach (XmlNode node in nodes)
                {
                    string text = String.Join(" ", node.SelectNodes(".//*[local-name()='String']")
                        .Cast<XmlNode>()
                        .Select(item => Attribute(item, "CONTENT"))
                        .Where(value => !String.IsNullOrWhiteSpace(value)));
                    if (String.IsNullOrWhiteSpace(text))
                    {
                        text = String.Join(" ", node.SelectNodes(".//*[local-name()='Unicode']")
                            .Cast<XmlNode>()
                            .Select(item => item.InnerText)
                            .Where(value => !String.IsNullOrWhiteSpace(value)));
                    }
                    if (String.IsNullOrWhiteSpace(text))
                        continue;

                    TranscriptionLine line = new TranscriptionLine();
                    line.SourceFile = Path.GetFileName(path);
                    line.Page = pageNumber;
                    line.Order = ++order;
                    line.Original = NormalizeXmlText(text);
                    line.Status = L.T("Imported", "已导入");
                    line.X = NumberAttribute(node, "HPOS");
                    line.Y = NumberAttribute(node, "VPOS");
                    line.Width = NumberAttribute(node, "WIDTH");
                    line.Height = NumberAttribute(node, "HEIGHT");
                    line.HasCoordinates = line.Width > 0 && line.Height > 0;
                    if (!line.HasCoordinates)
                    {
                        line.X = NumberAttribute(node, "hpos");
                        line.Y = NumberAttribute(node, "vpos");
                        line.Width = NumberAttribute(node, "width");
                        line.Height = NumberAttribute(node, "height");
                        line.HasCoordinates = line.Width > 0 && line.Height > 0;
                    }
                    lines.Add(line);
                }
            }

            if (lines.Count == 0)
            {
                XmlNodeList strings = doc.SelectNodes("//*[local-name()='String']");
                foreach (XmlNode node in strings)
                {
                    string text = Attribute(node, "CONTENT");
                    if (String.IsNullOrWhiteSpace(text))
                        continue;
                    TranscriptionLine line = new TranscriptionLine();
                    line.SourceFile = Path.GetFileName(path);
                    line.Page = 1;
                    line.Order = ++order;
                    line.Original = text.Trim();
                    line.Status = L.T("Imported", "已导入");
                    line.X = NumberAttribute(node, "HPOS");
                    line.Y = NumberAttribute(node, "VPOS");
                    line.Width = NumberAttribute(node, "WIDTH");
                    line.Height = NumberAttribute(node, "HEIGHT");
                    line.HasCoordinates = line.Width > 0 && line.Height > 0;
                    lines.Add(line);
                }
            }
            return lines;
        }

        private static List<TranscriptionLine> ParsePageXml(string path)
        {
            XmlDocument doc = LoadXml(path);
            XmlNodeList pages = doc.SelectNodes("//*[local-name()='Page']");
            List<TranscriptionLine> lines = new List<TranscriptionLine>();
            int order = 0;
            int pageNumber = 0;
            foreach (XmlNode page in pages)
            {
                pageNumber++;
                XmlNodeList nodes = page.SelectNodes(".//*[local-name()='TextLine']");
                foreach (XmlNode node in nodes)
                {
                    string text = String.Join(" ", node.SelectNodes(".//*[local-name()='Unicode']")
                        .Cast<XmlNode>()
                        .Select(item => item.InnerText)
                        .Where(value => !String.IsNullOrWhiteSpace(value)));
                    if (String.IsNullOrWhiteSpace(text))
                        continue;

                    TranscriptionLine line = new TranscriptionLine();
                    line.SourceFile = Path.GetFileName(path);
                    line.Page = pageNumber;
                    line.Order = ++order;
                    line.Original = NormalizeXmlText(text);
                    line.Status = L.T("Imported", "已导入");

                    XmlNode coords = node.SelectSingleNode(".//*[local-name()='Coords']");
                    if (coords != null)
                        ApplyPoints(line, Attribute(coords, "points"));
                    lines.Add(line);
                }
            }
            return lines;
        }

        private static List<TranscriptionLine> ParseText(string path)
        {
            string text = File.ReadAllText(path, DetectEncoding(path));
            string[] pieces = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            List<TranscriptionLine> lines = new List<TranscriptionLine>();
            int order = 0;
            foreach (string piece in pieces)
            {
                string value = piece.Trim();
                if (value.Length == 0)
                    continue;
                TranscriptionLine line = new TranscriptionLine();
                line.SourceFile = Path.GetFileName(path);
                line.Page = 1;
                line.Order = ++order;
                line.Original = value;
                line.Status = L.T("No coordinates", "无坐标");
                lines.Add(line);
            }
            return lines;
        }

        private static List<TranscriptionLine> ParseStudioJson(string path)
        {
            try
            {
                string json = File.ReadAllText(path, Encoding.UTF8);
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                List<TranscriptionLine> lines = serializer.Deserialize<List<TranscriptionLine>>(json);
                if (lines == null)
                    return new List<TranscriptionLine>();
                return lines;
            }
            catch
            {
                return ParseText(path);
            }
        }

        private static Encoding DetectEncoding(string path)
        {
            using (StreamReader reader = new StreamReader(path, Encoding.UTF8, true))
            {
                reader.Peek();
                return reader.CurrentEncoding;
            }
        }

        private static XmlDocument LoadXml(string path)
        {
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.DtdProcessing = DtdProcessing.Prohibit;
            settings.XmlResolver = null;
            XmlDocument doc = new XmlDocument();
            using (XmlReader reader = XmlReader.Create(path, settings))
                doc.Load(reader);
            return doc;
        }

        private static string Attribute(XmlNode node, string name)
        {
            if (node == null || node.Attributes == null)
                return String.Empty;
            XmlAttribute exact = node.Attributes[name];
            if (exact != null)
                return exact.Value;
            foreach (XmlAttribute attribute in node.Attributes)
            {
                if (String.Equals(attribute.LocalName, name, StringComparison.OrdinalIgnoreCase))
                    return attribute.Value;
            }
            return String.Empty;
        }

        private static double NumberAttribute(XmlNode node, string name)
        {
            double value;
            return Double.TryParse(Attribute(node, name), NumberStyles.Float, CultureInfo.InvariantCulture, out value)
                ? value
                : 0;
        }

        private static void ApplyPoints(TranscriptionLine line, string points)
        {
            if (String.IsNullOrWhiteSpace(points))
                return;
            List<double> values = new List<double>();
            foreach (string pair in points.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries))
            {
                string[] parts = pair.Split(',');
                double value;
                if (parts.Length == 2 &&
                    Double.TryParse(parts[0], NumberStyles.Float, CultureInfo.InvariantCulture, out value))
                    values.Add(value);
                if (parts.Length == 2 &&
                    Double.TryParse(parts[1], NumberStyles.Float, CultureInfo.InvariantCulture, out value))
                    values.Add(value);
            }
            if (values.Count < 4)
                return;
            double minX = values[0];
            double maxX = values[0];
            double minY = values[1];
            double maxY = values[1];
            for (int i = 2; i + 1 < values.Count; i += 2)
            {
                minX = Math.Min(minX, values[i]);
                maxX = Math.Max(maxX, values[i]);
                minY = Math.Min(minY, values[i + 1]);
                maxY = Math.Max(maxY, values[i + 1]);
            }
            line.X = minX;
            line.Y = minY;
            line.Width = Math.Max(0, maxX - minX);
            line.Height = Math.Max(0, maxY - minY);
            line.HasCoordinates = line.Width > 0 && line.Height > 0;
        }

        private static string NormalizeXmlText(string value)
        {
            return Regex.Replace(value ?? String.Empty, @"\s+", " ").Trim();
        }
    }

    internal static class LocalCleaner
    {
        public static string Clean(string value)
        {
            if (String.IsNullOrEmpty(value))
                return String.Empty;
            string cleaned = value.Normalize(NormalizationForm.FormC);
            cleaned = cleaned.Replace('\u00AD', ' ');
            cleaned = cleaned.Replace('\uFB01', 'f').Replace('\uFB02', 'f');
            cleaned = Regex.Replace(cleaned, @"\s+", " ").Trim();
            cleaned = Regex.Replace(cleaned, @"\s+([,.;:!?])", "$1");
            return cleaned;
        }
    }

    internal static class HistoricalSpellingResolver
    {
        private static readonly Dictionary<string, string> German =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "fich", "sich" },
                { "ift", "ist" },
                { "folch", "solch" },
                { "lolch", "solch" },
                { "fo", "so" },
                { "fch", "sch" }
            };

        private static readonly Dictionary<string, string> English =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "lhe", "she" },
                { "lhall", "shall" },
                { "lhal", "shall" },
                { "luch", "such" },
                { "thil", "this" }
            };

        private static readonly Dictionary<string, string> Latin =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "eft", "est" },
                { "funt", "sunt" },
                { "fed", "sed" },
                { "fic", "sic" }
            };

        private static readonly Dictionary<string, string> French =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "eft", "est" },
                { "font", "sont" },
                { "fuis", "suis" }
            };

        public static string Instruction(string languageHint)
        {
            if (Contains(languageHint, "German"))
                return "German examples requiring contextual checks include fich→sich, ift→ist, " +
                    "lolch→solch, but words where l/f is genuinely correct must stay unchanged.";
            if (Contains(languageHint, "English"))
                return "English examples include lhe→she, lhall→shall, luch→such, thil→this, " +
                    "but do not alter genuine l/f spellings.";
            if (Contains(languageHint, "Latin"))
                return "Latin examples include eft→est, funt→sunt, fed→sed, but preserve genuine l/f.";
            if (Contains(languageHint, "French"))
                return "French examples include eft→est, font→sont, fuis→suis, but preserve genuine l/f.";
            return "Use vocabulary and syntax in the detected language rather than a global l/f→s rule.";
        }

        public static string ApplyKnownCorrections(string text, string languageHint)
        {
            if (String.IsNullOrEmpty(text))
                return text;
            Dictionary<string, string> mappings = null;
            if (Contains(languageHint, "German"))
                mappings = German;
            else if (Contains(languageHint, "English"))
                mappings = English;
            else if (Contains(languageHint, "Latin"))
                mappings = Latin;
            else if (Contains(languageHint, "French"))
                mappings = French;
            if (mappings == null)
                return text;

            return Regex.Replace(text, @"[\p{L}\p{M}]+", delegate(Match match)
            {
                string replacement;
                if (!mappings.TryGetValue(match.Value, out replacement))
                    return match.Value;
                if (Char.IsUpper(match.Value[0]) && replacement.Length > 0)
                    return Char.ToUpperInvariant(replacement[0]) + replacement.Substring(1);
                return replacement;
            });
        }

        private static bool Contains(string value, string token)
        {
            return !String.IsNullOrEmpty(value) &&
                value.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0;
        }
    }

    internal sealed class AiTranslationService
    {
        private static readonly HttpClient Client = CreateClient();

        private sealed class ContextChunk
        {
            public List<TranscriptionLine> Lines { get; set; }
            public string Translation { get; set; }

            public ContextChunk()
            {
                Lines = new List<TranscriptionLine>();
                Translation = String.Empty;
            }
        }

        private static HttpClient CreateClient()
        {
            HttpClient client = new HttpClient();
            client.Timeout = TimeSpan.FromMinutes(3);
            client.DefaultRequestHeaders.UserAgent.ParseAdd("eScriptorium-Studio/1.0");
            return client;
        }

        public bool IsConfigured(AppSettings settings)
        {
            if (String.IsNullOrWhiteSpace(settings.AiEndpoint))
                return false;
            string key = settings.GetAiApiKey();
            bool localEndpoint = settings.AiEndpoint.IndexOf("localhost", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                 settings.AiEndpoint.IndexOf("127.0.0.1", StringComparison.OrdinalIgnoreCase) >= 0;
            return localEndpoint || !String.IsNullOrWhiteSpace(key);
        }

        public async Task ProcessAsync(
            IList<TranscriptionLine> lines,
            AppSettings settings,
            Action<int, int> progress,
            CancellationToken token)
        {
            ValidateInput(lines, settings);

            const int batchSize = 20;
            int total = lines.Count;
            for (int offset = 0; offset < total; offset += batchSize)
            {
                token.ThrowIfCancellationRequested();
                List<TranscriptionLine> batch = lines.Skip(offset).Take(batchSize).ToList();
                await ProcessBatchAsync(batch, settings, token);
                progress(Math.Min(total, offset + batch.Count), total);
            }
        }

        public async Task<ContextTranslationResult> TranslateDocumentAsync(
            IList<TranscriptionLine> lines,
            AppSettings settings,
            Action<int, int> progress,
            CancellationToken token)
        {
            return await TranslateDocumentAsync(lines, settings, progress, 2, token);
        }

        public async Task<ContextTranslationResult> TranslateDocumentAsync(
            IList<TranscriptionLine> lines,
            AppSettings settings,
            Action<int, int> progress,
            int pageConcurrency,
            CancellationToken token)
        {
            ValidateInput(lines, settings);
            List<IGrouping<int, TranscriptionLine>> pages = lines
                .GroupBy(line => line.Page <= 0 ? 1 : line.Page)
                .OrderBy(group => group.Key)
                .ToList();
            string languageHint = DetectPageLanguage(lines, settings.SourceLanguage);
            int completedPages = 0;

            string systemPrompt =
                "You process one manuscript page as a single contextual node. " +
                "OCR frequently confuses l, f and s (including long s ſ). Do not replace them mechanically. " +
                "Resolve each suspicious token using language-specific spelling patterns, function words, " +
                "morphology, capitalization and nearby-line syntax. A replacement from l/f to s is valid only " +
                "when it forms a plausible word in the detected source language. Keep the original if the " +
                "evidence is ambiguous. Language hint: " + languageHint + ". " +
                HistoricalSpellingResolver.Instruction(languageHint) + " " +
                "Return a contextual_cleanse that preserves early modern spelling, u/v and i/j forms while " +
                "making line continuations readable. Then translate " +
                "the whole page coherently into " + settings.TargetLanguage + ", using neighboring lines " +
                "to resolve pronouns, omitted subjects and cross-line syntax. Do not invent missing facts. " +
                "Every input line id must appear exactly once in lines[]. Return strict JSON only: " +
                "{\"page\":1,\"contextual_cleanse\":\"...\",\"translation\":\"...\"," +
                "\"lines\":[{\"id\":1,\"cleaned\":\"...\",\"translation\":\"...\"}]}.";

            int safeConcurrency = Math.Max(1, Math.Min(4, pageConcurrency));
            SemaphoreSlim concurrency = new SemaphoreSlim(safeConcurrency, safeConcurrency);
            List<Task<ContextPageResult>> tasks = new List<Task<ContextPageResult>>();
            foreach (IGrouping<int, TranscriptionLine> page in pages)
            {
                IGrouping<int, TranscriptionLine> pageGroup = page;
                tasks.Add(Task.Run(async () =>
                {
                    await concurrency.WaitAsync(token).ConfigureAwait(false);
                    try
                    {
                        token.ThrowIfCancellationRequested();
                        List<TranscriptionLine> pageLines = pageGroup
                            .OrderBy(line => line.Order)
                            .ThenBy(line => line.Id)
                            .ToList();
                        List<object> input = pageLines.Select(line => new
                        {
                            id = line.Id,
                            page = pageGroup.Key,
                            order = line.Order,
                            text = String.IsNullOrWhiteSpace(line.Cleaned) ? line.Original : line.Cleaned,
                            x = line.HasCoordinates ? line.X : (double?)null,
                            y = line.HasCoordinates ? line.Y : (double?)null,
                            width = line.HasCoordinates ? line.Width : (double?)null,
                            height = line.HasCoordinates ? line.Height : (double?)null
                        }).Cast<object>().ToList();
                        string userPrompt =
                            "Page number: " + pageGroup.Key + "\n" +
                            "Source language: " + settings.SourceLanguage + "\n" +
                            "Target language: " + settings.TargetLanguage + "\n" +
                            "Page lines in reading order:\n" +
                            new JavaScriptSerializer().Serialize(input);
                        string response = await CompleteChatAsync(
                            settings, systemPrompt, userPrompt, token).ConfigureAwait(false);
                        PageContextPayload payload = ParsePageContextResponse(
                            response, pageGroup.Key, pageLines, languageHint);
                        int completed = Interlocked.Increment(ref completedPages);
                        if (progress != null)
                            progress(completed, pages.Count);
                        return new ContextPageResult
                        {
                            Page = pageGroup.Key,
                            ContextualCleanse = payload.contextual_cleanse.Trim(),
                            Translation = payload.translation.Trim(),
                            LineCount = pageLines.Count,
                            LineIds = pageLines.Select(line => line.Id).ToList()
                        };
                    }
                    finally
                    {
                        concurrency.Release();
                    }
                }, token));
            }

            ContextPageResult[] unorderedResults = await Task.WhenAll(tasks).ConfigureAwait(false);
            List<ContextPageResult> pageResults = unorderedResults
                .OrderBy(result => result.Page)
                .ToList();

            string translationText = String.Join(Environment.NewLine + Environment.NewLine,
                pageResults.Select(result =>
                    "===== PAGE " + result.Page + " / 第 " + result.Page + " 页 =====" +
                    Environment.NewLine + result.Translation));
            string cleanseText = String.Join(Environment.NewLine + Environment.NewLine,
                pageResults.Select(result =>
                    "===== PAGE " + result.Page + " / 第 " + result.Page + " 页 =====" +
                    Environment.NewLine + result.ContextualCleanse));

            return new ContextTranslationResult
            {
                Translation = translationText,
                CleanseText = cleanseText,
                TargetLanguage = settings.TargetLanguage,
                LineCount = lines.Count,
                ChunkCount = pages.Count,
                CreatedAt = DateTime.Now,
                Pages = pageResults
            };
        }

        private static void ValidateInput(IList<TranscriptionLine> lines, AppSettings settings)
        {
            if (lines == null || lines.Count == 0)
                throw AiErrors.Create(AiErrorCode.NoInputLines, "Imported line count: 0");
            if (String.IsNullOrWhiteSpace(settings.AiEndpoint) ||
                String.IsNullOrWhiteSpace(settings.AiModel) ||
                !(settings.AiEndpoint.IndexOf("localhost", StringComparison.OrdinalIgnoreCase) >= 0 ||
                  settings.AiEndpoint.IndexOf("127.0.0.1", StringComparison.OrdinalIgnoreCase) >= 0 ||
                  !String.IsNullOrWhiteSpace(settings.GetAiApiKey())))
            {
                throw AiErrors.Create(
                    AiErrorCode.ConfigurationRequired,
                    "Endpoint: " + settings.AiEndpoint + "\nModel: " + settings.AiModel +
                    "\nAPI key present: " + (!String.IsNullOrWhiteSpace(settings.GetAiApiKey())));
            }
            Uri endpoint;
            if (!Uri.TryCreate(settings.AiEndpoint, UriKind.Absolute, out endpoint) ||
                (endpoint.Scheme != Uri.UriSchemeHttp && endpoint.Scheme != Uri.UriSchemeHttps))
            {
                throw AiErrors.Create(AiErrorCode.InvalidEndpoint, "Endpoint: " + settings.AiEndpoint);
            }
        }

        private static string DetectPageLanguage(
            IList<TranscriptionLine> lines,
            string configuredSourceLanguage)
        {
            if (!String.IsNullOrWhiteSpace(configuredSourceLanguage) &&
                configuredSourceLanguage.IndexOf("auto", StringComparison.OrdinalIgnoreCase) < 0)
                return configuredSourceLanguage;

            string text = String.Join(" ", lines.Select(line => line.Original));
            HashSet<string> tokens = new HashSet<string>(
                Regex.Matches(text.ToLowerInvariant(), @"[\p{L}\p{M}]+")
                    .Cast<Match>()
                    .Select(match => match.Value),
                StringComparer.OrdinalIgnoreCase);
            Dictionary<string, string[]> markers =
                new Dictionary<string, string[]>
                {
                    { "German", new[] { "der", "die", "das", "und", "den", "ist", "ich", "nicht", "mit", "von", "zu", "ſeyn", "seyn", "wird" } },
                    { "English", new[] { "the", "and", "thou", "thee", "hath", "doth", "shall", "which", "that", "with", "she", "his" } },
                    { "Latin", new[] { "et", "in", "est", "sunt", "sed", "quod", "non", "cum", "ad", "de", "qui", "quae" } },
                    { "French", new[] { "le", "la", "les", "des", "que", "dans", "et", "est", "pour", "une", "avec", "son" } },
                    { "Spanish", new[] { "el", "la", "los", "las", "que", "de", "en", "por", "una", "con", "es", "son" } },
                    { "Italian", new[] { "il", "la", "gli", "le", "che", "di", "in", "per", "una", "con", "sono" } },
                    { "Portuguese", new[] { "o", "a", "os", "as", "que", "de", "em", "por", "uma", "com", "são" } },
                    { "Dutch", new[] { "de", "het", "een", "en", "van", "in", "dat", "met", "is", "niet", "zijn" } }
                };
            string best = "Early modern European language (undetermined)";
            int bestScore = 0;
            foreach (KeyValuePair<string, string[]> pair in markers)
            {
                int score = pair.Value.Count(tokens.Contains);
                if (score > bestScore)
                {
                    bestScore = score;
                    best = pair.Key;
                }
            }
            return best + (bestScore > 0 ? " (auto-detected)" : String.Empty);
        }

        private async Task<string> CompleteChatAsync(
            AppSettings settings,
            string systemPrompt,
            string userPrompt,
            CancellationToken token)
        {
            Dictionary<string, object> body = new Dictionary<string, object>();
            body["model"] = settings.AiModel;
            body["temperature"] = 0.1;
            body["messages"] = new object[]
            {
                new Dictionary<string, object> { { "role", "system" }, { "content", systemPrompt } },
                new Dictionary<string, object> { { "role", "user" }, { "content", userPrompt } }
            };
            body["stream"] = false;
            if (settings.AiEndpoint.IndexOf("deepseek.com", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                body["thinking"] = new Dictionary<string, object> { { "type", "disabled" } };
                body["response_format"] = new Dictionary<string, object> { { "type", "json_object" } };
            }
            string json = new JavaScriptSerializer().Serialize(body);
            return await PostWithRetryAsync(settings, json, token).ConfigureAwait(false);
        }

        private static PageContextPayload ParsePageContextResponse(
            string response,
            int expectedPage,
            List<TranscriptionLine> pageLines,
            string languageHint)
        {
            if (String.IsNullOrWhiteSpace(response))
                throw AiErrors.Create(AiErrorCode.InvalidResponseJson, "Page translation response is empty.");
            string json = ExtractJson(response);
            PageContextPayload payload = null;
            try
            {
                payload = new JavaScriptSerializer().Deserialize<PageContextPayload>(json);
            }
            catch (Exception ex)
            {
                throw AiErrors.Create(
                    AiErrorCode.InvalidResponseJson,
                    "Expected a page-node JSON object.\nResponse: " + response,
                    ex);
            }
            if (payload == null || payload.lines == null || payload.lines.Count == 0)
            {
                throw AiErrors.Create(
                    AiErrorCode.InvalidResponseJson,
                    "Page-node response has no lines[].\nResponse: " + response);
            }

            List<int> expectedIds = pageLines.Select(line => line.Id).ToList();
            List<int> returnedIds = payload.lines.Select(line => line.id).ToList();
            List<int> missing = expectedIds.Except(returnedIds).ToList();
            List<int> unexpected = returnedIds.Except(expectedIds).ToList();
            List<int> duplicates = returnedIds
                .GroupBy(id => id)
                .Where(group => group.Count() > 1)
                .Select(group => group.Key)
                .ToList();
            bool orderMismatch = !expectedIds.SequenceEqual(
                returnedIds.Where(expectedIds.Contains));
            if (missing.Count > 0 || unexpected.Count > 0 ||
                duplicates.Count > 0 || orderMismatch)
            {
                throw AiErrors.Create(
                    AiErrorCode.LineAlignmentFailed,
                    "Page " + expectedPage + "\nExpected IDs: " + String.Join(",", expectedIds) +
                    "\nReturned IDs: " + String.Join(",", returnedIds) +
                    "\nMissing: " + String.Join(",", missing) +
                    "\nUnexpected: " + String.Join(",", unexpected) +
                    "\nDuplicates: " + String.Join(",", duplicates));
            }

            Dictionary<int, TranscriptionLine> byId =
                pageLines.ToDictionary(line => line.Id);
            foreach (AiLineResult result in payload.lines)
            {
                TranscriptionLine line = byId[result.id];
                string cleaned = String.IsNullOrWhiteSpace(result.cleaned)
                    ? LocalCleaner.Clean(line.Original)
                    : LocalCleaner.Clean(result.cleaned);
                line.Cleaned = HistoricalSpellingResolver.ApplyKnownCorrections(
                    cleaned, languageHint);
                line.Translation = (result.translation ?? String.Empty).Trim();
                line.Status = L.T("AI page aligned", "AI 页面已对齐");
            }

            if (String.IsNullOrWhiteSpace(payload.contextual_cleanse))
                payload.contextual_cleanse = String.Join(" ",
                    pageLines.Select(line => line.Cleaned));
            else
                payload.contextual_cleanse = HistoricalSpellingResolver.ApplyKnownCorrections(
                    payload.contextual_cleanse, languageHint);
            if (String.IsNullOrWhiteSpace(payload.translation))
                payload.translation = String.Join(" ",
                    pageLines.Select(line => line.Translation));
            payload.contextual_cleanse = PolishProse(payload.contextual_cleanse);
            payload.translation = PolishProse(payload.translation);
            return payload;
        }

        private static string PolishProse(string text)
        {
            if (String.IsNullOrWhiteSpace(text))
                return String.Empty;
            string polished = Regex.Replace(text, @"\s+", " ").Trim();
            polished = Regex.Replace(polished, @"\s+([,.;:!?])", "$1");
            polished = Regex.Replace(polished, @"([,.;:!?])(?=\p{L})", "$1 ");
            return polished;
        }

        private async Task ProcessBatchAsync(
            List<TranscriptionLine> batch,
            AppSettings settings,
            CancellationToken token)
        {
            List<object> input = batch.Select(line => new
            {
                id = line.Id,
                text = line.Original,
                x = line.HasCoordinates ? line.X : (double?)null,
                y = line.HasCoordinates ? line.Y : (double?)null,
                width = line.HasCoordinates ? line.Width : (double?)null,
                height = line.HasCoordinates ? line.Height : (double?)null
            }).Cast<object>().ToList();

            string systemPrompt =
                "You are a careful scholarly assistant for early modern European manuscripts. " +
                "Work line by line and preserve every input id. Cleaning must retain original spelling, " +
                "abbreviations, long s, u/v and i/j forms unless evidence makes a correction unambiguous. " +
                "Never invent missing words. Mark unreadable text as [illegible]. Translation must align to " +
                "the same line and coordinates, not merge or split lines. Return strict JSON only, with shape " +
                "{\"lines\":[{\"id\":1,\"cleaned\":\"...\",\"translation\":\"...\"}]} and no markdown.";
            string batchLanguage = DetectPageLanguage(batch, settings.SourceLanguage);
            systemPrompt += " Language hint: " + batchLanguage + ". " +
                HistoricalSpellingResolver.Instruction(batchLanguage);
            string userPrompt =
                "Source language: " + settings.SourceLanguage + "\n" +
                "Target language: " + settings.TargetLanguage + "\n" +
                "Lines as JSON:\n" + new JavaScriptSerializer().Serialize(input);

            string responseText = await CompleteChatAsync(
                settings, systemPrompt, userPrompt, token).ConfigureAwait(false);
            ApplyResponse(responseText, batch, settings.SourceLanguage);
        }

        private async Task<string> PostWithRetryAsync(
            AppSettings settings,
            string body,
            CancellationToken token)
        {
            Exception last = null;
            string endpoint = settings.AiEndpoint.Trim();
            for (int attempt = 0; attempt < 3; attempt++)
            {
                token.ThrowIfCancellationRequested();
                bool retryDelay = false;
                bool usePythonFallback = false;
                string fallbackReason = String.Empty;
                try
                {
                    using (HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, endpoint))
                    {
                        string key = settings.GetAiApiKey();
                        if (!String.IsNullOrWhiteSpace(key))
                            request.Headers.Authorization =
                                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", key);
                        request.Content = new StringContent(body, Encoding.UTF8, "application/json");
                        using (HttpResponseMessage response = await Client.SendAsync(request, token).ConfigureAwait(false))
                        {
                            string text = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                            if (response.StatusCode == (HttpStatusCode)429 ||
                                (int)response.StatusCode >= 500)
                            {
                                AiRequestException statusError =
                                    AiErrors.FromHttpStatus(response.StatusCode, text);
                                if (attempt >= 2)
                                    throw statusError;
                                last = statusError;
                                await Task.Delay(TimeSpan.FromSeconds(2 + attempt * 3), token).ConfigureAwait(false);
                                continue;
                            }
                            if (!response.IsSuccessStatusCode)
                                throw AiErrors.FromHttpStatus(response.StatusCode, text);
                            return ExtractChatContent(text);
                        }
                    }
                }
                catch (OperationCanceledException ex)
                {
                    if (token.IsCancellationRequested)
                        throw;
                    throw AiErrors.Create(
                        AiErrorCode.RequestTimeout,
                        "Endpoint: " + endpoint + "\nThe three-minute HTTP timeout elapsed.",
                        ex);
                }
                catch (AiRequestException ex)
                {
                    if (ex.Code == AiErrorCode.WindowsTlsCredentials ||
                        ex.Code == AiErrorCode.TlsCertificateError)
                    {
                        usePythonFallback = true;
                        fallbackReason = ex.Code;
                    }
                    else
                    {
                        throw;
                    }
                }
                catch (Exception ex)
                {
                    AiRequestException transportError = AiErrors.FromTransport(ex, endpoint);
                    if (transportError.Code == AiErrorCode.WindowsTlsCredentials ||
                        transportError.Code == AiErrorCode.TlsCertificateError)
                    {
                        usePythonFallback = true;
                        fallbackReason = transportError.Code;
                    }
                    else
                    {
                        last = transportError;
                        retryDelay = attempt < 2;
                    }
                }
                if (usePythonFallback)
                {
                    AppPaths.Log(
                        "AI_TRANSPORT_FALLBACK=" + fallbackReason +
                        " endpoint=" + endpoint +
                        " python_openSSL=true");
                    AiPythonResult fallbackResponse =
                        await AiPythonFallback.PostAsync(settings, body, token);
                    if (!String.IsNullOrWhiteSpace(fallbackResponse.Content))
                        return fallbackResponse.Content;
                    return ExtractChatContent(fallbackResponse.Text);
                }
                if (retryDelay)
                    await Task.Delay(TimeSpan.FromSeconds(2 + attempt * 3), token).ConfigureAwait(false);
            }
            AiRequestException previous = last as AiRequestException;
            if (previous != null)
                throw previous;
            throw AiErrors.Create(
                AiErrorCode.ConnectionFailed,
                "Endpoint: " + endpoint + "\n" + (last == null ? "No response after retries." : last.ToString()),
                last);
        }

        private static string ExtractChatContent(string responseJson)
        {
            try
            {
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                Dictionary<string, object> root =
                    serializer.Deserialize<Dictionary<string, object>>(responseJson);
                object choicesObject;
                if (root != null && root.TryGetValue("choices", out choicesObject))
                {
                    object[] choices = ToObjectArray(choicesObject);
                    if (choices != null && choices.Length > 0)
                    {
                        Dictionary<string, object> first = choices[0] as Dictionary<string, object>;
                        object messageObject;
                        if (first != null && first.TryGetValue("message", out messageObject))
                        {
                            Dictionary<string, object> message = messageObject as Dictionary<string, object>;
                            object contentObject;
                            if (message != null && message.TryGetValue("content", out contentObject))
                            {
                                string content = Convert.ToString(contentObject);
                                if (!String.IsNullOrWhiteSpace(content))
                                    return content;
                                throw AiErrors.Create(
                                    AiErrorCode.MissingChatChoices,
                                    "choices[0].message.content is empty.\nResponse: " + responseJson);
                            }
                        }
                    }
                }
                throw AiErrors.Create(
                    AiErrorCode.MissingChatChoices,
                    "Expected choices[0].message.content.\nResponse: " + responseJson);
            }
            catch (AiRequestException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw AiErrors.Create(
                    AiErrorCode.InvalidResponseJson,
                    "Response: " + responseJson,
                    ex);
            }
        }

        private static object[] ToObjectArray(object value)
        {
            object[] direct = value as object[];
            if (direct != null)
                return direct;
            IList list = value as IList;
            if (list == null)
                return null;
            object[] items = new object[list.Count];
            for (int index = 0; index < list.Count; index++)
                items[index] = list[index];
            return items;
        }

        private static void ApplyResponse(
            string content,
            List<TranscriptionLine> batch,
            string configuredSourceLanguage)
        {
            string json = ExtractJson(content);
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            List<AiLineResult> results = null;
            try
            {
                AiEnvelope envelope = serializer.Deserialize<AiEnvelope>(json);
                if (envelope != null)
                    results = envelope.lines;
            }
            catch (Exception firstError)
            {
                try
                {
                    results = serializer.Deserialize<List<AiLineResult>>(json);
                }
                catch
                {
                    throw AiErrors.Create(
                        AiErrorCode.InvalidResponseJson,
                        "AI message content:\n" + content,
                        firstError);
                }
            }

            if (results == null || results.Count == 0)
                throw AiErrors.Create(
                    AiErrorCode.InvalidResponseJson,
                    "Expected {\"lines\":[...]} with id, cleaned and translation.\n" + content);

            Dictionary<int, TranscriptionLine> byId = batch.ToDictionary(line => line.Id);
            string languageHint = DetectPageLanguage(batch, configuredSourceLanguage);
            int matched = 0;
            foreach (AiLineResult result in results)
            {
                TranscriptionLine line;
                if (!byId.TryGetValue(result.id, out line))
                    continue;
                matched++;
                string cleaned = String.IsNullOrWhiteSpace(result.cleaned)
                    ? LocalCleaner.Clean(line.Original)
                    : LocalCleaner.Clean(result.cleaned);
                line.Cleaned = HistoricalSpellingResolver.ApplyKnownCorrections(
                    cleaned, languageHint);
                line.Translation = (result.translation ?? String.Empty).Trim();
                line.Status = L.T("AI aligned", "AI 已对齐");
            }
            if (matched == 0)
                throw AiErrors.Create(
                    AiErrorCode.LineAlignmentFailed,
                    "Input IDs: " + String.Join(",", batch.Select(line => line.Id)) +
                    "\nReturned IDs: " + String.Join(",", results.Select(result => result.id)) +
                    "\nAI message content:\n" + content);
        }

        private static string ExtractJson(string content)
        {
            if (String.IsNullOrWhiteSpace(content))
                return "{}";
            int firstObject = content.IndexOf('{');
            int lastObject = content.LastIndexOf('}');
            if (firstObject >= 0 && lastObject > firstObject)
                return content.Substring(firstObject, lastObject - firstObject + 1);
            int firstArray = content.IndexOf('[');
            int lastArray = content.LastIndexOf(']');
            if (firstArray >= 0 && lastArray > firstArray)
                return content.Substring(firstArray, lastArray - firstArray + 1);
            return content.Trim();
        }
    }

    internal static class TextAnalyzer
    {
        private static readonly Regex TokenRegex = new Regex(
            @"[\p{L}\p{M}]+(?:['’.-][\p{L}\p{M}]+)*",
            RegexOptions.Compiled | RegexOptions.CultureInvariant);

        private static readonly Dictionary<string, string> LanguageMarkers =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "Latin", "et in est quod non cum ad de qui quae" },
                { "English", "the and thou thee hath doth shall which that with" },
                { "French", "le la les des que dans et est pour une avec" },
                { "German", "der die das und den mit ist nicht ein eine" },
                { "Spanish", "el la los las que de en por una con es" },
                { "Italian", "il la gli le che di in per una con è" },
                { "Portuguese", "o a os as que de em por uma com é" },
                { "Dutch", "de het een en van in dat met is niet" }
            };

        public static TextAnalysis Analyze(IList<TranscriptionLine> lines)
        {
            TextAnalysis analysis = new TextAnalysis();
            analysis.Lines = lines.Count;
            analysis.Coordinates = lines.Count(line => line.HasCoordinates);
            List<string> tokens = new List<string>();
            foreach (TranscriptionLine line in lines)
            {
                string source = String.IsNullOrWhiteSpace(line.Cleaned) ? line.Original : line.Cleaned;
                foreach (Match match in TokenRegex.Matches(source ?? String.Empty))
                    tokens.Add(NormalizeToken(match.Value));
            }
            analysis.Tokens = tokens.Count;
            analysis.Types = tokens.Distinct(StringComparer.OrdinalIgnoreCase).Count();
            analysis.TypeTokenRatio = tokens.Count == 0 ? 0 : (double)analysis.Types / tokens.Count;
            analysis.AverageTokenLength = tokens.Count == 0 ? 0 : tokens.Average(token => token.Length);
            analysis.TopWords = tokens
                .Where(token => token.Length > 1)
                .GroupBy(token => token, StringComparer.OrdinalIgnoreCase)
                .Select(group => new WordFrequency { Word = group.Key, Count = group.Count() })
                .OrderByDescending(item => item.Count)
                .ThenBy(item => item.Word)
                .Take(30)
                .ToList();
            analysis.LikelyLanguage = GuessLanguage(tokens);
            return analysis;
        }

        public static string Format(TextAnalysis analysis)
        {
            StringBuilder text = new StringBuilder();
            text.AppendLine(L.T("TEXT ANALYSIS", "文本分析"));
            text.AppendLine("====================");
            text.AppendLine(L.T("Lines: ", "行数：") + analysis.Lines);
            text.AppendLine(L.T("Coordinate-bearing lines: ", "带坐标行数：") + analysis.Coordinates);
            text.AppendLine(L.T("Tokens: ", "词元数：") + analysis.Tokens);
            text.AppendLine(L.T("Types: ", "词型数：") + analysis.Types);
            text.AppendLine(L.T("Type/token ratio: ", "词型/词元比：") +
                analysis.TypeTokenRatio.ToString("P1", CultureInfo.InvariantCulture));
            text.AppendLine(L.T("Average token length: ", "平均词元长度：") +
                analysis.AverageTokenLength.ToString("0.00", CultureInfo.InvariantCulture));
            text.AppendLine(L.T("Likely language: ", "语言提示：") + analysis.LikelyLanguage);
            text.AppendLine();
            text.AppendLine(L.T("Top words", "高频词"));
            foreach (WordFrequency word in analysis.TopWords)
                text.AppendLine(String.Format("{0,-24} {1}", word.Word, word.Count));
            return text.ToString();
        }

        private static string NormalizeToken(string token)
        {
            return token.ToLowerInvariant().Replace('ſ', 's').Normalize(NormalizationForm.FormC);
        }

        private static string GuessLanguage(List<string> tokens)
        {
            if (tokens.Count == 0)
                return "—";
            HashSet<string> set = new HashSet<string>(tokens, StringComparer.OrdinalIgnoreCase);
            string best = "Undetermined";
            int bestScore = 0;
            foreach (KeyValuePair<string, string> pair in LanguageMarkers)
            {
                int score = pair.Value.Split(' ').Count(set.Contains);
                if (score > bestScore)
                {
                    best = pair.Key;
                    bestScore = score;
                }
            }
            return bestScore == 0 ? "Undetermined" : best;
        }
    }

    internal static class ExportService
    {
        public static void ExportCsv(string path, IList<TranscriptionLine> lines)
        {
            StringBuilder csv = new StringBuilder();
            csv.AppendLine("id,page,source_file,original,cleaned,translation,x,y,width,height,has_coordinates,status");
            foreach (TranscriptionLine line in lines)
            {
                csv.AppendLine(String.Join(",", new[]
                {
                    line.Id.ToString(CultureInfo.InvariantCulture),
                    line.Page.ToString(CultureInfo.InvariantCulture),
                    Csv(line.SourceFile),
                    Csv(line.Original),
                    Csv(line.Cleaned),
                    Csv(line.Translation),
                    line.X.ToString("0.##", CultureInfo.InvariantCulture),
                    line.Y.ToString("0.##", CultureInfo.InvariantCulture),
                    line.Width.ToString("0.##", CultureInfo.InvariantCulture),
                    line.Height.ToString("0.##", CultureInfo.InvariantCulture),
                    line.HasCoordinates ? "true" : "false",
                    Csv(line.Status)
                }));
            }
            File.WriteAllText(path, csv.ToString(), new UTF8Encoding(true));
        }

        public static void ExportJson(
            string path,
            IList<TranscriptionLine> lines,
            TextAnalysis analysis,
            string contextTranslation = null,
            string contextCleanse = null,
            IList<ContextPageResult> contextPages = null)
        {
            Dictionary<string, object> doc = new Dictionary<string, object>();
            doc["generator"] = "eScriptorium Studio";
            doc["created"] = DateTime.Now.ToString("o", CultureInfo.InvariantCulture);
            doc["analysis"] = analysis;
            doc["lines"] = lines;
            doc["context_translation"] = contextTranslation ?? String.Empty;
            doc["context_cleanse"] = contextCleanse ?? String.Empty;
            doc["context_pages"] = contextPages ?? new List<ContextPageResult>();
            File.WriteAllText(path,
                new JavaScriptSerializer().Serialize(doc),
                new UTF8Encoding(false));
        }

        public static void ExportTei(string path, IList<TranscriptionLine> lines, TextAnalysis analysis,
            string sourceLanguage, string targetLanguage,
            string contextTranslation = null,
            string contextCleanse = null,
            IList<ContextPageResult> contextPages = null)
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.Encoding = new UTF8Encoding(false);
            using (XmlWriter writer = XmlWriter.Create(path, settings))
            {
                writer.WriteStartDocument();
                writer.WriteStartElement("TEI", "http://www.tei-c.org/ns/1.0");
                writer.WriteStartElement("teiHeader");
                writer.WriteStartElement("fileDesc");
                writer.WriteElementString("title", "eScriptorium Studio bilingual transcription");
                writer.WriteStartElement("publicationStmt");
                writer.WriteElementString("p", "Generated locally by eScriptorium Studio");
                writer.WriteEndElement();
                writer.WriteStartElement("sourceDesc");
                writer.WriteElementString("p", "Created from: " +
                    String.Join("; ", lines.Select(line => line.SourceFile).Distinct()));
                writer.WriteEndElement();
                writer.WriteEndElement();
                writer.WriteStartElement("encodingDesc");
                writer.WriteStartElement("p");
                writer.WriteAttributeString("type", "translationDirection");
                writer.WriteAttributeString("source", sourceLanguage);
                writer.WriteAttributeString("target", targetLanguage);
                writer.WriteEndElement();
                writer.WriteEndElement();
                writer.WriteEndElement();

                writer.WriteStartElement("facsimile");
                foreach (TranscriptionLine line in lines.Where(item => item.HasCoordinates))
                {
                    writer.WriteStartElement("surface");
                    writer.WriteAttributeString("n", line.Page.ToString(CultureInfo.InvariantCulture));
                    writer.WriteStartElement("zone");
                    writer.WriteAttributeString("xml", "id", "http://www.w3.org/XML/1998/namespace", "zone-" + line.Id);
                    writer.WriteAttributeString("ulx", line.X.ToString("0.##", CultureInfo.InvariantCulture));
                    writer.WriteAttributeString("uly", line.Y.ToString("0.##", CultureInfo.InvariantCulture));
                    writer.WriteAttributeString("lrx", (line.X + line.Width).ToString("0.##", CultureInfo.InvariantCulture));
                    writer.WriteAttributeString("lry", (line.Y + line.Height).ToString("0.##", CultureInfo.InvariantCulture));
                    writer.WriteEndElement();
                    writer.WriteEndElement();
                }
                writer.WriteEndElement();

                writer.WriteStartElement("text");
                writer.WriteStartElement("body");
                writer.WriteStartElement("div");
                writer.WriteAttributeString("type", "bilingualTranscription");
                foreach (TranscriptionLine line in lines)
                {
                    writer.WriteStartElement("seg");
                    writer.WriteAttributeString("xml", "id", "http://www.w3.org/XML/1998/namespace", "line-" + line.Id);
                    writer.WriteAttributeString("type", "textLine");
                    if (line.HasCoordinates)
                        writer.WriteAttributeString("corresp", "#zone-" + line.Id);
                    writer.WriteStartElement("orig");
                    writer.WriteString(line.Original ?? String.Empty);
                    writer.WriteEndElement();
                    writer.WriteStartElement("reg");
                    writer.WriteString(String.IsNullOrEmpty(line.Cleaned) ? (line.Original ?? String.Empty) : line.Cleaned);
                    writer.WriteEndElement();
                    writer.WriteStartElement("note");
                    writer.WriteAttributeString("type", "alignedTranslation");
                    writer.WriteString(line.Translation ?? String.Empty);
                    writer.WriteEndElement();
                    writer.WriteEndElement();
                }
                writer.WriteEndElement();
                if (contextPages != null && contextPages.Count > 0)
                {
                    foreach (ContextPageResult page in contextPages)
                    {
                        writer.WriteStartElement("div");
                        writer.WriteAttributeString("type", "pageContextNode");
                        writer.WriteAttributeString("n", page.Page.ToString(CultureInfo.InvariantCulture));
                        writer.WriteStartElement("div");
                        writer.WriteAttributeString("type", "contextualCleanse");
                        writer.WriteStartElement("p");
                        writer.WriteString(page.ContextualCleanse ?? String.Empty);
                        writer.WriteEndElement();
                        writer.WriteEndElement();
                        writer.WriteStartElement("div");
                        writer.WriteAttributeString("type", "contextualTranslation");
                        writer.WriteStartElement("p");
                        writer.WriteString(page.Translation ?? String.Empty);
                        writer.WriteEndElement();
                        writer.WriteEndElement();
                        writer.WriteEndElement();
                    }
                }
                else if (!String.IsNullOrWhiteSpace(contextTranslation))
                {
                    writer.WriteStartElement("div");
                    writer.WriteAttributeString("type", "contextTranslation");
                    writer.WriteStartElement("p");
                    writer.WriteString(contextTranslation);
                    writer.WriteEndElement();
                    writer.WriteEndElement();
                }
                writer.WriteEndElement();
                writer.WriteEndElement();
                writer.WriteEndElement();
                writer.WriteEndDocument();
            }
        }

        public static void ExportAnalysis(string path, TextAnalysis analysis)
        {
            File.WriteAllText(path, TextAnalyzer.Format(analysis), new UTF8Encoding(true));
        }

        private static string Csv(string value)
        {
            return "\"" + (value ?? String.Empty).Replace("\"", "\"\"") + "\"";
        }
    }
}
