using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EScriptoriumStudio
{
    internal sealed class EnvironmentSnapshot
    {
        public bool IsWindows64 { get; set; }
        public bool WslInstalled { get; set; }
        public string WslVersion { get; set; }
        public bool DockerInstalled { get; set; }
        public bool DockerRunning { get; set; }
        public bool PortAvailable { get; set; }
        public bool ServiceReady { get; set; }
        public bool MemorySufficient { get; set; }
        public bool DiskSufficient { get; set; }
        public string ProcessorArchitecture { get; set; }
        public double MemoryGb { get; set; }
        public double FreeDiskGb { get; set; }
        public bool LocalStackRecommended { get; set; }
        public string DockerDesktopPath { get; set; }
        public string DockerCliPath { get; set; }

        public EnvironmentSnapshot()
        {
            WslVersion = String.Empty;
            DockerDesktopPath = String.Empty;
            DockerCliPath = String.Empty;
            ProcessorArchitecture = String.Empty;
        }
    }

    internal sealed class CommandResult
    {
        public int ExitCode { get; set; }
        public string StandardOutput { get; set; }
        public string StandardError { get; set; }
        public bool TimedOut { get; set; }

        public CommandResult()
        {
            StandardOutput = String.Empty;
            StandardError = String.Empty;
        }

        public string Combined
        {
            get
            {
                string text = (StandardOutput + Environment.NewLine + StandardError).Trim();
                return text.Replace("\r\n", "\n");
            }
        }
    }

    internal sealed class InstallerEngine
    {
        public const string ServiceUrl = "http://localhost:8080/";
        public const string HealthUrl = "http://localhost:8080/health";
        public const string DockerDownloadUrl = "https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe";
        public const string DockerTermsUrl = "https://www.docker.com/legal/docker-subscription-service-agreement/";
        public const string EscriptoriumDocsUrl = "https://gitlab.com/scripta/escriptorium/-/wikis/docker-install";

        private readonly Action<string> _logger;

        public InstallerEngine(Action<string> logger)
        {
            _logger = logger ?? delegate { };
        }

        public static bool IsAdministrator()
        {
            try
            {
                System.Security.Principal.WindowsIdentity identity =
                    System.Security.Principal.WindowsIdentity.GetCurrent();
                System.Security.Principal.WindowsPrincipal principal =
                    new System.Security.Principal.WindowsPrincipal(identity);
                return principal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
            }
            catch
            {
                return false;
            }
        }

        public static bool RelaunchElevated()
        {
            try
            {
                ProcessStartInfo start = new ProcessStartInfo(
                    System.Reflection.Assembly.GetEntryAssembly().Location,
                    "--auto-install");
                start.UseShellExecute = true;
                start.Verb = "runas";
                start.WorkingDirectory = AppPaths.Root;
                Process.Start(start);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<EnvironmentSnapshot> CheckAsync()
        {
            EnvironmentSnapshot snapshot = new EnvironmentSnapshot();
            snapshot.IsWindows64 = Environment.Is64BitOperatingSystem;
            snapshot.ProcessorArchitecture = Environment.GetEnvironmentVariable(
                "PROCESSOR_ARCHITECTURE") ?? String.Empty;
            snapshot.DockerDesktopPath = FindDockerDesktop();
            snapshot.DockerCliPath = FindDockerCli();
            snapshot.DockerInstalled = !String.IsNullOrEmpty(snapshot.DockerDesktopPath);
            snapshot.PortAvailable = IsPortAvailable(8080);

            CommandResult wsl = await RunAsync("wsl.exe", "--version", null, 12000, false).ConfigureAwait(false);
            snapshot.WslInstalled = wsl.ExitCode == 0 && !String.IsNullOrWhiteSpace(wsl.Combined);
            snapshot.WslVersion = FirstUsefulLine(wsl.Combined);

            if (!String.IsNullOrEmpty(snapshot.DockerCliPath))
            {
                CommandResult docker = await RunAsync(
                    snapshot.DockerCliPath,
                    "info --format {{.ServerVersion}}",
                    null,
                    10000,
                    false).ConfigureAwait(false);
                snapshot.DockerRunning = docker.ExitCode == 0;
            }

            snapshot.ServiceReady = await IsServiceReadyAsync(2500).ConfigureAwait(false);
            snapshot.MemoryGb = GetInstalledMemoryGb();
            snapshot.FreeDiskGb = GetFreeDiskGb();
            snapshot.MemorySufficient = snapshot.MemoryGb >= 7.5;
            snapshot.DiskSufficient = snapshot.FreeDiskGb >= 20;
            snapshot.LocalStackRecommended =
                snapshot.IsWindows64 &&
                snapshot.ProcessorArchitecture.IndexOf("ARM", StringComparison.OrdinalIgnoreCase) < 0 &&
                snapshot.MemorySufficient &&
                snapshot.DiskSufficient;
            return snapshot;
        }

        public async Task<bool> StartDockerAsync(Action<string> progress)
        {
            string desktop = FindDockerDesktop();
            if (String.IsNullOrEmpty(desktop))
                return false;

            if (!await IsDockerEngineReadyAsync().ConfigureAwait(false))
            {
                progress(L.T("Starting Docker Desktop...", "正在启动 Docker Desktop..."));
                TryStart(desktop, String.Empty, Path.GetDirectoryName(desktop));
            }

            DateTime deadline = DateTime.UtcNow.AddMinutes(5);
            while (DateTime.UtcNow < deadline)
            {
                if (await IsDockerEngineReadyAsync().ConfigureAwait(false))
                    return true;
                progress(L.T(
                    "Waiting for the Docker engine. First start can take a few minutes.",
                    "正在等待 Docker 引擎启动，首次启动可能需要几分钟。"));
                await Task.Delay(3500).ConfigureAwait(false);
            }
            return false;
        }

        public async Task SetupAllAsync(
            AppSettings settings,
            bool consent,
            Action<string> progress)
        {
            if (!consent)
                throw new InvalidOperationException(L.T(
                    "Docker terms consent is required before automatic installation.",
                    "自动安装前必须确认已阅读 Docker 服务条款。"));

            if (!Environment.Is64BitOperatingSystem)
                throw new InvalidOperationException(L.T(
                    "eScriptorium Studio requires 64-bit Windows.",
                    "eScriptorium Studio 需要 64 位 Windows。"));

            if (!IsPortAvailable(8080))
            {
                throw new InvalidOperationException(L.T(
                    "Port 8080 is already in use. Close the other service and retry.",
                    "端口 8080 已被占用。请关闭占用该端口的服务后重试。"));
            }

            AppPaths.EnsureDirectories();
            progress(L.T("Step 1/5 · Checking WSL 2", "步骤 1/5 · 检查 WSL 2"));
            CommandResult wsl = await RunAsync("wsl.exe", "--version", null, 15000, true).ConfigureAwait(false);
            if (wsl.ExitCode != 0)
            {
                progress(L.T(
                    "WSL 2 is not ready. Running the Microsoft installer; Windows may request a restart.",
                    "WSL 2 尚未就绪。正在调用 Microsoft 安装程序；Windows 可能要求重启。"));
                CommandResult installWsl = await RunAsync(
                    "wsl.exe",
                    "--install --no-distribution",
                    null,
                    1800000,
                    true).ConfigureAwait(false);
                if (installWsl.ExitCode != 0)
                {
                    throw new InvalidOperationException(L.T(
                        "WSL 2 installation did not complete. Restart Windows, open this app again, and choose Install & Start.",
                        "WSL 2 安装未完成。请重启 Windows 后再次打开本程序并选择“安装并启动”。"
                    ) + Environment.NewLine + Environment.NewLine + installWsl.Combined);
                }
            }

            progress(L.T("Step 2/5 · Preparing Docker Desktop", "步骤 2/5 · 准备 Docker Desktop"));
            string desktop = FindDockerDesktop();
            if (String.IsNullOrEmpty(desktop))
            {
                string installer = Path.Combine(AppPaths.DownloadsDirectory, "DockerDesktopInstaller.exe");
                if (!File.Exists(installer) || new FileInfo(installer).Length < 1000000)
                {
                    progress(L.T(
                        "Downloading the official Docker Desktop installer (about 600 MB)...",
                        "正在下载 Docker Desktop 官方安装程序（约 600 MB）..."));
                    await DownloadFileAsync(DockerDownloadUrl, installer, progress).ConfigureAwait(false);
                }

                progress(L.T(
                    "Installing Docker Desktop for all users. This can take several minutes.",
                    "正在为所有用户安装 Docker Desktop，这可能需要几分钟。"));
                CommandResult installDocker = await RunAsync(
                    installer,
                    "install --quiet --accept-license --backend=wsl-2",
                    Path.GetDirectoryName(installer),
                    1800000,
                    true).ConfigureAwait(false);
                if (installDocker.ExitCode != 0)
                {
                    throw new InvalidOperationException(L.T(
                        "Docker Desktop installation failed.",
                        "Docker Desktop 安装失败。") + Environment.NewLine + installDocker.Combined);
                }
                desktop = FindDockerDesktop();
            }

            if (String.IsNullOrEmpty(desktop))
                throw new InvalidOperationException(L.T(
                    "Docker Desktop was installed but its executable could not be found.",
                    "Docker Desktop 已安装，但未找到可执行文件。"));

            progress(L.T("Step 3/5 · Starting the Docker engine", "步骤 3/5 · 启动 Docker 引擎"));
            if (!await StartDockerAsync(progress).ConfigureAwait(false))
            {
                throw new InvalidOperationException(L.T(
                    "Docker is installed but its engine is not running. Open Docker Desktop, accept its first-run prompts, then retry.",
                    "Docker 已安装，但引擎尚未运行。请打开 Docker Desktop，完成首次启动提示后重试。"));
            }

            progress(L.T("Step 4/5 · Installing eScriptorium services", "步骤 4/5 · 安装 eScriptorium 服务"));
            settings.InstallDirectory = AppPaths.ServerDirectory;
            EnsureDeploymentFiles(settings);

            CommandResult compose = await RunDockerComposeAsync(settings,
                "pull",
                1800000,
                progress).ConfigureAwait(false);
            if (compose.ExitCode != 0)
                throw new InvalidOperationException(L.T(
                    "Could not download the eScriptorium container images.",
                    "无法下载 eScriptorium 容器镜像。") + Environment.NewLine + compose.Combined);

            compose = await RunDockerComposeAsync(settings,
                "up -d --remove-orphans",
                1800000,
                progress).ConfigureAwait(false);
            if (compose.ExitCode != 0)
                throw new InvalidOperationException(L.T(
                    "Docker Compose could not start eScriptorium.",
                    "Docker Compose 无法启动 eScriptorium。") + Environment.NewLine + compose.Combined);

            progress(L.T(
                "Step 5/5 · Waiting for http://localhost:8080/health",
                "步骤 5/5 · 等待 http://localhost:8080/health 就绪"));
            DateTime deadline = DateTime.UtcNow.AddMinutes(10);
            while (DateTime.UtcNow < deadline)
            {
                if (await IsServiceReadyAsync(2500).ConfigureAwait(false))
                {
                    settings.Save();
                    progress(L.T(
                        "eScriptorium is ready at http://localhost:8080/",
                        "eScriptorium 已就绪：http://localhost:8080/"));
                    return;
                }
                await Task.Delay(4000).ConfigureAwait(false);
            }

            throw new InvalidOperationException(L.T(
                "The containers started, but the web service did not become healthy in time. Inspect the log, then choose Start / Repair.",
                "容器已启动，但 Web 服务未在预期时间内就绪。请查看日志后选择“启动 / 修复”。"));
        }

        public async Task RepairAsync(AppSettings settings, Action<string> progress)
        {
            if (!await StartDockerAsync(progress).ConfigureAwait(false))
                throw new InvalidOperationException(L.T(
                    "Docker Desktop is not ready.",
                    "Docker Desktop 尚未就绪。"));

            EnsureDeploymentFiles(settings);
            CommandResult compose = await RunDockerComposeAsync(settings,
                "up -d --remove-orphans",
                900000,
                progress).ConfigureAwait(false);
            if (compose.ExitCode != 0)
                throw new InvalidOperationException(L.T(
                    "Could not start the eScriptorium containers.",
                    "无法启动 eScriptorium 容器。") + Environment.NewLine + compose.Combined);

            DateTime deadline = DateTime.UtcNow.AddMinutes(6);
            while (DateTime.UtcNow < deadline)
            {
                if (await IsServiceReadyAsync(2500).ConfigureAwait(false))
                {
                    progress(L.T("eScriptorium is online.", "eScriptorium 已在线。"));
                    return;
                }
                await Task.Delay(3000).ConfigureAwait(false);
            }
            throw new InvalidOperationException(L.T(
                "The service is still starting. Check the log and container status.",
                "服务仍在启动。请检查日志和容器状态。"));
        }

        public async Task StopAsync(AppSettings settings, Action<string> progress)
        {
            EnsureDeploymentFiles(settings);
            progress(L.T("Stopping the eScriptorium stack...", "正在停止 eScriptorium 服务..."));
            CommandResult result = await RunDockerComposeAsync(settings,
                "stop",
                180000,
                progress).ConfigureAwait(false);
            if (result.ExitCode != 0)
                throw new InvalidOperationException(result.Combined);
            progress(L.T("eScriptorium has stopped. Your data is preserved.", "eScriptorium 已停止，数据仍会保留。"));
        }

        public async Task<string> GetContainerStatusAsync(AppSettings settings)
        {
            if (String.IsNullOrEmpty(FindDockerCli()))
                return L.T("Docker CLI is unavailable.", "Docker CLI 不可用。");
            EnsureDeploymentFiles(settings);
            CommandResult result = await RunDockerComposeAsync(settings,
                "ps",
                30000,
                null).ConfigureAwait(false);
            return String.IsNullOrWhiteSpace(result.Combined)
                ? L.T("No eScriptorium containers are running.", "没有正在运行的 eScriptorium 容器。")
                : result.Combined;
        }

        public void EnsureDeploymentFiles(AppSettings settings)
        {
            AppPaths.EnsureDirectories();
            Directory.CreateDirectory(settings.InstallDirectory);
            WriteDeploymentFiles(settings, settings.InstallDirectory);
            settings.Save();
        }

        internal static void WriteDeploymentFiles(AppSettings settings, string directory)
        {
            Directory.CreateDirectory(directory);
            string composePath = Path.Combine(directory, "docker-compose.yml");
            string envPath = Path.Combine(directory, "variables.env");
            File.WriteAllText(composePath, ComposeYaml, new UTF8Encoding(false));

            if (!File.Exists(envPath))
            {
                if (String.IsNullOrEmpty(settings.GetEscriptoriumPassword()))
                    settings.SetEscriptoriumPassword(RandomSecret(18));
                File.WriteAllText(envPath, BuildVariablesEnv(settings), new UTF8Encoding(false));
            }
            else if (String.IsNullOrEmpty(settings.GetEscriptoriumPassword()))
            {
                string password = ReadEnvValue(envPath, "DJANGO_SU_PASSWORD");
                if (!String.IsNullOrEmpty(password))
                    settings.SetEscriptoriumPassword(password);
            }
        }

        public void OpenService()
        {
            Process.Start(new ProcessStartInfo(ServiceUrl) { UseShellExecute = true });
        }

        public void OpenUploads()
        {
            Process.Start(new ProcessStartInfo(ServiceUrl) { UseShellExecute = true });
        }

        public void OpenFolder()
        {
            AppPaths.EnsureDirectories();
            Process.Start(new ProcessStartInfo(AppPaths.Root) { UseShellExecute = true });
        }

        public static string FindDockerDesktop()
        {
            string[] candidates =
            {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Docker", "Docker", "Docker Desktop.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "DockerDesktop", "Docker Desktop.exe")
            };
            return candidates.FirstOrDefault(File.Exists) ?? String.Empty;
        }

        public static string FindDockerCli()
        {
            string[] candidates =
            {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Docker", "Docker", "resources", "bin", "docker.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "DockerDesktop", "resources", "bin", "docker.exe")
            };
            string found = candidates.FirstOrDefault(File.Exists);
            if (!String.IsNullOrEmpty(found))
                return found;

            string path = Environment.GetEnvironmentVariable("PATH") ?? String.Empty;
            foreach (string part in path.Split(Path.PathSeparator))
            {
                try
                {
                    string candidate = Path.Combine(part.Trim(), "docker.exe");
                    if (File.Exists(candidate))
                        return candidate;
                }
                catch
                {
                }
            }
            return String.Empty;
        }

        private async Task<CommandResult> RunDockerComposeAsync(
            AppSettings settings,
            string arguments,
            int timeoutMs,
            Action<string> progress)
        {
            string docker = FindDockerCli();
            if (String.IsNullOrEmpty(docker))
                return new CommandResult { ExitCode = 127, StandardError = "docker.exe not found" };

            string fullArguments = "--context default compose --project-name escriptorium-studio --file \""
                + Path.Combine(settings.InstallDirectory, "docker-compose.yml") + "\" " + arguments;
            if (progress != null)
            {
                progress(L.T(
                    "docker " + fullArguments,
                    "正在执行 docker " + fullArguments));
            }
            return await RunAsync(
                docker,
                fullArguments,
                settings.InstallDirectory,
                timeoutMs,
                true).ConfigureAwait(false);
        }

        private async Task<CommandResult> RunAsync(
            string fileName,
            string arguments,
            string workingDirectory,
            int timeoutMs,
            bool echoOutput)
        {
            return await Task.Run(() =>
            {
                CommandResult result = new CommandResult();
                try
                {
                    ProcessStartInfo start = new ProcessStartInfo();
                    start.FileName = fileName;
                    start.Arguments = arguments;
                    start.UseShellExecute = false;
                    start.CreateNoWindow = true;
                    start.RedirectStandardOutput = true;
                    start.RedirectStandardError = true;
                    start.WindowStyle = ProcessWindowStyle.Hidden;
                    if (!String.IsNullOrEmpty(workingDirectory))
                        start.WorkingDirectory = workingDirectory;

                    using (Process process = new Process())
                    {
                        process.StartInfo = start;
                        process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e)
                        {
                            if (e.Data != null)
                            {
                                lock (result)
                                    result.StandardOutput += e.Data + Environment.NewLine;
                                if (echoOutput && !String.IsNullOrWhiteSpace(e.Data))
                                    _logger(e.Data);
                            }
                        };
                        process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e)
                        {
                            if (e.Data != null)
                            {
                                lock (result)
                                    result.StandardError += e.Data + Environment.NewLine;
                                if (echoOutput && !String.IsNullOrWhiteSpace(e.Data))
                                    _logger(e.Data);
                            }
                        };
                        process.Start();
                        process.BeginOutputReadLine();
                        process.BeginErrorReadLine();
                        if (!process.WaitForExit(timeoutMs))
                        {
                            result.TimedOut = true;
                            try { process.Kill(); } catch { }
                        }
                        else
                        {
                            process.WaitForExit();
                        }
                        result.ExitCode = result.TimedOut ? 124 : process.ExitCode;
                    }
                }
                catch (Exception ex)
                {
                    result.ExitCode = 126;
                    result.StandardError = ex.Message;
                }
                return result;
            }).ConfigureAwait(false);
        }

        private async Task DownloadFileAsync(string url, string target, Action<string> progress)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            Directory.CreateDirectory(Path.GetDirectoryName(target));
            DateTime lastReport = DateTime.MinValue;
            using (WebClient client = new WebClient())
            {
                client.Headers[HttpRequestHeader.UserAgent] = "eScriptorium-Studio-Setup/1.0";
                client.DownloadProgressChanged += delegate(object sender, DownloadProgressChangedEventArgs e)
                {
                    if ((DateTime.UtcNow - lastReport).TotalSeconds > 1.5)
                    {
                        lastReport = DateTime.UtcNow;
                        progress(String.Format(
                            L.T("Docker download: {0:0.0} MB / {1:0.0} MB ({2}%)",
                                "Docker 下载：{0:0.0} MB / {1:0.0} MB（{2}%）"),
                            e.BytesReceived / 1048576.0,
                            e.TotalBytesToReceive / 1048576.0,
                            e.ProgressPercentage));
                    }
                };
                await client.DownloadFileTaskAsync(new Uri(url), target).ConfigureAwait(false);
            }
        }

        private async Task<bool> IsDockerEngineReadyAsync()
        {
            string docker = FindDockerCli();
            if (String.IsNullOrEmpty(docker))
                return false;
            CommandResult result = await RunAsync(
                docker,
                "info --format {{.ServerVersion}}",
                null,
                7000,
                false).ConfigureAwait(false);
            return result.ExitCode == 0;
        }

        public async Task<bool> IsServiceReadyAsync(int timeoutMs)
        {
            bool healthReady = await Task.Run(() =>
            {
                try
                {
                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(HealthUrl);
                    request.Timeout = timeoutMs;
                    request.ReadWriteTimeout = timeoutMs;
                    request.Method = "GET";
                    request.Proxy = null;
                    using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                        return (int)response.StatusCode >= 200 && (int)response.StatusCode < 400;
                }
                catch
                {
                    return false;
                }
            }).ConfigureAwait(false);
            if (healthReady)
                return true;

            return await Task.Run(() =>
            {
                try
                {
                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ServiceUrl);
                    request.Timeout = timeoutMs;
                    request.ReadWriteTimeout = timeoutMs;
                    request.Method = "GET";
                    request.Proxy = null;
                    using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                        return (int)response.StatusCode >= 200 && (int)response.StatusCode < 400;
                }
                catch
                {
                    return false;
                }
            }).ConfigureAwait(false);
        }

        private static bool IsPortAvailable(int port)
        {
            try
            {
                return !IPGlobalProperties.GetIPGlobalProperties()
                    .GetActiveTcpListeners()
                    .Any(endpoint => endpoint.Port == port);
            }
            catch
            {
                return true;
            }
        }

        private static double GetInstalledMemoryGb()
        {
            try
            {
                return new Microsoft.VisualBasic.Devices.ComputerInfo().TotalPhysicalMemory / 1073741824.0;
            }
            catch
            {
                return 8;
            }
        }

        private static double GetFreeDiskGb()
        {
            try
            {
                DriveInfo drive = new DriveInfo(Path.GetPathRoot(AppPaths.Root));
                return drive.AvailableFreeSpace / 1073741824.0;
            }
            catch
            {
                return 20;
            }
        }

        private static string FirstUsefulLine(string text)
        {
            if (String.IsNullOrWhiteSpace(text))
                return String.Empty;
            string line = text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(value => value.Trim())
                .FirstOrDefault(value => value.Length > 0);
            return line ?? String.Empty;
        }

        private static void TryStart(string fileName, string arguments, string workingDirectory)
        {
            try
            {
                ProcessStartInfo start = new ProcessStartInfo(fileName, arguments);
                start.UseShellExecute = true;
                start.WindowStyle = ProcessWindowStyle.Normal;
                if (!String.IsNullOrEmpty(workingDirectory))
                    start.WorkingDirectory = workingDirectory;
                Process.Start(start);
            }
            catch (Exception ex)
            {
                AppPaths.Log("Could not start Docker Desktop: " + ex.Message);
            }
        }

        private static string RandomSecret(int length)
        {
            const string alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
            byte[] bytes = new byte[length];
            using (RandomNumberGenerator rng = RandomNumberGenerator.Create())
                rng.GetBytes(bytes);
            StringBuilder value = new StringBuilder(length);
            foreach (byte b in bytes)
                value.Append(alphabet[b % alphabet.Length]);
            return value.ToString();
        }

        private static string ReadEnvValue(string path, string key)
        {
            try
            {
                foreach (string raw in File.ReadAllLines(path, Encoding.UTF8))
                {
                    string line = raw.Trim();
                    if (line.StartsWith(key + "=", StringComparison.Ordinal))
                        return line.Substring(key.Length + 1).Trim();
                }
            }
            catch
            {
            }
            return String.Empty;
        }

        private static string BuildVariablesEnv(AppSettings settings)
        {
            string password = settings.GetEscriptoriumPassword();
            if (String.IsNullOrEmpty(password))
            {
                password = RandomSecret(18);
                settings.SetEscriptoriumPassword(password);
            }
            string secret = RandomSecret(64);
            StringBuilder env = new StringBuilder();
            env.AppendLine("DOMAIN=localhost");
            env.AppendLine("SECRET_KEY=" + secret);
            env.AppendLine("CSRF_TRUSTED_ORIGINS=http://localhost:8080");
            env.AppendLine("SITE_NAME=eScriptorium Studio");
            env.AppendLine("REDIS_HOST=redis");
            env.AppendLine("SQL_HOST=db");
            env.AppendLine("SQL_PORT=5432");
            env.AppendLine("POSTGRES_USER=postgres");
            env.AppendLine("POSTGRES_PASSWORD=" + RandomSecret(24));
            env.AppendLine("POSTGRES_DB=escriptorium");
            env.AppendLine("DJANGO_SU_NAME=" + settings.AdminUser);
            env.AppendLine("DJANGO_SU_EMAIL=admin@localhost");
            env.AppendLine("DJANGO_SU_PASSWORD=" + password);
            env.AppendLine("DJANGO_FROM_EMAIL=noreply@localhost");
            env.AppendLine("FLOWER_BASIC_AUTH=flower:" + RandomSecret(18));
            env.AppendLine("DISABLE_ES_SEARCH=True");
            env.AppendLine("CELERY_MAIN_CONC=2");
            env.AppendLine("CELERY_LIVE_CONC=2");
            env.AppendLine("CELERY_LOW_CONC=1");
            env.AppendLine("KRAKEN_TRAINING_DEVICE=cpu");
            env.AppendLine("KRAKEN_INFERENCE_DEVICE=cpu");
            return env.ToString();
        }

        private const string ComposeYaml = @"name: escriptorium-studio

x-app:
  &app
  image: registry.gitlab.com/scripta/escriptorium:latest
  env_file: variables.env
  volumes:
    - static:/usr/src/app/static
    - media:/usr/src/app/media
  restart: always
  command: /bin/true

services:
  web:
    <<: *app
    command: uwsgi --ini /usr/src/app/uwsgi.ini
    expose:
      - 8000
    healthcheck:
      test: [""CMD"", ""curl"", ""-f"", ""http://localhost:8000/health""]
      interval: 30s
      timeout: 5s
      retries: 5
      start_period: 90s

  channelserver:
    <<: *app
    command: daphne --bind 0.0.0.0 --port 5000 -v 1 escriptorium.asgi:application
    expose:
      - 5000

  db:
    image: docker.io/library/postgres:15
    volumes:
      - postgres:/var/lib/postgresql/data/
    env_file: variables.env
    restart: always

  redis:
    image: docker.io/redis:alpine
    restart: always

  nginx:
    image: registry.gitlab.com/scripta/escriptorium/nginx
    environment:
      - SERVERNAME=${DOMAIN:-localhost}
    volumes:
      - static:/usr/src/app/static
      - media:/usr/src/app/media
    ports:
      - ""127.0.0.1:8080:80""
    healthcheck:
      test: [""CMD"", ""curl"", ""-f"", ""http://localhost/health""]
      interval: 30s
      timeout: 5s
      retries: 5
      start_period: 20s
    restart: always

  celery-main:
    <<: *app
    environment:
      - OMP_NUM_THREADS=1
    command: celery -A escriptorium worker -l INFO -E -Ofair --prefetch-multiplier 1 -Q default -c ${CELERY_MAIN_CONC:-2} --max-tasks-per-child=10

  celery-live:
    <<: *app
    command: celery -A escriptorium worker -l INFO -E -Ofair --prefetch-multiplier 1 -Q live -c ${CELERY_LIVE_CONC:-2} --max-tasks-per-child=10

  celery-low-priority:
    <<: *app
    command: celery -A escriptorium worker -l INFO -E -Ofair --prefetch-multiplier 1 -Q low-priority -c ${CELERY_LOW_CONC:-1} --max-tasks-per-child=10

  celery-gpu:
    <<: *app
    environment:
      - KRAKEN_TRAINING_DEVICE=cpu
    command: celery -A escriptorium worker -l INFO -E -Ofair --prefetch-multiplier 1 -Q gpu -c 1 --max-tasks-per-child=1
    shm_size: '3gb'

  celery-intensive-inference:
    <<: *app
    environment:
      - KRAKEN_INFERENCE_DEVICE=cpu
    command: celery -A escriptorium worker -l INFO -E -Ofair --prefetch-multiplier 1 -Q intensive-inference -c 1 --max-tasks-per-child=1
    shm_size: '3gb'

  flower:
    image: docker.io/mher/flower
    command: [""celery"", ""--broker=redis://redis:6379/0"", ""flower"", ""--port=5555""]
    ports:
      - ""127.0.0.1:5555:5555""
    restart: always

  mail:
    image: registry.gitlab.com/scripta/escriptorium/mail
    expose:
      - 25
    environment:
      - PRIMARY_HOST=${DOMAIN:-localhost}
      - ALLOWED_HOSTS=web;celery-main;celery-low-priority;docker0
    restart: always

volumes:
  static:
  media:
  postgres:
";
    }
}
