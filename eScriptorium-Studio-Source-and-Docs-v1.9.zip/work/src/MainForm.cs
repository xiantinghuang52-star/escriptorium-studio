using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace EScriptoriumStudio
{
    internal sealed class MainForm : Form
    {
        private readonly AppSettings _settings;
        private readonly InstallerEngine _engine;
        private readonly AiTranslationService _ai;
        private EnvironmentSnapshot _environment;
        private readonly Dictionary<string, Button> _navButtons = new Dictionary<string, Button>();
        private Panel _content;
        private Label _headerStatus;
        private Label _headerSubtitle;
        private Label _footerLabel;
        private Button _englishButton;
        private Button _chineseButton;
        private string _page = "home";
        private bool _busy;
        private CancellationTokenSource _busyCancellation;
        private readonly bool _autoInstall;

        private TextBox _installLog;
        private ProgressBar _installProgress;
        private CheckBox _dockerConsent;
        private Label _installStatus;
        private Label _compatibilityLabel;

        private List<TranscriptionLine> _lines = new List<TranscriptionLine>();
        private BindingList<TranscriptionLine> _lineBinding;
        private DataGridView _linesGrid;
        private TextBox _detailOriginal;
        private TextBox _detailCleaned;
        private TextBox _detailTranslation;
        private Label _detailCoordinates;
        private Label _studioStats;
        private Label _studioStatus;
        private TextBox _analysisText;
        private TextAnalysis _analysis;
        private ContextTranslationResult _contextTranslation;
        private TextBox _contextTranslationBox;
        private TextBox _contextCleanseBox;
        private Label _contextTranslationStatus;
        private TabControl _studioTabs;
        private TabControl _contextOutputTabs;

        private ProcessingProject _processingProject;
        private DataGridView _groupsGrid;
        private TextBox _groupNameBox;
        private TextBox _groupPagesBox;
        private TextBox _groupTargetBox;
        private ComboBox _groupConcurrencyBox;
        private Label _groupsStatusLabel;
        private TextBox _groupOutputBox;
        private Button _groupPauseButton;
        private bool _groupPaused;
        private CancellationTokenSource _groupCancellation;
        private bool _groupBusy;
        private bool _selectingGroupRow;

        private readonly List<string> _ocrFiles = new List<string>();
        private ComboBox _ocrBackendBox;
        private TextBox _ocrEndpointBox;
        private Label _ocrEndpointLabel;
        private ComboBox _ocrLanguageBox;
        private Label _ocrLanguageLabel;
        private ComboBox _ocrParserBox;
        private Label _ocrParserLabel;
        private ComboBox _ocrPdfModeBox;
        private TextBox _ocrPdfPagesBox;
        private TextBox _umiPathBox;
        private Label _umiPathLabel;
        private TextBox _tesseractPathBox;
        private Label _tesseractPathLabel;
        private TextBox _tesseractLanguageBox;
        private Label _tesseractLanguageLabel;
        private PictureBox _ocrPreview;
        private Image _ocrPreviewImage;
        private Label _ocrStatusLabel;
        private ListBox _ocrFilesList;
        private TextBox _ocrHelpBox;
        private Button _ocrRunButton;

        private WebView2 _mirrorView;
        private ComboBox _htrModelBox;
        private ComboBox _transcriptionBox;
        private Label _mirrorStatusLabel;
        private EscriptoriumApiClient _escriptoriumApi;
        private int? _mirrorDocumentId;

        private TextBox _aiEndpoint;
        private TextBox _aiKey;
        private TextBox _aiModel;
        private TextBox _sourceLanguage;
        private TextBox _targetLanguage;
        private ComboBox _pageConcurrencyBox;
        private CheckBox _showSecrets;
        private Label _passwordValue;
        private Label _dockerStatusLabel;
        private Label _serviceStatusLabel;

        public MainForm(bool autoInstall)
        {
            _autoInstall = autoInstall;
            _settings = AppSettings.Load();
            _engine = new InstallerEngine(AppendLog);
            _ai = new AiTranslationService();
            BuildShell();
            ShowPage("home");
        }

        private void BuildShell()
        {
            Text = L.T("eScriptorium Studio · EN / 中文", "eScriptorium 手稿工作台 · EN / 中文");
            BackColor = Palette.Parchment;
            ForeColor = Palette.Ink;
            Font = Ui.Body;
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(900, 600);
            ClientSize = new Size(1180, 760);
            AutoScaleMode = AutoScaleMode.Dpi;
            KeyPreview = true;
            AllowDrop = true;
            DragEnter += FormDragEnter;
            DragDrop += FormDragDrop;

            TopAccentPanel header = new TopAccentPanel();
            header.Dock = DockStyle.Top;
            header.Height = 94;
            Controls.Add(header);

            Label logo = new Label();
            logo.Text = "E";
            logo.TextAlign = ContentAlignment.MiddleCenter;
            logo.Font = new Font(Ui.Display.FontFamily, 22f, FontStyle.Bold);
            logo.ForeColor = Color.White;
            logo.BackColor = Palette.Accent;
            logo.SetBounds(24, 22, 49, 49);
            header.Controls.Add(logo);

            Label title = Ui.Label("eScriptorium Studio", Ui.Heading, Color.White, 500);
            title.SetBounds(88, 18, 460, 36);
            header.Controls.Add(title);

            _headerSubtitle = Ui.Label(
                L.T("Early modern manuscript lab · install, transcribe, align, translate",
                    "早期现代手稿实验室 · 安装、转录、坐标对齐与翻译"),
                Ui.BodySmall,
                Color.FromArgb(203, 214, 217),
                680);
            _headerSubtitle.SetBounds(89, 53, 720, 24);
            header.Controls.Add(_headerSubtitle);

            _headerStatus = Ui.Label("", Ui.BodyBold, Color.FromArgb(222, 231, 233), 220);
            _headerStatus.TextAlign = ContentAlignment.MiddleRight;
            _headerStatus.SetBounds(915, 28, 245, 28);
            _headerStatus.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            header.Controls.Add(_headerStatus);

            _englishButton = LanguageButton("EN");
            _englishButton.SetBounds(1062, 22, 54, 29);
            _englishButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _englishButton.Click += delegate { SetLanguage(false); };
            header.Controls.Add(_englishButton);

            _chineseButton = LanguageButton("中文");
            _chineseButton.SetBounds(1120, 22, 62, 29);
            _chineseButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _chineseButton.Click += delegate { SetLanguage(true); };
            header.Controls.Add(_chineseButton);

            Panel body = new Panel();
            body.Dock = DockStyle.None;
            body.SetBounds(0, header.Height, ClientSize.Width, Math.Max(0, ClientSize.Height - header.Height));
            body.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            body.BackColor = Palette.Parchment;
            Controls.Add(body);

            Panel sidebar = new Panel();
            sidebar.Dock = DockStyle.Left;
            sidebar.Width = 222;
            sidebar.BackColor = Palette.Deep;
            sidebar.Padding = new Padding(16, 24, 16, 18);
            body.Controls.Add(sidebar);

            Button home = NavButton("◆  " + L.T("Overview", "总览"), "home");
            home.Top = 18;
            Button install = NavButton("▦  " + L.T("Install & run", "安装与运行"), "install");
            install.Top = 70;
            Button studio = NavButton("⌁  " + L.T("Manuscript studio", "手稿工作台"), "studio");
            studio.Top = 122;
            Button ocr = NavButton("▧  " + L.T("Printed OCR", "印刷文本 OCR"), "ocr");
            ocr.Top = 174;
            Button mirror = NavButton("◉  " + L.T("eScriptorium mirror", "eScriptorium 镜像"), "mirror");
            mirror.Top = 226;
            Button groups = NavButton("▤  " + L.T("Processing groups", "分组处理"), "groups");
            groups.Top = 278;
            Button settings = NavButton("⚙  " + L.T("Settings", "设置"), "settings");
            settings.Top = 330;
            sidebar.Controls.Add(home);
            sidebar.Controls.Add(install);
            sidebar.Controls.Add(studio);
            sidebar.Controls.Add(ocr);
            sidebar.Controls.Add(mirror);
            sidebar.Controls.Add(groups);
            sidebar.Controls.Add(settings);

            _footerLabel = Ui.Label(
                "LOCAL WORKSPACE\n" + L.T("Data remains on this computer", "数据保存在本机"),
                Ui.BodySmall,
                Color.FromArgb(158, 178, 184),
                180);
            _footerLabel.SetBounds(20, 0, 180, 48);
            _footerLabel.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            _footerLabel.Top = sidebar.ClientSize.Height - 54;
            sidebar.Controls.Add(_footerLabel);
            sidebar.Resize += delegate { _footerLabel.Top = sidebar.ClientSize.Height - 62; };

            _content = new Panel();
            _content.Dock = DockStyle.Fill;
            _content.BackColor = Palette.Parchment;
            _content.Padding = new Padding(28, 24, 26, 28);
            _content.AutoScroll = true;
            body.Controls.Add(_content);
            _content.BringToFront();
            header.BringToFront();

            UpdateLanguageButtons();
        }

        private Button LanguageButton(string text)
        {
            Button button = new Button();
            button.Text = text;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 1;
            button.FlatAppearance.BorderColor = Color.FromArgb(103, 129, 135);
            button.FlatAppearance.MouseOverBackColor = Palette.Deep2;
            button.BackColor = Palette.Deep;
            button.ForeColor = Color.White;
            button.Font = Ui.BodySmall;
            button.Cursor = Cursors.Hand;
            return button;
        }

        private Button NavButton(string text, string key)
        {
            Button button = new Button();
            button.Text = text;
            button.TextAlign = ContentAlignment.MiddleLeft;
            button.Padding = new Padding(14, 0, 0, 0);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.FlatAppearance.MouseOverBackColor = Palette.Deep2;
            button.BackColor = Palette.Deep;
            button.ForeColor = Color.FromArgb(202, 215, 219);
            button.Font = Ui.BodyBold;
            button.UseMnemonic = false;
            button.Cursor = Cursors.Hand;
            button.SetBounds(0, 0, 190, 43);
            button.Click += delegate { ShowPage(key); };
            _navButtons[key] = button;
            return button;
        }

        private void ShowPage(string key)
        {
            if (_page == "settings" && key != "settings")
                CaptureSettingsFromControls(false);
            if (_page == "studio" && _contextTranslationBox != null && !_contextTranslationBox.IsDisposed)
            {
                if (_contextTranslation == null)
                    _contextTranslation = new ContextTranslationResult();
                _contextTranslation.Translation = _contextTranslationBox.Text;
                if (_contextCleanseBox != null && !_contextCleanseBox.IsDisposed)
                    _contextTranslation.CleanseText = _contextCleanseBox.Text;
            }
            if (_page == "mirror" && key != "mirror" && _mirrorView != null)
            {
                _mirrorView.Dispose();
                _mirrorView = null;
            }
            _page = key;
            foreach (KeyValuePair<string, Button> pair in _navButtons)
            {
                pair.Value.BackColor = pair.Key == key ? Palette.Deep2 : Palette.Deep;
                pair.Value.ForeColor = pair.Key == key ? Color.White : Color.FromArgb(202, 215, 219);
            }

            _content.SuspendLayout();
            _content.Controls.Clear();
            Control page = null;
            bool isFillPage = key == "studio" || key == "groups" ||
                key == "mirror" || key == "ocr";
            if (key == "home")
                page = BuildHomePage();
            else if (key == "install")
                page = BuildInstallPage();
            else if (key == "studio")
                page = BuildStudioPage();
            else if (key == "ocr")
                page = BuildPrintedOcrPage();
            else if (key == "groups")
                page = BuildGroupsPage();
            else if (key == "mirror")
                page = BuildMirrorPage();
            else
                page = BuildSettingsPage();
            if (!isFillPage)
                page = ScrollingPage(page);
            page.Dock = DockStyle.Fill;
            _content.Controls.Add(page);
            _content.ResumeLayout();
            RefreshEnvironmentLabels();
        }

        private Control BuildHomePage()
        {
            TableLayoutPanel root = VerticalRoot();
            AddFixedRows(root, 220, 84, 158, 168);

            RoundedPanel hero = new RoundedPanel();
            hero.FillColor = Palette.Deep;
            hero.BorderColor = Palette.Deep;
            hero.Dock = DockStyle.Fill;
            hero.MinimumSize = new Size(0, 198);
            hero.Margin = new Padding(0, 0, 0, 18);
            hero.Padding = new Padding(28, 24, 28, 22);

            Label eyebrow = Ui.Label(
                L.T("FROM A BLANK WINDOWS PC", "从一台全新的 WINDOWS 电脑开始"),
                Ui.BodySmall,
                Palette.Gold,
                700);
            eyebrow.Font = new Font(Ui.BodySmall.FontFamily, 8.5f, FontStyle.Bold);
            eyebrow.SetBounds(28, 23, 650, 20);
            hero.Controls.Add(eyebrow);

            Label headline = Ui.Label(
                L.T("A working eScriptorium lab in one guided setup.",
                    "一次引导，完成 eScriptorium 手稿实验室部署。"),
                new Font(Ui.Heading.FontFamily, 21f, FontStyle.Bold),
                Color.White,
                780);
            headline.SetBounds(26, 48, 790, 70);
            hero.Controls.Add(headline);

            Label description = Ui.Label(
                L.T(
                    "Install WSL 2 and Docker Desktop, launch eScriptorium on localhost:8080, then import ALTO / PAGE XML to clean, translate by line, and analyze early modern European text.",
                    "自动安装 WSL 2 与 Docker Desktop，在 localhost:8080 启动 eScriptorium；随后可导入 ALTO / PAGE XML，逐行清洗、按坐标对照翻译并分析早期现代欧洲语言文本。"),
                Ui.Body,
                Color.FromArgb(215, 225, 227),
                810);
            description.SetBounds(28, 111, 810, 58);
            hero.Controls.Add(description);

            Button start = Ui.Button(L.T("Start guided install", "开始一键安装"), true);
            start.SetBounds(28, 159, 168, 37);
            start.Click += delegate { ShowPage("install"); };
            hero.Controls.Add(start);

            Button open = Ui.Button(L.T("Open eScriptorium", "打开 eScriptorium"), false);
            open.BackColor = Palette.Deep2;
            open.ForeColor = Color.White;
            open.FlatAppearance.BorderColor = Color.FromArgb(78, 106, 113);
            open.FlatAppearance.MouseOverBackColor = Color.FromArgb(31, 66, 79);
            open.SetBounds(208, 159, 165, 37);
            open.Click += delegate { _engine.OpenService(); };
            hero.Controls.Add(open);
            root.Controls.Add(hero, 0, 0);

            root.Controls.Add(SectionTitle(
                L.T("Workspace readiness", "工作区状态"),
                L.T("Checks are read-only until you choose an install or repair action.",
                    "在您选择安装或修复前，所有检查均为只读操作。")), 0, 1);

            TableLayoutPanel cards = new TableLayoutPanel();
            cards.Dock = DockStyle.Fill;
            cards.Height = 142;
            cards.ColumnCount = 3;
            cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.333f));
            cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.333f));
            cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.334f));
            cards.RowCount = 1;
            cards.Margin = new Padding(0, 0, 0, 20);
            cards.Controls.Add(StatusCard(
                "DOCKER",
                _environment == null ? L.T("Checking…", "检查中…") :
                    (_environment.DockerRunning ? L.T("Running", "运行中") :
                        (_environment.DockerInstalled ? L.T("Needs start", "需要启动") : L.T("Not installed", "未安装"))),
                _environment != null && _environment.DockerRunning,
                L.T("Linux container engine used by eScriptorium.",
                    "eScriptorium 使用的 Linux 容器引擎。")), 0, 0);
            cards.Controls.Add(StatusCard(
                "ESCRIPTORIUM",
                _environment == null ? L.T("Checking…", "检查中…") :
                    (_environment.ServiceReady ? L.T("Ready on :8080", ":8080 已就绪") : L.T("Not online", "尚未在线")),
                _environment != null && _environment.ServiceReady,
                L.T("Local web application; upload and transcription stay on this machine.",
                    "本地 Web 应用；上传与转录数据保存在本机。")), 1, 0);
            cards.Controls.Add(StatusCard(
                "AI TRANSLATION",
                _ai.IsConfigured(_settings) ? L.T("Configured", "已配置") : L.T("Key not set", "尚未设置密钥"),
                _ai.IsConfigured(_settings),
                L.T("Uses your OpenAI-compatible endpoint. You can work locally without it.",
                    "使用您自己的 OpenAI 兼容接口；不配置也可使用本地清洗与分析。")), 2, 0);
            root.Controls.Add(cards, 0, 2);

            RoundedPanel workflow = new RoundedPanel();
            workflow.Dock = DockStyle.Fill;
            workflow.MinimumSize = new Size(0, 145);
            workflow.Margin = new Padding(0);
            Label workflowTitle = Ui.Label(
                L.T("A coordinate-aware research workflow", "带坐标信息的研究工作流"),
                Ui.Heading,
                Palette.Ink,
                700);
            workflowTitle.SetBounds(20, 16, 700, 32);
            workflow.Controls.Add(workflowTitle);
            AddWorkflowStep(workflow, 20, 67, "01", L.T("Upload images", "上传图像"),
                L.T("Open eScriptorium and create a document.", "打开 eScriptorium 并创建文档。"));
            AddWorkflowStep(workflow, 235, 67, "02", L.T("Recognize", "文字识别"),
                L.T("Choose segmentation and HTR models; they are not auto-selected.",
                    "请自行选择区域检测与 HTR 模型，软件不会自动替您选择。"));
            AddWorkflowStep(workflow, 450, 67, "03", L.T("Export coordinates", "导出坐标"),
                L.T("Use ALTO XML or PAGE XML from eScriptorium.", "从 eScriptorium 导出 ALTO/PAGE XML。"));
            AddWorkflowStep(workflow, 665, 67, "04", L.T("Clean + translate", "清洗与翻译"),
                L.T("Use your own API key; lines stay anchored to boxes.",
                    "使用您自己的 API Key；每行保持原坐标框。"));
            root.Controls.Add(workflow, 0, 3);
            return root;
        }

        private Control BuildInstallPage()
        {
            TableLayoutPanel root = VerticalRoot();
            AddFixedRows(root, 84, 282, 232, 270);
            root.Controls.Add(SectionTitle(
                L.T("Install and run", "安装与运行"),
                L.T("One guided path from Windows prerequisites to a healthy localhost:8080 service.",
                    "从 Windows 前置条件到 localhost:8080 健康运行的一条引导路径。")), 0, 0);

            RoundedPanel stages = new RoundedPanel();
            stages.Dock = DockStyle.Fill;
            stages.MinimumSize = new Size(0, 266);
            stages.Margin = new Padding(0, 0, 0, 14);
            stages.Padding = new Padding(22, 15, 22, 15);
            bool wslOk = _environment != null && _environment.WslInstalled;
            bool dockerOk = _environment != null && _environment.DockerRunning;
            bool serviceOk = _environment != null && _environment.ServiceReady;
            AddStage(stages, 1, L.T("WSL 2", "WSL 2"),
                wslOk ? L.T("WSL 2 ready", "WSL 2 已就绪") :
                    L.T("Ready to install / repair", "可安装或修复"),
                wslOk);
            AddStage(stages, 2, "Docker Desktop",
                dockerOk ? L.T("Engine running", "引擎运行中") :
                    (_environment != null && _environment.DockerInstalled ?
                        L.T("Installed; engine stopped", "已安装；引擎未运行") :
                        L.T("Will download official installer", "将下载官方安装程序")),
                dockerOk);
            AddStage(stages, 3, L.T("eScriptorium containers", "eScriptorium 容器"),
                L.T("Pinned Compose stack, port 8080 bound to localhost only",
                    "固定 Compose 配置，8080 仅绑定本机"), false);
            AddStage(stages, 4, L.T("Health and browser", "健康检查与浏览器"),
                serviceOk ? L.T("Healthy at localhost:8080", "localhost:8080 状态正常") :
                    L.T("Verifies /health before opening", "在打开前验证 /health"),
                serviceOk);
            AddStage(stages, 5, L.T("Research workspace", "研究工作台"),
                L.T("Credentials, ALTO/PAGE import and bilingual exports",
                    "登录凭据、ALTO/PAGE 导入与双语导出"), false);
            root.Controls.Add(stages, 0, 1);

            RoundedPanel controls = new RoundedPanel();
            controls.Dock = DockStyle.Fill;
            controls.MinimumSize = new Size(0, 124);
            controls.Margin = new Padding(0, 0, 0, 14);
            _dockerConsent = new CheckBox();
            _dockerConsent.Text = L.T(
                "I have reviewed and accept the Docker Subscription Service Agreement.",
                "我已阅读并接受 Docker 订阅服务协议。");
            _dockerConsent.Font = Ui.Body;
            _dockerConsent.ForeColor = Palette.Ink;
            _dockerConsent.AutoSize = true;
            _dockerConsent.SetBounds(20, 15, 700, 26);
            controls.Controls.Add(_dockerConsent);

            Button terms = Ui.Button(L.T("Read Docker terms", "查看 Docker 条款"), false);
            terms.Width = 160;
            terms.SetBounds(738, 12, 160, 31);
            terms.Click += delegate
            {
                Process.Start(new ProcessStartInfo(InstallerEngine.DockerTermsUrl) { UseShellExecute = true });
            };
            controls.Controls.Add(terms);

            Button install = Ui.Button(L.T("Install & start", "安装并启动"), true);
            install.Width = 154;
            install.SetBounds(20, 58, 154, 39);
            install.Click += InstallAndStartClick;
            controls.Controls.Add(install);

            Button repair = Ui.Button(L.T("Start / repair", "启动 / 修复"), false);
            repair.Width = 142;
            repair.SetBounds(184, 58, 142, 39);
            repair.Click += RepairClick;
            controls.Controls.Add(repair);

            Button check = Ui.Button(L.T("Recheck", "重新检查"), false);
            check.Width = 112;
            check.SetBounds(336, 58, 112, 39);
            check.Click += async delegate { await RefreshEnvironmentAsync(); };
            controls.Controls.Add(check);

            Button open = Ui.Button(L.T("Open :8080", "打开 :8080"), false);
            open.Width = 128;
            open.SetBounds(458, 58, 128, 39);
            open.Click += delegate { _engine.OpenService(); };
            controls.Controls.Add(open);

            Button folder = Ui.Button(L.T("Deployment folder", "部署目录"), false);
            folder.Width = 158;
            folder.SetBounds(596, 58, 158, 39);
            folder.Click += delegate { _engine.OpenFolder(); };
            controls.Controls.Add(folder);

            _installStatus = Ui.Label(
                L.T("Ready. The first download can be several GB.",
                    "已准备。首次下载内容可能有数 GB。"),
                Ui.BodySmall,
                Palette.Muted,
                430);
            _installStatus.SetBounds(770, 65, 430, 28);
            _installStatus.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            controls.Controls.Add(_installStatus);

            Label modelNotice = Ui.Label(
                L.T(
                    "After installation, choose a segmentation model and an HTR/recognition model inside eScriptorium. The correct model depends on script, language and period.",
                    "安装完成后，必须在 eScriptorium 内自行选择区域检测模型和 HTR/文字识别模型。正确模型取决于字体、语言与年代。"),
                Ui.BodySmall,
                Palette.Ink,
                900);
            modelNotice.SetBounds(20, 105, 900, 36);
            modelNotice.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            controls.Controls.Add(modelNotice);

            Label credentialNotice = Ui.Label(
                L.T(
                    "eScriptorium administrator credentials and your AI provider API key are separate. See Workflow guide after installation.",
                    "eScriptorium 管理员账号密码与 AI 服务商 API Key 是两套独立凭据。安装后可查看“工作流说明”。"),
                Ui.BodySmall,
                Palette.Amber,
                900);
            credentialNotice.SetBounds(20, 145, 900, 34);
            credentialNotice.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            controls.Controls.Add(credentialNotice);

            _compatibilityLabel = Ui.Label(
                L.T("Compatibility: checking this device…", "兼容性：正在检查此设备…"),
                Ui.BodySmall, Palette.Muted, 900);
            _compatibilityLabel.SetBounds(20, 184, 900, 36);
            _compatibilityLabel.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            controls.Controls.Add(_compatibilityLabel);
            root.Controls.Add(controls, 0, 2);

            RoundedPanel logCard = new RoundedPanel();
            logCard.Dock = DockStyle.Fill;
            logCard.MinimumSize = new Size(0, 238);
            logCard.Margin = new Padding(0);
            _installProgress = new ProgressBar();
            _installProgress.Style = ProgressBarStyle.Continuous;
            _installProgress.SetBounds(20, 17, 900, 8);
            _installProgress.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            logCard.Controls.Add(_installProgress);
            Label logLabel = Ui.Label("ACTIVITY LOG", Ui.BodySmall, Palette.Muted, 300);
            logLabel.Font = new Font(Ui.BodySmall.FontFamily, 8.3f, FontStyle.Bold);
            logLabel.SetBounds(20, 34, 300, 20);
            logCard.Controls.Add(logLabel);
            _installLog = new TextBox();
            _installLog.Multiline = true;
            _installLog.ReadOnly = true;
            _installLog.ScrollBars = ScrollBars.Vertical;
            _installLog.BorderStyle = BorderStyle.FixedSingle;
            _installLog.BackColor = Color.FromArgb(32, 43, 47);
            _installLog.ForeColor = Color.FromArgb(221, 229, 225);
            _installLog.Font = Ui.Mono;
            _installLog.SetBounds(20, 58, 900, 160);
            _installLog.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            _installLog.Text = L.T(
                "No installation has been started in this session.\r\n" +
                "Actions write only after you press Install & start.\r\n",
                "本次会话尚未开始安装。\r\n" +
                "只有按下“安装并启动”后才会进行写入操作。\r\n");
            logCard.Controls.Add(_installLog);
            root.Controls.Add(logCard, 0, 3);
            return root;
        }

        private Control BuildStudioPage()
        {
            TableLayoutPanel root = VerticalRoot();
            root.AutoSize = false;
            root.Dock = DockStyle.Fill;
            root.RowStyles.Clear();
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 84));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 78));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.Controls.Add(SectionTitle(
                L.T("Manuscript studio", "手稿工作台"),
                L.T("Import coordinate-bearing text, preserve line IDs, then clean, translate and analyze.",
                    "导入带坐标文本，保留行号，在同一行内完成清洗、翻译与分析。")), 0, 0);

            FlowLayoutPanel toolbar = new FlowLayoutPanel();
            toolbar.Dock = DockStyle.Fill;
            toolbar.Height = 48;
            toolbar.WrapContents = false;
            toolbar.Margin = new Padding(0, 0, 0, 10);
            toolbar.Padding = new Padding(0, 2, 0, 0);
            Button import = Ui.Button(L.T("Import ALTO / PAGE / text", "导入 ALTO / PAGE / 文本"), true);
            import.Width = 194;
            import.Click += ImportClick;
            toolbar.Controls.Add(import);
            Button clean = Ui.Button(L.T("Local clean", "本地清洗"), false);
            clean.Width = 104;
            clean.Click += LocalCleanClick;
            toolbar.Controls.Add(clean);
            Button ai = Ui.Button(L.T("AI clean + align + translate", "AI 清洗 + 对照翻译"), true);
            ai.Width = 205;
            ai.Click += AiProcessClick;
            toolbar.Controls.Add(ai);
            Button analyze = Ui.Button(L.T("Analyze", "文本分析"), false);
            analyze.Width = 86;
            analyze.Click += AnalyzeClick;
            toolbar.Controls.Add(analyze);
            Button export = Ui.Button(L.T("Export bilingual set", "导出双语成果"), false);
            export.Width = 142;
            export.Click += ExportClick;
            toolbar.Controls.Add(export);
            Button exportWord = Ui.Button(L.T("Export Word", "导出 Word"), true);
            exportWord.Width = 126;
            exportWord.Click += ExportWordClick;
            toolbar.Controls.Add(exportWord);
            Button upload = Ui.Button(L.T("Open upload", "打开上传页"), false);
            upload.Width = 112;
            upload.Click += delegate { _engine.OpenUploads(); };
            toolbar.Controls.Add(upload);
            root.Controls.Add(toolbar, 0, 1);

            RoundedPanel stats = new RoundedPanel();
            stats.Dock = DockStyle.Fill;
            stats.Height = 68;
            stats.MinimumSize = new Size(0, 64);
            stats.Margin = new Padding(0, 0, 0, 10);
            _studioStats = Ui.Label("", Ui.Body, Palette.Ink, 760);
            _studioStats.SetBounds(18, 17, 770, 27);
            stats.Controls.Add(_studioStats);
            _studioStatus = Ui.Label(
                L.T("Drop files here or use Import.", "可拖放文件，或点击“导入”。"),
                Ui.BodySmall,
                Palette.Muted,
                420);
            _studioStatus.SetBounds(18, 42, 780, 20);
            stats.Controls.Add(_studioStatus);
            root.Controls.Add(stats, 0, 2);
            UpdateStudioStats();

            TabControl tabs = new TabControl();
            tabs.Dock = DockStyle.Fill;
            tabs.Font = Ui.BodyBold;
            tabs.Padding = new Point(16, 6);
            tabs.Margin = new Padding(0);
            _studioTabs = tabs;
            TabPage linesTab = new TabPage(L.T("Coordinates & lines", "坐标与逐行文本"));
            linesTab.BackColor = Palette.Paper;
            linesTab.Padding = new Padding(8);
            tabs.TabPages.Add(linesTab);

            SplitContainer split = new SplitContainer();
            split.Dock = DockStyle.Fill;
            split.FixedPanel = FixedPanel.Panel2;
            split.SplitterWidth = 7;
            split.BackColor = Palette.Line;
            bool splitInitialized = false;
            split.SizeChanged += delegate
            {
                if (splitInitialized || split.Width < 680)
                    return;
                try
                {
                    split.Panel1MinSize = 360;
                    split.Panel2MinSize = 250;
                    split.SplitterDistance = Math.Max(380, split.Width - 300);
                    splitInitialized = true;
                }
                catch
                {
                }
            };
            linesTab.Controls.Add(split);

            _lineBinding = new BindingList<TranscriptionLine>(_lines);
            _linesGrid = new DataGridView();
            _linesGrid.Dock = DockStyle.Fill;
            _linesGrid.AutoGenerateColumns = false;
            _linesGrid.DataSource = _lineBinding;
            _linesGrid.AllowUserToAddRows = false;
            _linesGrid.AllowUserToDeleteRows = false;
            _linesGrid.AllowUserToResizeRows = false;
            _linesGrid.ReadOnly = true;
            _linesGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _linesGrid.MultiSelect = false;
            _linesGrid.RowHeadersVisible = false;
            _linesGrid.BackgroundColor = Palette.Paper;
            _linesGrid.BorderStyle = BorderStyle.None;
            _linesGrid.GridColor = Color.FromArgb(229, 223, 212);
            _linesGrid.EnableHeadersVisualStyles = false;
            _linesGrid.ColumnHeadersDefaultCellStyle.BackColor = Palette.Deep;
            _linesGrid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            _linesGrid.ColumnHeadersDefaultCellStyle.Font = Ui.BodyBold;
            _linesGrid.ColumnHeadersHeight = 36;
            _linesGrid.DefaultCellStyle.Font = Ui.BodySmall;
            _linesGrid.DefaultCellStyle.ForeColor = Palette.Ink;
            _linesGrid.DefaultCellStyle.BackColor = Palette.Paper;
            _linesGrid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(226, 236, 232);
            _linesGrid.DefaultCellStyle.SelectionForeColor = Palette.Ink;
            _linesGrid.RowTemplate.Height = 30;
            _linesGrid.AllowDrop = true;
            _linesGrid.DragEnter += FormDragEnter;
            _linesGrid.DragDrop += FormDragDrop;
            _linesGrid.SelectionChanged += UpdateDetailPanel;
            AddGridColumn("Id", "#", 42, false);
            AddGridColumn("Page", L.T("Page", "页"), 50, false);
            AddGridColumn("Original", L.T("Original", "原文"), 225, true);
            AddGridColumn("Cleaned", L.T("Cleaned", "清洗"), 190, true);
            AddGridColumn("Translation", L.T("Translation", "翻译"), 195, true);
            AddGridColumn("CoordinateText", L.T("X, Y, W×H", "X, Y, 宽×高"), 120, false);
            AddGridColumn("Status", L.T("Status", "状态"), 95, false);
            split.Panel1.Controls.Add(_linesGrid);

            Panel detail = new Panel();
            detail.Dock = DockStyle.Fill;
            detail.BackColor = Palette.Card;
            detail.Padding = new Padding(16);
            split.Panel2.Controls.Add(detail);
            Label detailTitle = Ui.Label(L.T("Selected line", "当前行"), Ui.Heading, Palette.Ink, 260);
            detailTitle.SetBounds(16, 14, 270, 32);
            detail.Controls.Add(detailTitle);
            _detailCoordinates = Ui.Label("", Ui.BodySmall, Palette.Muted, 270);
            _detailCoordinates.SetBounds(16, 48, 280, 22);
            detail.Controls.Add(_detailCoordinates);
            _detailOriginal = DetailBox(L.T("Original", "原文"), detail, 78);
            _detailCleaned = DetailBox(L.T("Cleaned", "清洗"), detail, 172);
            _detailTranslation = DetailBox(L.T("Aligned translation", "对照翻译"), detail, 266);
            Button apply = Ui.Button(L.T("Apply edits", "应用修改"), true);
            apply.SetBounds(16, 363, 120, 35);
            apply.Click += ApplyDetailEdits;
            detail.Controls.Add(apply);
            detail.Resize += delegate
            {
                int width = Math.Max(180, detail.ClientSize.Width - 32);
                _detailOriginal.Width = width;
                _detailCleaned.Width = width;
                _detailTranslation.Width = width;
                apply.Top = Math.Max(330, detail.ClientSize.Height - 50);
                _detailTranslation.Height = Math.Max(58, apply.Top - _detailTranslation.Top - 12);
            };
            _linesGrid.DataBindingComplete += delegate
            {
                if (_linesGrid.Rows.Count > 0 && _linesGrid.CurrentRow == null)
                {
                    _linesGrid.CurrentCell = _linesGrid.Rows[0].Cells[0];
                    _linesGrid.Rows[0].Selected = true;
                }
            };

            tabs.TabPages.Add(BuildContextTranslationTab());

            TabPage analysisTab = new TabPage(L.T("Text analysis", "文本分析"));
            analysisTab.BackColor = Palette.Paper;
            analysisTab.Padding = new Padding(12);
            _analysisText = new TextBox();
            _analysisText.Dock = DockStyle.Fill;
            _analysisText.Multiline = true;
            _analysisText.ReadOnly = true;
            _analysisText.ScrollBars = ScrollBars.Both;
            _analysisText.WordWrap = false;
            _analysisText.Font = Ui.Mono;
            _analysisText.BackColor = Palette.Paper;
            _analysisText.ForeColor = Palette.Ink;
            _analysisText.BorderStyle = BorderStyle.None;
            _analysisText.Text = _analysis == null
                ? L.T("Analyze after importing text.", "导入文本后可运行分析。")
                : TextAnalyzer.Format(_analysis);
            analysisTab.Controls.Add(_analysisText);
            tabs.TabPages.Add(analysisTab);

            TabPage guide = new TabPage(L.T("Workflow guide", "工作流说明"));
            guide.BackColor = Palette.Paper;
            guide.Padding = new Padding(22);
            TextBox guideText = new TextBox();
            guideText.Dock = DockStyle.Fill;
            guideText.Multiline = true;
            guideText.ReadOnly = true;
            guideText.ScrollBars = ScrollBars.Vertical;
            guideText.BorderStyle = BorderStyle.None;
            guideText.BackColor = Palette.Paper;
            guideText.ForeColor = Palette.Ink;
            guideText.Font = Ui.Body;
            guideText.Text =
                L.T(
                    "A. ESCRIPTORIUM MODELS — CHOOSE THEM YOURSELF\r\n" +
                    "1. In eScriptorium, create a document and upload manuscript images or a PDF.\r\n" +
                    "2. Select a segmentation model and an HTR/recognition model in the processing form. " +
                    "They are separate and are not selected automatically.\r\n" +
                    "3. Match the model to script, language and period. For early modern German handwriting, " +
                    "check that the HTR model supports Kurrent/Fraktur; for Latin, French, Spanish or other hands, " +
                    "use a model trained on the relevant script.\r\n" +
                    "4. Run segmentation first, then recognition. Confirm the editor contains real transcription " +
                    "text, not only coordinate boxes.\r\n" +
                    "5. Export ALTO XML or PAGE XML after recognition so each line keeps its coordinates.\r\n\r\n" +
                    "B. AI API KEY — YOUR PROVIDER, YOUR MODEL\r\n" +
                    "1. Obtain the API key from the AI provider you actually intend to use. An OpenAI key cannot " +
                    "authenticate a DeepSeek endpoint, and the model name must belong to that provider.\r\n" +
                    "2. In Settings, enter the complete Chat Completions URL. Examples: " +
                    "https://api.openai.com/v1/chat/completions or https://api.deepseek.com/chat/completions.\r\n" +
                    "3. Enter the provider model exactly, save settings, and press Test one line before processing a manuscript.\r\n" +
                    "4. The default target language in this version is English; change it in Settings if another language is required.\r\n" +
                    "5. If the key changes, replace only the API key field and save again. API secrets are protected with Windows DPAPI.\r\n\r\n" +
                    "C. TWO SEPARATE CREDENTIAL SETS\r\n" +
                    "1. LOCAL SERVER shows the eScriptorium administrator username and generated password. " +
                    "These are used only to sign in at http://localhost:8080/.\r\n" +
                    "2. AI TRANSLATION contains the AI provider API key. Never use the eScriptorium password as an API key " +
                    "and never paste the API key into the eScriptorium login form.\r\n" +
                    "3. Changing the AI key does not change the eScriptorium account password, and changing the eScriptorium " +
                    "password does not affect AI access.\r\n\r\n" +
                    "D. IMPORT AND ANALYSIS\r\n" +
                    "1. Import the ALTO/PAGE files that contain non-empty text. METS.xml is only an inventory file.\r\n" +
                    "2. Use AI clean + align + translate for line-level cleaning and translation.\r\n" +
                    "3. Use Analyze, then open the Text analysis tab. Export CSV, aligned JSON or TEI when finished.\r\n\r\n" +
                    "E. PAGE-NODE CONTEXTUAL CLEANSE + TRANSLATION\r\n" +
                    "1. Open the Context translation tab after importing text. Each manuscript page is one node.\r\n" +
                    "2. Generate page nodes. One request returns the contextual cleansed page, the coherent page " +
                    "translation, and one cleaned/aligned translation for every input line ID.\r\n" +
                    "3. OCR confusion among l, f, s and long s ſ is resolved from the detected language, word forms, " +
                    "function words and neighboring lines. It is not a blind global l/f→s replacement.\r\n" +
                    "4. Both outputs mark PAGE numbers. The line-level table and coordinate boxes remain unchanged.\r\n" +
                    "5. Speed mode processes up to two page nodes in parallel. For DeepSeek, thinking is disabled and " +
                    "JSON response format is requested when available.\r\n" +
                    "6. JSON and TEI exports include page-numbered contextual cleanse and translation nodes.\r\n\r\n" +
                    "F. WORD EXPORT, ANNOTATION AND FOLLOW-UP ANALYSIS\r\n" +
                    "1. Use Export Word for a native .docx. Every line retains three texts: Original, Cleanse and " +
                    "Translation. Pages are grouped, page-level contextual results are appended, and a short " +
                    "analysis summary is included.\r\n" +
                    "2. Use Export bilingual set → CSV for Excel review. Keep page, line ID, original, cleaned, " +
                    "translation and coordinates. Add working columns such as normalized_analysis, entity, lemma, " +
                    "pos, certainty, review_status and translator_note.\r\n" +
                    "3. Do not overwrite the original HTR result with normalized spellings. Keep original, cleaned " +
                    "transcription and normalized analysis in separate columns so every editorial decision remains traceable.\r\n" +
                    "4. Save CSV, JSON, TEI and the original ALTO/PAGE XML together. Word is for reading and review, " +
                    "CSV is for line-by-line annotation, JSON is for machine processing, and TEI is best for a " +
                    "long-term digital edition. TEI marks original/regularized text, translation, coordinates and " +
                    "page nodes; add tags such as persName, placeName, date, unclear and note as needed.\r\n" +
                    "5. For corpus work, analyze cleaned or normalized text with AntConc, Voyant Tools or TXM. " +
                    "For entity and semantic annotation, use INCEpTION or a TEI editor, then retain the page and " +
                    "line ID so annotations can be linked back to the manuscript image.\r\n\r\n" +
                    "G. PRINTED OCR AND HANDWRITING HTR\r\n" +
                    "1. Choose the routing by material: use Printed OCR for printed books, Fraktur, typescript and " +
                    "modern print; use eScriptorium mirror + HTR Recognition for handwriting such as Kurrent.\r\n" +
                    "2. PRINTED OCR: open the Printed OCR page, choose Umi-OCR HTTP (recommended) or Tesseract CLI. " +
                    "Umi-OCR is an external local program and is not bundled; enable its HTTP service in Umi global " +
                    "settings. The default address is http://127.0.0.1:1224.\r\n" +
                    "3. In Printed OCR, click Open Umi-OCR and Test / load languages, choose the printed language, " +
                    "select page images, preview them, then Run printed OCR. Umi returns text and four-corner boxes; " +
                    "the app converts these to page, line ID and coordinate rows and sends them to the manuscript studio.\r\n" +
                    "4. Tesseract alternative: enter tesseract.exe and an installed language code such as eng, deu, " +
                    "fra, lat or chi_sim. Tesseract must be installed separately with its language data.\r\n" +
                    "5. HANDWRITING HTR: in the eScriptorium mirror create a document and upload page images or PDF. " +
                    "Choose a segmentation model and a Recognition/HTR model that match script, language and period; " +
                    "refresh the layer, Segment lines, Run HTR, verify text and boxes, then export ALTO/PAGE XML.\r\n" +
                    "6. Import the OCR or HTR result into the studio, run AI cleanse + alignment + translation, and " +
                    "verify names, abbreviations, long s ſ, l/f/s confusions and uncertain readings against the image.\r\n\r\n" +
                    "H. WINDOWS TABLET AND PERFORMANCE\r\n" +
                    "1. Local eScriptorium requires 64-bit Windows, hardware virtualization/WSL 2, at least 8 GB RAM " +
                    "(16 GB recommended) and about 20 GB free disk. The installer shows warnings for ARM, low memory " +
                    "and low disk devices.\r\n" +
                    "2. Low-power or ARM tablets may be unable to run the amd64 eScriptorium Docker images reliably. " +
                    "Printed OCR and Word/CSV/TEI work can still run locally; handwriting HTR should use a more powerful " +
                    "PC or a remote eScriptorium server.\r\n\r\n" +
                    "Scholarly safeguards: the default prompt preserves early modern spelling and marks uncertain text " +
                    "[illegible]. Check names and abbreviations against the image. AI output is a draft, not a critical edition.",
                    "A. ESCRIPTORIUM 模型 — 必须自行选择\r\n" +
                    "1. 在 eScriptorium 中新建文档，上传手稿图像或 PDF。\r\n" +
                    "2. 在处理表单中分别选择“区域检测/分割模型”和“HTR/文字识别模型”。" +
                    "这是两个独立模型，软件不会自动替您选择。\r\n" +
                    "3. 模型必须适合字体、语言和年代。早期现代德语手稿应确认模型支持 Kurrent/Fraktur；" +
                    "拉丁语、法语、西班牙语等手稿应选择相应文字的训练模型。\r\n" +
                    "4. 先执行区域检测，再执行文字识别。确认编辑器中已经出现真实转录文字，而不只是坐标框。\r\n" +
                    "5. 完成识别后再导出 ALTO XML 或 PAGE XML，确保每行保留坐标。\r\n\r\n" +
                    "B. AI API KEY — 服务商和模型必须匹配\r\n" +
                    "1. API Key 必须从您实际使用的 AI 服务商申请。OpenAI Key 不能用于 DeepSeek 接口，" +
                    "模型名也必须属于对应服务商。\r\n" +
                    "2. 在“设置”中填写完整 Chat Completions 地址，例如：" +
                    "https://api.openai.com/v1/chat/completions 或 https://api.deepseek.com/chat/completions。\r\n" +
                    "3. 填写服务商提供的准确模型名，保存设置，并先点击“测试单行翻译”。\r\n" +
                    "4. 本版本默认翻译目标语言为英语；如需其他语言，请在“设置”中修改。\r\n" +
                    "5. 更换 API Key 时只替换密钥字段并重新保存。密钥使用 Windows DPAPI 保护。\r\n\r\n" +
                    "C. 两套独立账号密码\r\n" +
                    "1. “本机服务”显示的是 eScriptorium 管理员账号和自动生成的密码，" +
                    "仅用于登录 http://localhost:8080/。\r\n" +
                    "2. “AI TRANSLATION”中的 API Key 是 AI 服务商凭据。" +
                    "不要把 eScriptorium 密码当作 API Key，也不要把 API Key 填入 eScriptorium 登录框。\r\n" +
                    "3. 修改 AI Key 不会修改 eScriptorium 账号密码；修改 eScriptorium 密码也不会影响 AI 接口。\r\n\r\n" +
                    "D. 导入与分析\r\n" +
                    "1. 导入包含非空文字的 ALTO/PAGE 文件；METS.xml 只是文件清单，不含正文。\r\n" +
                    "2. 使用“AI 清洗 + 对照翻译”完成逐行清洗和翻译。\r\n" +
                    "3. 点击“文本分析”，再打开“文本分析”标签页查看结果。完成后可导出 CSV、对齐 JSON 或 TEI。\r\n\r\n" +
                    "E. 按页节点语境清洗与翻译\r\n" +
                    "1. 导入文本后，打开“全文语境翻译”标签页。每一页手稿作为一个处理节点。\r\n" +
                    "2. 点击“生成按页语境翻译”。一次请求同时返回整页语境清洗、连贯的整页译文，" +
                    "以及每个输入行号对应的清洗文本和译文。\r\n" +
                    "3. l、f、s 与长 s（ſ）的 OCR 混淆会根据检测到的语言、词形、功能词和相邻行消歧，" +
                    "不会盲目全局替换 l/f→s。\r\n" +
                    "4. 两种输出都标记 PAGE 页码；逐行表格和坐标不会改变。\r\n" +
                    "5. 加速模式最多并行处理两个页面节点。DeepSeek 接口会关闭思考模式并请求 JSON 输出格式。\r\n" +
                    "6. JSON 和 TEI 导出包含带页码的语境清洗与翻译节点。\r\n\r\n" +
                    "F. WORD 导出、标注与后续分析\r\n" +
                    "1. 点击“导出 Word”可生成原生 .docx。每一行同时保留原文、清洗文和译文三段；" +
                    "文档按页分组，并附页面语境清洗、整页译文和基础文本分析摘要。\r\n" +
                    "2. 如需在 Excel 中校对，使用“导出双语成果”→CSV。保留 page、行号、原文、清洗文、" +
                    "译文和坐标，并增加 normalized_analysis、entity、lemma、pos、certainty、" +
                    "review_status、translator_note 等标注列。\r\n" +
                    "3. 不要用规范化拼写覆盖 HTR 原始结果。应分别保留 original、cleaned 和 " +
                    "normalized_analysis，使每一次编辑判断都可追溯。\r\n" +
                    "4. 建议把 CSV、JSON、TEI 与原始 ALTO/PAGE XML 一起保存：Word 用于阅读审核，" +
                    "CSV 用于逐行标注，JSON 用于程序处理，TEI 最适合长期数字版本。可继续添加 persName（人名）、" +
                    "placeName（地名）、date（日期）、unclear（不确定）和 note（注释）等 TEI 标签。\r\n" +
                    "5. 词频和语境检索可使用清洗文或规范化文本，工具可选 AntConc、Voyant Tools 或 TXM。" +
                    "实体和语义标注可使用 INCEpTION 或 TEI 编辑器；必须保留页码和行号，" +
                    "以便把标注重新对应回手稿图像。\r\n\r\n" +
                    "G. 印刷 OCR 与手写 HTR\r\n" +
                    "1. 按材料选择入口：印刷书籍、Fraktur、打字稿和现代印刷文本使用“印刷文本 OCR”；" +
                    "Kurrent 等手写文字使用 eScriptorium 镜像和 HTR Recognition 模型。\r\n" +
                    "2. 印刷 OCR：打开“印刷文本 OCR”，选择 Umi-OCR HTTP（推荐）或 Tesseract CLI。" +
                    "Umi-OCR 是外部本机程序，未直接打包；请在 Umi 全局设置中启用 HTTP 服务，默认地址为 " +
                    "http://127.0.0.1:1224。\r\n" +
                    "3. 在印刷 OCR 页点击“打开 Umi-OCR”和“测试 / 读取语言”，选择印刷语言，添加并预览页面，" +
                    "再点击“运行印刷 OCR”。Umi 返回文字和四角坐标，软件会转换为页码、行号和坐标框并写入手稿工作台。\r\n" +
                    "4. Tesseract 备选：填写 tesseract.exe 和已安装的语言代码，例如 eng、deu、fra、lat 或 " +
                    "chi_sim；需要另行安装 Tesseract 和对应语言数据。\r\n" +
                    "5. 手写 HTR：在 eScriptorium 镜像中上传页面或 PDF，分别选择适合版面、字体、语言和年代的" +
                    "分割模型及 Recognition/HTR 模型，刷新转录层，检测文本行并运行 HTR。检查文字和坐标后导出 ALTO/PAGE XML。\r\n" +
                    "6. 将 OCR 或 HTR 结果导入手稿工作台，执行 AI 清洗、对齐和翻译；最后逐页核对人名、" +
                    "缩写、长 s（ſ）、l/f/s 混淆和不确定读法。\r\n\r\n" +
                    "H. WINDOWS 平板与性能\r\n" +
                    "1. 本机 eScriptorium 需要 64 位 Windows、硬件虚拟化/WSL 2、至少 8 GB 内存" +
                    "（建议 16 GB）以及约 20 GB 可用磁盘。安装器会对 ARM、内存不足和磁盘不足设备给出警告。\r\n" +
                    "2. 低功耗或 ARM 平板可能无法可靠运行 amd64 eScriptorium Docker 镜像。印刷 OCR 和 " +
                    "Word/CSV/TEI 工作仍可在本机进行；手写 HTR 建议使用性能更好的电脑或远程 eScriptorium 服务器。\r\n\r\n" +
                    "学术保护：默认提示词保留早期现代拼写，不确定文字标记为 [illegible]。" +
                    "人名、缩写和异体字仍需对照原图复核。AI 输出是工作稿，不是校勘定本。")
                + AiErrors.BilingualReference();
            guide.Controls.Add(guideText);
            tabs.TabPages.Add(guide);
            root.Controls.Add(tabs, 0, 3);
            return root;
        }

        private TabPage BuildContextTranslationTab()
        {
            TabPage context = new TabPage(L.T("Context translation", "全文语境翻译"));
            context.BackColor = Palette.Paper;
            context.Padding = new Padding(12);

            TableLayoutPanel layout = new TableLayoutPanel();
            layout.Dock = DockStyle.Fill;
            layout.ColumnCount = 1;
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            layout.RowCount = 3;
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            context.Controls.Add(layout);

            Panel explanation = new Panel();
            explanation.Dock = DockStyle.Fill;
            explanation.BackColor = Palette.Paper;
            Label title = Ui.Label(
                L.T("Page-node contextual cleanse & translation",
                    "按页节点语境清洗与翻译"),
                Ui.Heading,
                Palette.Ink,
                800);
            title.SetBounds(4, 0, 800, 31);
            explanation.Controls.Add(title);
            Label description = Ui.Label(
                L.T(
                    "Each page is sent as one contextual node. One AI request returns page-level cleansing, page-level translation and every aligned line ID; page numbers are marked in both outputs.",
                    "每一页作为一个语境节点发送；一次 AI 请求同时返回整页语境清洗、整页译文和每个对齐行号。两种输出都会标记页码。"),
                Ui.BodySmall,
                Palette.Muted,
                900);
            description.SetBounds(5, 31, 900, 25);
            explanation.Controls.Add(description);
            _contextTranslationStatus = Ui.Label(
                _contextTranslation == null
                    ? L.T("Generate after importing and cleaning the transcription.",
                        "导入转录文本后可生成按页清洗与翻译。")
                    : String.Format(
                        L.T("Generated for {0} lines · {1} page node(s) · {2}",
                            "已生成：{0} 行 · {1} 个页面节点 · {2}"),
                        _contextTranslation.LineCount,
                        _contextTranslation.ChunkCount,
                        _contextTranslation.CreatedAt.ToString("yyyy-MM-dd HH:mm")),
                Ui.BodySmall,
                Palette.Amber,
                900);
            _contextTranslationStatus.SetBounds(5, 67, 900, 25);
            explanation.Controls.Add(_contextTranslationStatus);
            layout.Controls.Add(explanation, 0, 0);

            FlowLayoutPanel actions = new FlowLayoutPanel();
            actions.Dock = DockStyle.Fill;
            actions.WrapContents = false;
            actions.Padding = new Padding(0, 2, 0, 0);
            Button generate = Ui.Button(
                L.T("Generate page nodes", "生成按页语境翻译"), true);
            generate.Width = 178;
            generate.Click += GenerateContextTranslationClick;
            actions.Controls.Add(generate);
            Button copy = Ui.Button(L.T("Copy", "复制"), false);
            copy.Width = 84;
            copy.Click += delegate
            {
                TextBox selected = _contextOutputTabs != null &&
                    _contextOutputTabs.SelectedIndex == 1
                    ? _contextCleanseBox
                    : _contextTranslationBox;
                if (selected != null && !String.IsNullOrWhiteSpace(selected.Text))
                    Clipboard.SetText(selected.Text);
            };
            actions.Controls.Add(copy);
            Button clear = Ui.Button(L.T("Clear", "清除"), false);
            clear.Width = 84;
            clear.Click += delegate
            {
                _contextTranslation = null;
                if (_contextTranslationBox != null)
                    _contextTranslationBox.Clear();
                if (_contextCleanseBox != null)
                    _contextCleanseBox.Clear();
                if (_contextTranslationStatus != null)
                    _contextTranslationStatus.Text =
                        L.T("No page-node output generated.", "尚未生成按页语境结果。");
            };
            actions.Controls.Add(clear);
            layout.Controls.Add(actions, 0, 1);

            _contextOutputTabs = new TabControl();
            _contextOutputTabs.Dock = DockStyle.Fill;
            _contextOutputTabs.Font = Ui.BodyBold;
            TabPage translationPage = new TabPage(
                L.T("Page translations", "按页译文"));
            translationPage.BackColor = Palette.Paper;
            translationPage.Padding = new Padding(5);
            _contextTranslationBox = CreateContextOutputBox(
                _contextTranslation == null ? String.Empty : _contextTranslation.Translation);
            translationPage.Controls.Add(_contextTranslationBox);
            _contextOutputTabs.TabPages.Add(translationPage);

            TabPage cleansePage = new TabPage(
                L.T("Contextual cleanse", "语境清洗"));
            cleansePage.BackColor = Palette.Paper;
            cleansePage.Padding = new Padding(5);
            _contextCleanseBox = CreateContextOutputBox(
                _contextTranslation == null ? String.Empty : _contextTranslation.CleanseText);
            cleansePage.Controls.Add(_contextCleanseBox);
            _contextOutputTabs.TabPages.Add(cleansePage);
            layout.Controls.Add(_contextOutputTabs, 0, 2);
            return context;
        }

        private static TextBox CreateContextOutputBox(string text)
        {
            TextBox box = new TextBox();
            box.Dock = DockStyle.Fill;
            box.Multiline = true;
            box.AcceptsReturn = true;
            box.ScrollBars = ScrollBars.Both;
            box.WordWrap = true;
            box.BorderStyle = BorderStyle.FixedSingle;
            box.Font = Ui.Body;
            box.BackColor = Color.White;
            box.ForeColor = Palette.Ink;
            box.Text = text ?? String.Empty;
            return box;
        }

        private async void GenerateContextTranslationClick(object sender, EventArgs e)
        {
            if (_lines.Count == 0)
            {
                MessageBox.Show(
                    AiErrors.Create(AiErrorCode.NoInputLines, "Imported line count: 0").UserMessage,
                    AiErrorCode.NoInputLines + " · " + L.T("AI error", "AI 错误"),
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }
            if (!_ai.IsConfigured(_settings))
            {
                AiRequestException configurationError = AiErrors.Create(
                    AiErrorCode.ConfigurationRequired,
                    "Endpoint: " + _settings.AiEndpoint + "\nModel: " + _settings.AiModel);
                MessageBox.Show(
                    configurationError.UserMessage,
                    configurationError.Code + " · " + L.T("AI configuration", "AI 配置"),
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            ContextTranslationResult generated = null;
            await ExecuteBusyAsync(
                L.T("Generating whole-document context translation…",
                    "正在生成全文语境翻译…"),
                async delegate
                {
                    if (_busyCancellation == null)
                        throw new InvalidOperationException();
                    generated = await _ai.TranslateDocumentAsync(
                        _lines,
                        _settings,
                        delegate(int completed, int total)
                        {
                            SetStudioStatusThreadSafe(String.Format(
                                L.T("Page node {0} / {1} completed.",
                                    "按页语境翻译：已完成 {0} / {1} 页。"),
                                completed, total));
                        },
                        _settings.PageConcurrency,
                        _busyCancellation.Token);
                },
                delegate
                {
                    _contextTranslation = generated;
                    if (_contextTranslationBox != null &&
                        !_contextTranslationBox.IsDisposed)
                        _contextTranslationBox.Text = generated.Translation;
                    if (_contextCleanseBox != null &&
                        !_contextCleanseBox.IsDisposed)
                        _contextCleanseBox.Text = generated.CleanseText;
                    ShowPage("studio");
                    if (_studioTabs != null && _studioTabs.TabPages.Count > 1)
                        _studioTabs.SelectedIndex = 1;
                    if (_contextOutputTabs != null && _contextOutputTabs.TabPages.Count > 0)
                        _contextOutputTabs.SelectedIndex = 0;
                    SetStudioStatus(L.T(
                        "Page-node contextual cleanse and aligned translation generated.",
                        "已按页面节点生成语境清洗和逐行对齐译文。"));
                });
        }

        private Control BuildPrintedOcrPage()
        {
            TableLayoutPanel root = VerticalRoot();
            root.AutoSize = false;
            root.Dock = DockStyle.Fill;
            root.RowStyles.Clear();
            root.RowCount = 5;
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 86));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 120));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 120));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 26));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            root.Controls.Add(SectionTitle(
                L.T("Printed-text OCR", "印刷文本 OCR"),
                L.T(
                    "A separate OCR workflow for printed books, Fraktur, typescript and clean modern print. OCR results are added to the manuscript studio with page, line and bounding-box coordinates.",
                    "专门用于印刷书籍、Fraktur、打字稿和现代印刷文本的 OCR 流程；识别结果连同页码、行号和坐标框加入手稿工作台。")), 0, 0);

            FlowLayoutPanel connectionBar = new FlowLayoutPanel();
            connectionBar.Dock = DockStyle.Fill;
            connectionBar.WrapContents = true;
            connectionBar.Padding = new Padding(0, 2, 0, 0);

            Label backendLabel = Ui.Label(L.T("OCR backend", "OCR 后端"), Ui.BodyBold,
                Palette.Ink, 92);
            backendLabel.Margin = new Padding(0, 10, 8, 0);
            connectionBar.Controls.Add(backendLabel);
            _ocrBackendBox = new ComboBox();
            _ocrBackendBox.DropDownStyle = ComboBoxStyle.DropDownList;
            _ocrBackendBox.Width = 155;
            _ocrBackendBox.Margin = new Padding(0, 7, 14, 0);
            _ocrBackendBox.Items.AddRange(new object[] { "Umi-OCR HTTP", "Tesseract CLI" });
            _ocrBackendBox.SelectedIndex =
                String.Equals(_settings.OcrBackend, "Tesseract", StringComparison.OrdinalIgnoreCase)
                    ? 1 : 0;
            _ocrBackendBox.SelectedIndexChanged += OcrBackendChanged;
            connectionBar.Controls.Add(_ocrBackendBox);

            Button handwritingMode = Ui.Button(L.T("Handwriting HTR", "手写 HTR"), false);
            handwritingMode.Width = 132;
            handwritingMode.Click += delegate { ShowPage("mirror"); };
            connectionBar.Controls.Add(handwritingMode);

            _ocrEndpointLabel = Ui.Label(L.T("Umi endpoint", "Umi 地址"), Ui.BodyBold,
                Palette.Ink, 86);
            _ocrEndpointLabel.Margin = new Padding(0, 10, 8, 0);
            connectionBar.Controls.Add(_ocrEndpointLabel);
            _ocrEndpointBox = Ui.TextBox(_settings.OcrEndpoint, false, false);
            _ocrEndpointBox.Width = 206;
            _ocrEndpointBox.Margin = new Padding(0, 7, 10, 0);
            connectionBar.Controls.Add(_ocrEndpointBox);

            Button openUmi = Ui.Button(L.T("Open Umi-OCR", "打开 Umi-OCR"), false);
            openUmi.Width = 132;
            openUmi.Click += LaunchUmiOcrClick;
            connectionBar.Controls.Add(openUmi);
            Button testOcr = Ui.Button(L.T("Test / load languages", "测试 / 读取语言"), true);
            testOcr.Width = 174;
            testOcr.Click += TestUmiOcrClick;
            connectionBar.Controls.Add(testOcr);
            Button installUmi = Ui.Button(L.T("Install Umi-OCR", "安装 Umi-OCR"), false);
            installUmi.Width = 142;
            installUmi.Click += InstallUmiOcrClick;
            connectionBar.Controls.Add(installUmi);
            Button installTess = Ui.Button(L.T("Install Tesseract", "安装 Tesseract"), false);
            installTess.Width = 150;
            installTess.Click += InstallTesseractClick;
            connectionBar.Controls.Add(installTess);

            _umiPathLabel = Ui.Label(L.T("Umi path", "Umi 路径"), Ui.BodyBold,
                Palette.Ink, 76);
            _umiPathLabel.Margin = new Padding(18, 10, 8, 0);
            connectionBar.Controls.Add(_umiPathLabel);
            _umiPathBox = Ui.TextBox(
                !String.IsNullOrWhiteSpace(_settings.UmiOcrPath)
                    ? _settings.UmiOcrPath
                    : PrintedOcrClient.FindUmiOcr(),
                false,
                false);
            _umiPathBox.Width = 330;
            _umiPathBox.Margin = new Padding(0, 7, 0, 0);
            connectionBar.Controls.Add(_umiPathBox);
            root.Controls.Add(connectionBar, 0, 1);

            FlowLayoutPanel optionBar = new FlowLayoutPanel();
            optionBar.Dock = DockStyle.Fill;
            optionBar.WrapContents = true;
            optionBar.Padding = new Padding(0, 2, 0, 0);

            _ocrLanguageLabel = Ui.Label(L.T("Language / model", "语言 / 模型"), Ui.BodyBold,
                Palette.Ink, 112);
            _ocrLanguageLabel.Margin = new Padding(0, 10, 8, 0);
            optionBar.Controls.Add(_ocrLanguageLabel);
            _ocrLanguageBox = new ComboBox();
            _ocrLanguageBox.DropDownStyle = ComboBoxStyle.DropDown;
            _ocrLanguageBox.Width = 220;
            _ocrLanguageBox.Margin = new Padding(0, 7, 10, 0);
            PopulateUmiLanguages(null, _settings.OcrLanguageKey);
            optionBar.Controls.Add(_ocrLanguageBox);

            _ocrParserLabel = Ui.Label(L.T("Layout parser", "排版解析"), Ui.BodyBold,
                Palette.Ink, 92);
            _ocrParserLabel.Margin = new Padding(0, 10, 8, 0);
            optionBar.Controls.Add(_ocrParserLabel);
            _ocrParserBox = new ComboBox();
            _ocrParserBox.DropDownStyle = ComboBoxStyle.DropDownList;
            _ocrParserBox.Width = 150;
            _ocrParserBox.Margin = new Padding(0, 7, 10, 0);
            _ocrParserBox.Items.AddRange(new object[]
            {
                "single_line", "single_para", "single_none",
                "multi_line", "multi_para", "multi_none", "none"
            });
            int parserIndex = _ocrParserBox.Items.IndexOf(_settings.OcrParser);
            _ocrParserBox.SelectedIndex = parserIndex >= 0 ? parserIndex : 0;
            optionBar.Controls.Add(_ocrParserBox);

            Label pdfModeLabel = Ui.Label(L.T("PDF mode", "PDF 模式"), Ui.BodyBold,
                Palette.Ink, 72);
            pdfModeLabel.Margin = new Padding(0, 10, 8, 0);
            optionBar.Controls.Add(pdfModeLabel);
            _ocrPdfModeBox = new ComboBox();
            _ocrPdfModeBox.DropDownStyle = ComboBoxStyle.DropDownList;
            _ocrPdfModeBox.Width = 126;
            _ocrPdfModeBox.Margin = new Padding(0, 7, 10, 0);
            _ocrPdfModeBox.Items.AddRange(new object[]
            {
                "mixed", "fullPage", "imageOnly", "textOnly"
            });
            int pdfModeIndex = _ocrPdfModeBox.Items.IndexOf(_settings.OcrPdfMode);
            _ocrPdfModeBox.SelectedIndex = pdfModeIndex >= 0 ? pdfModeIndex : 0;
            optionBar.Controls.Add(_ocrPdfModeBox);
            Label pdfPagesLabel = Ui.Label(L.T("PDF range", "PDF 范围"), Ui.BodyBold,
                Palette.Ink, 82);
            pdfPagesLabel.Margin = new Padding(0, 10, 6, 0);
            optionBar.Controls.Add(pdfPagesLabel);
            _ocrPdfPagesBox = Ui.TextBox("all", false, false);
            _ocrPdfPagesBox.Width = 82;
            _ocrPdfPagesBox.Margin = new Padding(0, 7, 10, 0);
            optionBar.Controls.Add(_ocrPdfPagesBox);

            _tesseractPathLabel = Ui.Label(L.T("Tesseract path", "Tesseract 路径"),
                Ui.BodyBold, Palette.Ink, 100);
            _tesseractPathLabel.Margin = new Padding(0, 10, 8, 0);
            _tesseractPathLabel.Visible = false;
            optionBar.Controls.Add(_tesseractPathLabel);
            _tesseractPathBox = Ui.TextBox(
                !String.IsNullOrWhiteSpace(_settings.TesseractPath)
                    ? _settings.TesseractPath
                    : PrintedOcrClient.FindTesseract(),
                false,
                false);
            _tesseractPathBox.Width = 300;
            _tesseractPathBox.Margin = new Padding(0, 7, 10, 0);
            _tesseractPathBox.Visible = false;
            optionBar.Controls.Add(_tesseractPathBox);
            _tesseractLanguageLabel = Ui.Label(L.T("OCR language", "OCR 语言"),
                Ui.BodyBold, Palette.Ink, 88);
            _tesseractLanguageLabel.Margin = new Padding(0, 10, 8, 0);
            _tesseractLanguageLabel.Visible = false;
            optionBar.Controls.Add(_tesseractLanguageLabel);
            _tesseractLanguageBox = Ui.TextBox(_settings.TesseractLanguage, false, false);
            _tesseractLanguageBox.Width = 105;
            _tesseractLanguageBox.Margin = new Padding(0, 7, 10, 0);
            _tesseractLanguageBox.Visible = false;
            optionBar.Controls.Add(_tesseractLanguageBox);

            Button chooseImages = Ui.Button(L.T("Choose printed pages", "选择印刷页面"), false);
            chooseImages.Width = 164;
            chooseImages.Click += ChooseOcrImagesClick;
            optionBar.Controls.Add(chooseImages);
            Button clearImages = Ui.Button(L.T("Clear", "清空"), false);
            clearImages.Width = 80;
            clearImages.Click += delegate
            {
                _ocrFiles.Clear();
                if (_ocrFilesList != null)
                    _ocrFilesList.Items.Clear();
                SetOcrPreview(null);
                SetOcrStatus(L.T("No printed pages selected.", "尚未选择印刷页面。"), Palette.Muted);
            };
            optionBar.Controls.Add(clearImages);
            _ocrRunButton = Ui.Button(L.T("Run printed OCR", "运行印刷 OCR"), true);
            _ocrRunButton.Width = 158;
            _ocrRunButton.Click += RunPrintedOcrClick;
            optionBar.Controls.Add(_ocrRunButton);
            root.Controls.Add(optionBar, 0, 2);

            TableLayoutPanel content = new TableLayoutPanel();
            content.Dock = DockStyle.Fill;
            content.ColumnCount = 2;
            content.RowCount = 1;
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 62));
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 38));
            content.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            content.Margin = new Padding(0, 8, 0, 0);

            _ocrPreview = new PictureBox();
            _ocrPreview.Dock = DockStyle.Fill;
            _ocrPreview.BackColor = Color.FromArgb(30, 35, 37);
            _ocrPreview.BorderStyle = BorderStyle.FixedSingle;
            _ocrPreview.SizeMode = PictureBoxSizeMode.Zoom;
            content.Controls.Add(_ocrPreview, 0, 0);

            TableLayoutPanel side = new TableLayoutPanel();
            side.Dock = DockStyle.Fill;
            side.ColumnCount = 1;
            side.RowCount = 3;
            side.RowStyles.Add(new RowStyle(SizeType.Absolute, 27));
            side.RowStyles.Add(new RowStyle(SizeType.Percent, 30));
            side.RowStyles.Add(new RowStyle(SizeType.Percent, 70));
            side.Margin = new Padding(14, 0, 0, 0);
            side.Controls.Add(Ui.Label(L.T("Selected pages", "已选页面"),
                Ui.BodyBold, Palette.Ink, 350), 0, 0);

            _ocrFilesList = new ListBox();
            _ocrFilesList.Dock = DockStyle.Fill;
            _ocrFilesList.Font = Ui.BodySmall;
            _ocrFilesList.IntegralHeight = false;
            _ocrFilesList.SelectedIndexChanged += delegate
            {
                if (_ocrFilesList.SelectedIndex >= 0 &&
                    _ocrFilesList.SelectedIndex < _ocrFiles.Count)
                    LoadOcrPreview(_ocrFiles[_ocrFilesList.SelectedIndex]);
            };
            side.Controls.Add(_ocrFilesList, 0, 1);

            _ocrHelpBox = new TextBox();
            _ocrHelpBox.Multiline = true;
            _ocrHelpBox.ReadOnly = true;
            _ocrHelpBox.ScrollBars = ScrollBars.Vertical;
            _ocrHelpBox.BorderStyle = BorderStyle.FixedSingle;
            _ocrHelpBox.Dock = DockStyle.Fill;
            _ocrHelpBox.BackColor = Palette.Paper;
            _ocrHelpBox.ForeColor = Palette.Ink;
            _ocrHelpBox.Font = Ui.BodySmall;
            _ocrHelpBox.Text =
                L.T(
                    "Umi-OCR setup\r\n" +
                    "1. Start Umi-OCR, open its global settings, enable the HTTP service and keep the default port 1224 (or enter the configured endpoint above).\r\n" +
                    "2. Click Test / load languages, choose the printed-text language, then select page images or a PDF.\r\n" +
                    "3. Use single_line or single_para for printed pages. Umi returns text plus four-corner boxes; v1.9 converts them into page, line and coordinate rows. PDF mode mixed reuses native text and OCRs image pages; fullPage forces OCR. PDF range accepts all, 5, or 3-12.\r\n" +
                    "4. Run OCR. Results are added to the manuscript studio, where you can clean, translate, export Word/CSV/TEI, or correct coordinates.\r\n\r\n" +
                    "Tesseract alternative\r\n" +
                    "Select Tesseract CLI, enter tesseract.exe and a language code such as eng, deu, fra, lat or chi_sim. Tesseract processes page images; use Umi-OCR for multi-page PDF documents.\r\n\r\n" +
                    "Scope\r\n" +
                    "This module is for printed text. Handwritten Kurrent and other hands should use the eScriptorium mirror and an HTR Recognition model. The Install buttons download official packages and verify SHA-256 before execution.",
                    "Umi-OCR 设置\r\n" +
                    "1. 启动 Umi-OCR，在全局设置中启用 HTTP 服务，默认端口为 1224（也可在上方填写自定义地址）。\r\n" +
                    "2. 点击“测试 / 读取语言”，选择印刷文本语言，然后选择页面图像或 PDF。\r\n" +
                    "3. 印刷页面建议使用 single_line 或 single_para。Umi 返回文字和四角坐标，v1.9 会转换为页码、行号和坐标框。PDF 的 mixed 模式优先复用原文本并对图像页 OCR，fullPage 强制整页 OCR；PDF 范围可填 all、5 或 3-12。\r\n" +
                    "4. 运行 OCR 后结果进入手稿工作台，可继续清洗、翻译、导出 Word/CSV/TEI 或修正坐标。\r\n\r\n" +
                    "Tesseract 备选方案\r\n" +
                    "选择 Tesseract CLI，填写 tesseract.exe 和语言代码，例如 eng、deu、fra、lat 或 chi_sim；Tesseract 处理页面图像，多页 PDF 请使用 Umi-OCR。\r\n\r\n" +
                    "适用范围\r\n" +
                    "本板块用于印刷文字。Kurrent 和其他手写文字仍应在 eScriptorium 镜像中使用 HTR Recognition 模型。安装按钮会下载官方软件包，并在执行前验证 SHA-256。");
            side.Controls.Add(_ocrHelpBox, 0, 2);
            content.Controls.Add(side, 1, 0);
            root.Controls.Add(content, 0, 4);

            _ocrStatusLabel = Ui.Label(L.T("No printed pages selected.", "尚未选择印刷页面。"),
                Ui.BodyBold, Palette.Muted, 760);
            _ocrStatusLabel.AutoSize = false;
            _ocrStatusLabel.Dock = DockStyle.Fill;
            _ocrStatusLabel.Height = 24;
            _ocrStatusLabel.Padding = new Padding(2, 0, 0, 4);
            root.Controls.Add(_ocrStatusLabel, 0, 3);

            OcrBackendChanged(null, EventArgs.Empty);
            return root;
        }

        private void OcrBackendChanged(object sender, EventArgs e)
        {
            bool tesseract = _ocrBackendBox != null && _ocrBackendBox.SelectedIndex == 1;
            if (_ocrEndpointBox != null)
                _ocrEndpointBox.Enabled = !tesseract;
            if (_ocrLanguageBox != null)
            {
                _ocrLanguageBox.Enabled = !tesseract;
                _ocrLanguageBox.Visible = !tesseract;
            }
            if (_ocrParserBox != null)
            {
                _ocrParserBox.Enabled = !tesseract;
                _ocrParserBox.Visible = !tesseract;
            }
            if (_ocrPdfModeBox != null)
                _ocrPdfModeBox.Enabled = !tesseract;
            if (_ocrPdfPagesBox != null)
                _ocrPdfPagesBox.Enabled = !tesseract;
            if (_ocrLanguageLabel != null)
                _ocrLanguageLabel.Visible = !tesseract;
            if (_ocrParserLabel != null)
                _ocrParserLabel.Visible = !tesseract;
            if (_umiPathBox != null)
            {
                _umiPathBox.Enabled = !tesseract;
                _umiPathBox.Visible = !tesseract;
            }
            if (_umiPathLabel != null)
                _umiPathLabel.Visible = !tesseract;
            if (_ocrEndpointLabel != null)
                _ocrEndpointLabel.Visible = !tesseract;
            if (_ocrEndpointBox != null)
                _ocrEndpointBox.Visible = !tesseract;
            if (_tesseractPathLabel != null)
                _tesseractPathLabel.Visible = tesseract;
            if (_tesseractPathBox != null)
                _tesseractPathBox.Visible = tesseract;
            if (_tesseractLanguageLabel != null)
                _tesseractLanguageLabel.Visible = tesseract;
            if (_tesseractLanguageBox != null)
                _tesseractLanguageBox.Visible = tesseract;
        }

        private void PopulateUmiLanguages(
            IEnumerable<OcrLanguageOption> languages,
            string preferredValue)
        {
            if (_ocrLanguageBox == null)
                return;
            List<OcrLanguageOption> choices = languages == null
                ? new List<OcrLanguageOption>
                {
                    new OcrLanguageOption { Value = "models/config_en.txt", Label = "English" },
                    new OcrLanguageOption { Value = "models/config_chinese.txt", Label = "简体中文" },
                    new OcrLanguageOption { Value = "models/config_chinese_cht(v2).txt", Label = "繁體中文" },
                    new OcrLanguageOption { Value = "models/config_japan.txt", Label = "日本語" },
                    new OcrLanguageOption { Value = "models/config_korean.txt", Label = "한국어" },
                    new OcrLanguageOption { Value = "models/config_cyrillic.txt", Label = "Cyrillic" }
                }
                : languages.Where(item => item != null && !String.IsNullOrWhiteSpace(item.Value)).ToList();
            if (choices.Count == 0)
                return;

            OcrLanguageOption selected = choices.FirstOrDefault(item =>
                String.Equals(item.Value, preferredValue, StringComparison.OrdinalIgnoreCase));
            if (selected == null && !String.IsNullOrWhiteSpace(preferredValue))
            {
                selected = new OcrLanguageOption
                {
                    Value = preferredValue,
                    Label = L.T("Current custom model", "当前自定义模型")
                };
                choices.Insert(0, selected);
            }
            if (selected == null)
                selected = choices[0];

            _ocrLanguageBox.BeginUpdate();
            try
            {
                _ocrLanguageBox.Items.Clear();
                foreach (OcrLanguageOption choice in choices)
                    _ocrLanguageBox.Items.Add(choice);
                _ocrLanguageBox.SelectedItem = selected;
            }
            finally
            {
                _ocrLanguageBox.EndUpdate();
            }
        }

        private string SelectedUmiLanguage()
        {
            if (_ocrLanguageBox == null)
                return String.Empty;
            OcrLanguageOption selected = _ocrLanguageBox.SelectedItem as OcrLanguageOption;
            return selected != null ? selected.Value : _ocrLanguageBox.Text.Trim();
        }

        private static void ParsePdfPageRange(string text, out int start, out int end)
        {
            start = 1;
            end = -1;
            string value = (text ?? String.Empty).Trim();
            if (String.IsNullOrWhiteSpace(value) ||
                String.Equals(value, "all", StringComparison.OrdinalIgnoreCase) ||
                String.Equals(value, "全部", StringComparison.OrdinalIgnoreCase))
                return;

            int dash = value.IndexOf('-');
            if (dash > 0)
            {
                Int32.TryParse(value.Substring(0, dash).Trim(), out start);
                Int32.TryParse(value.Substring(dash + 1).Trim(), out end);
                if (start < 1)
                    start = 1;
                if (end == 0)
                    end = -1;
                return;
            }

            int page;
            if (Int32.TryParse(value, out page) && page > 0)
                start = end = page;
        }

        private void ChooseOcrImagesClick(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = L.T("Choose printed page images", "选择印刷页面图像");
                dialog.Filter =
                    L.T("Page images", "页面图像") +
                    "|*.pdf;*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff|" +
                    L.T("All files", "所有文件") + "|*.*";
                dialog.Multiselect = true;
                dialog.InitialDirectory = Directory.Exists(_settings.LastOcrPath)
                    ? _settings.LastOcrPath
                    : Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
                if (dialog.ShowDialog(this) != DialogResult.OK)
                    return;

                _ocrFiles.Clear();
                _ocrFiles.AddRange(dialog.FileNames.Where(File.Exists));
                if (_ocrFilesList != null)
                {
                    _ocrFilesList.Items.Clear();
                    foreach (string file in _ocrFiles)
                        _ocrFilesList.Items.Add(Path.GetFileName(file));
                    if (_ocrFilesList.Items.Count > 0)
                        _ocrFilesList.SelectedIndex = 0;
                }
                if (_ocrFiles.Count > 0)
                {
                    _settings.LastOcrPath = Path.GetDirectoryName(_ocrFiles[0]);
                    try { _settings.Save(); } catch { }
                }
                LoadOcrPreview(_ocrFiles.FirstOrDefault());
                if (String.Equals(Path.GetExtension(_ocrFiles.FirstOrDefault()),
                    ".pdf", StringComparison.OrdinalIgnoreCase))
                    SetOcrStatus(L.T(
                        "PDF selected. Umi-OCR will OCR it page by page.",
                        "已选择 PDF，Umi-OCR 将逐页进行 OCR。"), Palette.Green);
                SetOcrStatus(String.Format(
                    L.T("{0} printed page(s) ready for OCR.", "已准备 {0} 个印刷页面。"),
                    _ocrFiles.Count), Palette.Green);
            }
        }

        private void LoadOcrPreview(string path)
        {
            if (String.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                SetOcrPreview(null);
                return;
            }
            if (String.Equals(Path.GetExtension(path), ".pdf",
                StringComparison.OrdinalIgnoreCase))
            {
                SetOcrPreview(null);
                return;
            }
            try
            {
                Image image;
                using (FileStream stream = new FileStream(
                    path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (Image source = Image.FromStream(stream))
                    image = new Bitmap(source);
                SetOcrPreview(image);
            }
            catch
            {
                SetOcrPreview(null);
            }
        }

        private void SetOcrPreview(Image image)
        {
            if (_ocrPreview != null)
                _ocrPreview.Image = image;
            if (_ocrPreviewImage != null && !ReferenceEquals(_ocrPreviewImage, image))
                _ocrPreviewImage.Dispose();
            _ocrPreviewImage = image;
        }

        private void LaunchUmiOcrClick(object sender, EventArgs e)
        {
            try
            {
                string path = _umiPathBox == null ? String.Empty : _umiPathBox.Text.Trim('"');
                if (!File.Exists(path))
                    path = PrintedOcrClient.FindUmiOcr();
                if (String.IsNullOrWhiteSpace(path) || !File.Exists(path))
                    throw new FileNotFoundException(L.T(
                        "Umi-OCR was not found. Enter the path to Umi-OCR.exe.",
                        "未找到 Umi-OCR，请填写 Umi-OCR.exe 的路径。"));
                Process.Start(new ProcessStartInfo
                {
                    FileName = path,
                    WorkingDirectory = Path.GetDirectoryName(path),
                    UseShellExecute = true
                });
                _settings.UmiOcrPath = path;
                try { _settings.Save(); } catch { }
                SetOcrStatus(L.T(
                    "Umi-OCR started. Enable its HTTP service in global settings.",
                    "Umi-OCR 已启动，请在全局设置中启用 HTTP 服务。"), Palette.Amber);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, L.T("Could not open Umi-OCR", "无法打开 Umi-OCR"),
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private async void InstallUmiOcrClick(object sender, EventArgs e)
        {
            if (_busy)
                return;
            string installedPath = String.Empty;
            await ExecuteBusyAsync(
                L.T("Downloading and installing Umi-OCR Rapid...",
                    "正在下载并安装 Umi-OCR Rapid..."),
                async delegate
                {
                    if (_busyCancellation == null)
                        throw new InvalidOperationException();
                    installedPath = await DependencyInstaller.InstallUmiAsync(
                        SetOcrStatusThreadSafe,
                        _busyCancellation.Token);
                },
                delegate
                {
                    if (_umiPathBox != null && !_umiPathBox.IsDisposed)
                        _umiPathBox.Text = installedPath;
                    _settings.UmiOcrPath = installedPath;
                    try { _settings.Save(); } catch { }
                    SetOcrStatus(L.T("Umi-OCR is ready. Enable its HTTP service.",
                        "Umi-OCR 已准备完成，请启用 HTTP 服务。"), Palette.Green);
                });
        }

        private async void InstallTesseractClick(object sender, EventArgs e)
        {
            if (_busy)
                return;
            string languages = _tesseractLanguageBox == null
                ? "eng" : _tesseractLanguageBox.Text.Trim();
            if (String.IsNullOrWhiteSpace(languages))
                languages = "eng";
            string installedPath = String.Empty;
            await ExecuteBusyAsync(
                L.T("Downloading and installing Tesseract...",
                    "正在下载并安装 Tesseract..."),
                async delegate
                {
                    if (_busyCancellation == null)
                        throw new InvalidOperationException();
                    installedPath = await DependencyInstaller.InstallTesseractAsync(
                        new[] { languages },
                        SetOcrStatusThreadSafe,
                        _busyCancellation.Token);
                },
                delegate
                {
                    if (_tesseractPathBox != null && !_tesseractPathBox.IsDisposed)
                        _tesseractPathBox.Text = installedPath;
                    _settings.TesseractPath = installedPath;
                    _settings.TesseractLanguage = languages;
                    try { _settings.Save(); } catch { }
                    SetOcrStatus(L.T("Tesseract and selected language data are ready.",
                        "Tesseract 及所选语言数据已准备完成。"), Palette.Green);
                });
        }

        private void SetOcrStatusThreadSafe(string message)
        {
            SetOcrStatus(message, Palette.Gold);
        }

        private async void TestUmiOcrClick(object sender, EventArgs e)
        {
            if (_ocrBackendBox != null && _ocrBackendBox.SelectedIndex == 1)
            {
                string path = _tesseractPathBox == null
                    ? String.Empty : _tesseractPathBox.Text.Trim('"');
                try
                {
                    List<string> languages = await PrintedOcrClient.GetTesseractLanguagesAsync(
                        path, CancellationToken.None);
                    string selected = _tesseractLanguageBox.Text.Trim();
                    bool installed = languages.Any(language =>
                        String.Equals(language, selected, StringComparison.OrdinalIgnoreCase));
                    SetOcrStatus(
                        L.T("Tesseract found. Installed languages: ", "已找到 Tesseract，已安装语言：") +
                        String.Join(", ", languages),
                        installed ? Palette.Green : Palette.Amber);
                }
                catch (Exception ex)
                {
                    SetOcrStatus(L.T("Tesseract check failed: ", "Tesseract 检查失败：") +
                        ex.Message, Palette.Red);
                }
                return;
            }

            try
            {
                _ocrRunButton.Enabled = false;
                string endpoint = _ocrEndpointBox == null
                    ? "http://127.0.0.1:1224" : _ocrEndpointBox.Text.Trim();
                List<OcrLanguageOption> languages =
                    await PrintedOcrClient.GetUmiLanguagesAsync(endpoint, CancellationToken.None);
                if (languages.Count > 0)
                {
                    OcrLanguageOption current = languages.FirstOrDefault(item =>
                        String.Equals(item.Value, SelectedUmiLanguage(),
                            StringComparison.OrdinalIgnoreCase));
                    if (current == null)
                        current = languages.FirstOrDefault(item =>
                            item.Value.IndexOf("_en", StringComparison.OrdinalIgnoreCase) >= 0) ??
                            languages[0];
                    PopulateUmiLanguages(languages, current.Value);
                }
                _settings.OcrEndpoint = endpoint;
                _settings.OcrLanguageKey = SelectedUmiLanguage();
                try { _settings.Save(); } catch { }
                SetOcrStatus(String.Format(
                    L.T("Umi-OCR connected. {0} language/model option(s) loaded.",
                        "Umi-OCR 连接成功，已读取 {0} 个语言/模型选项。"),
                    languages.Count), Palette.Green);
            }
            catch (Exception ex)
            {
                SetOcrStatus(L.T("Umi-OCR connection failed: ", "Umi-OCR 连接失败：") +
                    ex.Message, Palette.Red);
                MessageBox.Show(
                    L.T(
                        "Could not connect to the Umi-OCR HTTP service.\n\n" +
                        "Open Umi-OCR → Global settings → HTTP service, enable it, and verify the endpoint. " +
                        "The default endpoint is http://127.0.0.1:1224.\n\n",
                        "无法连接 Umi-OCR HTTP 服务。\n\n" +
                        "请打开 Umi-OCR → 全局设置 → HTTP 服务并启用，确认地址。默认地址为 " +
                        "http://127.0.0.1:1224。\n\n") + ex.Message,
                    L.T("OCR connection failed", "OCR 连接失败"),
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            finally
            {
                if (_ocrRunButton != null)
                    _ocrRunButton.Enabled = true;
            }
        }

        private async void RunPrintedOcrClick(object sender, EventArgs e)
        {
            if (_busy)
                return;
            if (_ocrFiles.Count == 0)
            {
                SetOcrStatus(L.T("Choose one or more printed page images first.",
                    "请先选择一个或多个印刷页面图像。"), Palette.Amber);
                return;
            }

            PrintedOcrOptions options = new PrintedOcrOptions();
            options.Backend = _ocrBackendBox.SelectedIndex == 1 ? "Tesseract" : "Umi-OCR";
            options.Endpoint = _ocrEndpointBox.Text.Trim();
            options.LanguageKey = SelectedUmiLanguage();
            options.Parser = _ocrParserBox.SelectedItem == null
                ? "single_line" : _ocrParserBox.SelectedItem.ToString();
            options.TesseractPath = _tesseractPathBox.Text.Trim('"');
            options.TesseractLanguage = _tesseractLanguageBox.Text.Trim();
            options.PdfExtractionMode = _ocrPdfModeBox.SelectedItem == null
                ? "mixed" : _ocrPdfModeBox.SelectedItem.ToString();
            int pdfStart;
            int pdfEnd;
            ParsePdfPageRange(_ocrPdfPagesBox.Text, out pdfStart, out pdfEnd);
            options.PdfPageStart = pdfStart;
            options.PdfPageEnd = pdfEnd;

            List<TranscriptionLine> recognized = new List<TranscriptionLine>();
            int firstPage = _lines.Count == 0 ? 1 : _lines.Max(line => line.Page) + 1;
            List<string> files = _ocrFiles.ToList();
            await ExecuteBusyAsync(
                L.T("Running printed-text OCR…", "正在执行印刷文本 OCR…"),
                async delegate
                {
                    int nextPage = firstPage;
                    for (int index = 0; index < files.Count; index++)
                    {
                        if (_busyCancellation == null)
                            throw new InvalidOperationException();
                        SetOcrStatus(String.Format(
                            L.T("OCR page {0} / {1}: {2}", "OCR 第 {0} / {1} 页：{2}"),
                            index + 1, files.Count, Path.GetFileName(files[index])),
                            Palette.Gold);
                        List<TranscriptionLine> pageLines;
                        if (String.Equals(Path.GetExtension(files[index]), ".pdf",
                            StringComparison.OrdinalIgnoreCase))
                        {
                            pageLines = await PrintedOcrClient.RecognizePdfWithUmiAsync(
                                files[index],
                                nextPage,
                                options,
                                delegate(int processed, int total)
                                {
                                    SetOcrStatus(String.Format(
                                        L.T("PDF OCR {0}: {1} / {2} page(s)",
                                            "PDF OCR {0}：{1} / {2} 页"),
                                        Path.GetFileName(files[index]), processed, total),
                                        Palette.Gold);
                                },
                                _busyCancellation.Token);
                        }
                        else
                        {
                            if (String.Equals(options.Backend, "Tesseract",
                                StringComparison.OrdinalIgnoreCase))
                                pageLines = await PrintedOcrClient.RecognizeImageAsync(
                                    files[index], nextPage, options,
                                    _busyCancellation.Token);
                            else
                                pageLines = await PrintedOcrClient.RecognizeImageAsync(
                                    files[index], nextPage, options,
                                    _busyCancellation.Token);
                        }
                        recognized.AddRange(pageLines);
                        int pagesUsed = pageLines.Count == 0
                            ? 1
                            : pageLines.Max(line => line.Page) - nextPage + 1;
                        nextPage += Math.Max(1, pagesUsed);
                    }
                },
                delegate
                {
                    if (recognized.Count == 0)
                    {
                        SetOcrStatus(L.T("OCR completed but found no text.",
                            "OCR 已完成，但没有识别到文字。"), Palette.Amber);
                        return;
                    }
                    _lines.AddRange(recognized);
                    _contextTranslation = null;
                    if (_contextTranslationBox != null)
                        _contextTranslationBox.Clear();
                    for (int index = 0; index < _lines.Count; index++)
                        _lines[index].Id = index + 1;
                    if (_lineBinding != null)
                        _lineBinding.ResetBindings();
                    _analysis = TextAnalyzer.Analyze(_lines);
                    if (_analysisText != null)
                        _analysisText.Text = TextAnalyzer.Format(_analysis);
                    _settings.OcrBackend = options.Backend;
                    _settings.OcrEndpoint = options.Endpoint;
                    _settings.OcrLanguageKey = options.LanguageKey;
                    _settings.OcrParser = options.Parser;
                    _settings.OcrPdfMode = options.PdfExtractionMode;
                    _settings.UmiOcrPath = _umiPathBox.Text.Trim('"');
                    _settings.TesseractPath = options.TesseractPath;
                    _settings.TesseractLanguage = options.TesseractLanguage;
                    try { _settings.Save(); } catch { }
                    ShowPage("studio");
                    SetStudioStatus(String.Format(
                        L.T("Printed OCR added {0} line(s) from {1} page(s).",
                            "印刷 OCR 已加入 {0} 行，来自 {1} 个页面。"),
                        recognized.Count, files.Count));
                });
        }

        private void SetOcrStatus(string message, Color color)
        {
            if (_ocrStatusLabel == null || _ocrStatusLabel.IsDisposed)
                return;
            if (InvokeRequired)
            {
                BeginInvoke(new Action<string, Color>(SetOcrStatus), message, color);
                return;
            }
            _ocrStatusLabel.Text = message;
            _ocrStatusLabel.ForeColor = color;
        }

        private Control BuildMirrorPage()
        {
            TableLayoutPanel root = VerticalRoot();
            root.AutoSize = false;
            root.Dock = DockStyle.Fill;
            root.RowStyles.Clear();
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 84));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            root.Controls.Add(SectionTitle(
                L.T("eScriptorium mirror", "eScriptorium 镜像"),
                L.T(
                    "Embed the local eScriptorium page, select a Recognition model and start HTR for the current document.",
                    "在软件中嵌入本地 eScriptorium 页面，选择 Recognition 模型，并对当前文档启动 HTR。")), 0, 0);

            FlowLayoutPanel modelBar = new FlowLayoutPanel();
            modelBar.Dock = DockStyle.Fill;
            modelBar.WrapContents = false;
            modelBar.Padding = new Padding(0, 2, 0, 0);
            Label modelLabel = Ui.Label(L.T("HTR model", "HTR 模型"), Ui.BodyBold,
                Palette.Ink, 100);
            modelLabel.Margin = new Padding(0, 10, 8, 0);
            modelBar.Controls.Add(modelLabel);
            _htrModelBox = new ComboBox();
            _htrModelBox.DropDownStyle = ComboBoxStyle.DropDownList;
            _htrModelBox.Width = 310;
            _htrModelBox.Margin = new Padding(0, 6, 10, 0);
            _htrModelBox.SelectedIndexChanged += SaveSelectedHtrModel;
            modelBar.Controls.Add(_htrModelBox);
            Button refreshModels = Ui.Button(L.T("Refresh models", "刷新模型"), false);
            refreshModels.Width = 128;
            refreshModels.Click += async delegate { await RefreshHtrModelsAsync(); };
            modelBar.Controls.Add(refreshModels);
            Button uploadModel = Ui.Button(L.T("Upload .mlmodel", "上传 .mlmodel"), true);
            uploadModel.Width = 146;
            uploadModel.Click += UploadHtrModelClick;
            modelBar.Controls.Add(uploadModel);
            Button modelsPage = Ui.Button(L.T("Models page", "模型页面"), false);
            modelsPage.Width = 108;
            modelsPage.Click += delegate { NavigateMirror("/models"); };
            modelBar.Controls.Add(modelsPage);
            root.Controls.Add(modelBar, 0, 1);

            FlowLayoutPanel actionBar = new FlowLayoutPanel();
            actionBar.Dock = DockStyle.Fill;
            actionBar.WrapContents = false;
            actionBar.Padding = new Padding(0, 2, 0, 0);
            Label transcriptionLabel = Ui.Label(
                L.T("Layer", "转录层"),
                Ui.BodyBold,
                Palette.Ink,
                100);
            transcriptionLabel.Margin = new Padding(0, 10, 8, 0);
            actionBar.Controls.Add(transcriptionLabel);
            _transcriptionBox = new ComboBox();
            _transcriptionBox.DropDownStyle = ComboBoxStyle.DropDownList;
            _transcriptionBox.Width = 235;
            _transcriptionBox.Margin = new Padding(0, 6, 10, 0);
            actionBar.Controls.Add(_transcriptionBox);
            Button segment = Ui.Button(L.T("Segment lines", "检测文本行"), false);
            segment.Width = 126;
            segment.Click += SegmentMirrorDocumentClick;
            actionBar.Controls.Add(segment);
            Button runHtr = Ui.Button(L.T("Run HTR", "运行 HTR"), true);
            runHtr.Width = 105;
            runHtr.Click += RunHtrClick;
            actionBar.Controls.Add(runHtr);
            Button home = Ui.Button(L.T("Home", "首页"), false);
            home.Width = 74;
            home.Click += delegate { NavigateMirror("/"); };
            actionBar.Controls.Add(home);
            Button reload = Ui.Button(L.T("Reload", "刷新"), false);
            reload.Width = 78;
            reload.Click += delegate { if (_mirrorView != null) _mirrorView.Reload(); };
            actionBar.Controls.Add(reload);
            Button external = Ui.Button(L.T("Open in Edge", "在 Edge 打开"), false);
            external.Width = 112;
            external.Click += delegate { Process.Start(new ProcessStartInfo(InstallerEngine.ServiceUrl) { UseShellExecute = true }); };
            actionBar.Controls.Add(external);
            root.Controls.Add(actionBar, 0, 2);

            _mirrorStatusLabel = Ui.Label(
                L.T("Starting embedded eScriptorium…", "正在启动内嵌 eScriptorium…"),
                Ui.BodySmall,
                Palette.Amber,
                1000);
            _mirrorStatusLabel.SetBounds(2, 5, 1000, 24);
            Panel statusPanel = new Panel();
            statusPanel.Dock = DockStyle.Fill;
            statusPanel.Controls.Add(_mirrorStatusLabel);
            root.Controls.Add(statusPanel, 0, 3);

            try
            {
                WebView2Runtime.EnsureLoader();
                _mirrorView = new WebView2();
                _mirrorView.Dock = DockStyle.Fill;
                _mirrorView.CoreWebView2InitializationCompleted += MirrorWebViewInitialized;
                _mirrorView.NavigationCompleted += MirrorNavigationCompleted;
                root.Controls.Add(_mirrorView, 0, 4);
                InitializeMirrorAsync();
            }
            catch (Exception ex)
            {
                Label error = Ui.Label(
                    L.T("Embedded browser failed: ", "嵌入浏览器启动失败：") + ex.Message +
                    L.T("\nUse “Open in Edge” and install the Microsoft Edge WebView2 Runtime.",
                        "\n请使用“在 Edge 打开”，并安装 Microsoft Edge WebView2 Runtime。"),
                    Ui.Body,
                    Palette.Red,
                    950);
                error.Dock = DockStyle.Fill;
                root.Controls.Add(error, 0, 4);
            }
            return root;
        }

        private async void InitializeMirrorAsync()
        {
            if (_mirrorView == null)
                return;
            try
            {
                string profile = Path.Combine(AppPaths.Root, "WebView2Profile");
                Directory.CreateDirectory(profile);
                CoreWebView2Environment environment =
                    await CoreWebView2Environment.CreateAsync(null, profile, null);
                await _mirrorView.EnsureCoreWebView2Async(environment);
                _mirrorView.Source = new Uri(InstallerEngine.ServiceUrl);
            }
            catch (Exception ex)
            {
                if (_mirrorStatusLabel != null)
                    _mirrorStatusLabel.Text = L.T("Embedded browser unavailable: ",
                        "嵌入浏览器不可用：") + ex.Message;
            }
        }

        private async void MirrorWebViewInitialized(
            object sender, CoreWebView2InitializationCompletedEventArgs e)
        {
            if (!e.IsSuccess)
            {
                if (_mirrorStatusLabel != null)
                    _mirrorStatusLabel.Text = L.T("WebView2 initialization failed.",
                        "WebView2 初始化失败。");
                return;
            }
            _escriptoriumApi = new EscriptoriumApiClient(_settings);
            if (_mirrorStatusLabel != null)
                _mirrorStatusLabel.Text = L.T(
                    "eScriptorium is embedded. Sign in inside the page; model API access uses the saved administrator credentials.",
                    "eScriptorium 已嵌入。请在页面内登录；模型 API 使用已保存的管理员凭据。");
            await RefreshHtrModelsAsync();
        }

        private async void MirrorNavigationCompleted(
            object sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            if (_mirrorView == null || _mirrorView.Source == null)
                return;
            _mirrorDocumentId = EscriptoriumApiClient.DocumentIdFromUrl(
                _mirrorView.Source.ToString());
            if (_mirrorDocumentId.HasValue)
                await RefreshTranscriptionsAsync(_mirrorDocumentId.Value);
            else if (_transcriptionBox != null)
                _transcriptionBox.Items.Clear();
        }

        private void NavigateMirror(string relativePath)
        {
            if (_mirrorView == null || _mirrorView.CoreWebView2 == null)
                return;
            _mirrorView.Source = new Uri(new Uri(InstallerEngine.ServiceUrl), relativePath.TrimStart('/'));
        }

        private async Task RefreshHtrModelsAsync()
        {
            if (_escriptoriumApi == null)
                _escriptoriumApi = new EscriptoriumApiClient(_settings);
            try
            {
                List<EscriptoriumModelInfo> models =
                    await _escriptoriumApi.GetRecognitionModelsAsync();
                if (_htrModelBox == null)
                    return;
                _htrModelBox.BeginUpdate();
                try
                {
                    _htrModelBox.Items.Clear();
                    foreach (EscriptoriumModelInfo model in models)
                        _htrModelBox.Items.Add(model);
                    int selectedIndex = -1;
                    for (int index = 0; index < _htrModelBox.Items.Count; index++)
                    {
                        EscriptoriumModelInfo item =
                            _htrModelBox.Items[index] as EscriptoriumModelInfo;
                        if (item != null && item.Pk == _settings.SelectedHtrModelPk)
                            selectedIndex = index;
                    }
                    if (selectedIndex >= 0)
                        _htrModelBox.SelectedIndex = selectedIndex;
                    else if (_htrModelBox.Items.Count > 0)
                        _htrModelBox.SelectedIndex = 0;
                }
                finally
                {
                    _htrModelBox.EndUpdate();
                }
                SetMirrorStatus(String.Format(
                    L.T("Loaded {0} Recognition model(s).", "已加载 {0} 个 Recognition 模型。"),
                    models.Count), Palette.Green);
            }
            catch (Exception ex)
            {
                SetMirrorStatus(L.T("Model API failed: ", "模型 API 失败：") + ex.Message,
                    Palette.Red);
            }
        }

        private async Task RefreshTranscriptionsAsync(int documentId)
        {
            try
            {
                if (_escriptoriumApi == null)
                    _escriptoriumApi = new EscriptoriumApiClient(_settings);
                List<EscriptoriumTranscriptionInfo> transcriptions =
                    await _escriptoriumApi.GetTranscriptionsAsync(documentId);
                if (_transcriptionBox == null)
                    return;
                _transcriptionBox.Items.Clear();
                foreach (EscriptoriumTranscriptionInfo item in transcriptions)
                    _transcriptionBox.Items.Add(item);
                if (_transcriptionBox.Items.Count > 0)
                    _transcriptionBox.SelectedIndex = 0;
                SetMirrorStatus(String.Format(
                    L.T("Document {0}: {1} transcription layer(s).",
                        "文档 {0}：{1} 个转录层。"),
                    documentId, transcriptions.Count), Palette.Green);
            }
            catch (Exception ex)
            {
                SetMirrorStatus(L.T("Transcription API failed: ",
                    "转录层 API 失败：") + ex.Message, Palette.Red);
            }
        }

        private async void UploadHtrModelClick(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = L.T("Select a Kraken recognition model", "选择 Kraken Recognition 模型");
                dialog.Filter = "Kraken model (*.mlmodel)|*.mlmodel";
                if (dialog.ShowDialog(this) != DialogResult.OK)
                    return;
                try
                {
                    if (_escriptoriumApi == null)
                        _escriptoriumApi = new EscriptoriumApiClient(_settings);
                    string name = Path.GetFileNameWithoutExtension(dialog.FileName);
                    EscriptoriumModelInfo model =
                        await _escriptoriumApi.UploadRecognitionModelAsync(dialog.FileName, name);
                    _settings.SelectedHtrModelPk = model.Pk;
                    _settings.SelectedHtrModelName = model.Name;
                    _settings.Save();
                    await RefreshHtrModelsAsync();
                    SetMirrorStatus(L.T("Uploaded HTR model: ", "已上传 HTR 模型：") + model.Name,
                        Palette.Green);
                }
                catch (Exception ex)
                {
                    SetMirrorStatus(L.T("Model upload failed: ", "模型上传失败：") + ex.Message,
                        Palette.Red);
                }
            }
        }

        private void SaveSelectedHtrModel(object sender, EventArgs e)
        {
            EscriptoriumModelInfo model = _htrModelBox == null
                ? null
                : _htrModelBox.SelectedItem as EscriptoriumModelInfo;
            if (model == null)
                return;
            _settings.SelectedHtrModelPk = model.Pk;
            _settings.SelectedHtrModelName = model.Name;
            try { _settings.Save(); } catch { }
        }

        private async void SegmentMirrorDocumentClick(object sender, EventArgs e)
        {
            if (!_mirrorDocumentId.HasValue)
            {
                SetMirrorStatus(L.T("Open a document inside the mirror first.",
                    "请先在镜像中打开一个文档。"), Palette.Amber);
                return;
            }
            try
            {
                if (_escriptoriumApi == null)
                    _escriptoriumApi = new EscriptoriumApiClient(_settings);
                await _escriptoriumApi.SegmentDocumentAsync(
                    _mirrorDocumentId.Value, "lines", false);
                SetMirrorStatus(L.T("Segmentation task submitted.",
                    "已提交文本行检测任务。"), Palette.Gold);
            }
            catch (Exception ex)
            {
                SetMirrorStatus(L.T("Segmentation failed: ", "文本行检测失败：") + ex.Message,
                    Palette.Red);
            }
        }

        private async void RunHtrClick(object sender, EventArgs e)
        {
            if (!_mirrorDocumentId.HasValue)
            {
                SetMirrorStatus(L.T("Open a document inside the mirror first.",
                    "请先在镜像中打开一个文档。"), Palette.Amber);
                return;
            }
            EscriptoriumModelInfo model = _htrModelBox == null
                ? null
                : _htrModelBox.SelectedItem as EscriptoriumModelInfo;
            EscriptoriumTranscriptionInfo transcription = _transcriptionBox == null
                ? null
                : _transcriptionBox.SelectedItem as EscriptoriumTranscriptionInfo;
            if (model == null || transcription == null)
            {
                SetMirrorStatus(L.T("Select a Recognition model and transcription layer.",
                    "请选择 Recognition 模型和转录层。"), Palette.Amber);
                return;
            }
            try
            {
                if (_escriptoriumApi == null)
                    _escriptoriumApi = new EscriptoriumApiClient(_settings);
                await _escriptoriumApi.TranscribeDocumentAsync(
                    _mirrorDocumentId.Value, transcription.Pk, model.Pk);
                SetMirrorStatus(String.Format(
                    L.T("HTR task submitted with “{0}”.", "已使用“{0}”提交 HTR 任务。"),
                    model.Name), Palette.Gold);
                if (_mirrorView != null)
                    _mirrorView.Reload();
            }
            catch (Exception ex)
            {
                SetMirrorStatus(L.T("HTR task failed: ", "HTR 任务失败：") + ex.Message,
                    Palette.Red);
            }
        }

        private void SetMirrorStatus(string message, Color color)
        {
            if (_mirrorStatusLabel == null)
                return;
            if (IsHandleCreated && InvokeRequired)
            {
                BeginInvoke(new Action<string, Color>(SetMirrorStatus), message, color);
                return;
            }
            _mirrorStatusLabel.Text = message;
            _mirrorStatusLabel.ForeColor = color;
        }

        private Control BuildGroupsPage()
        {
            if (_processingProject == null)
                _processingProject = ProcessingProjectStore.LoadOrCreate();
            TableLayoutPanel root = VerticalRoot();
            root.AutoSize = false;
            root.Dock = DockStyle.Fill;
            root.RowStyles.Clear();
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 84));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            root.Controls.Add(SectionTitle(
                L.T("Processing groups", "分组处理"),
                L.T(
                    "Group pages by hand, archive series or model, then run the page-node pipeline as a resumable batch.",
                    "按书写者、档案系列或模型将页面分组，并以可继续的批处理方式运行按页节点流程。")), 0, 0);

            FlowLayoutPanel toolbar = new FlowLayoutPanel();
            toolbar.Dock = DockStyle.Fill;
            toolbar.WrapContents = false;
            toolbar.Padding = new Padding(0, 2, 0, 0);
            Button autoGroup = Ui.Button(L.T("Auto-group by page", "按页自动分组"), true);
            autoGroup.Width = 158;
            autoGroup.Click += AutoGroupByPageClick;
            toolbar.Controls.Add(autoGroup);
            Button newGroup = Ui.Button(L.T("New group", "新建分组"), false);
            newGroup.Width = 108;
            newGroup.Click += delegate { ClearGroupEditor(); };
            toolbar.Controls.Add(newGroup);
            Button saveProject = Ui.Button(L.T("Save project", "保存项目"), false);
            saveProject.Width = 118;
            saveProject.Click += delegate { SaveProcessingProject(); };
            toolbar.Controls.Add(saveProject);
            Button reload = Ui.Button(L.T("Reload project", "重新载入"), false);
            reload.Width = 118;
            reload.Click += delegate
            {
                _processingProject = ProcessingProjectStore.LoadOrCreate();
                RefreshGroupsGrid();
            };
            toolbar.Controls.Add(reload);
            root.Controls.Add(toolbar, 0, 1);

            SplitContainer split = new SplitContainer();
            split.Dock = DockStyle.Fill;
            split.FixedPanel = FixedPanel.Panel1;
            split.SplitterWidth = 7;
            split.BackColor = Palette.Line;
            bool splitReady = false;
            split.SizeChanged += delegate
            {
                if (splitReady || split.Width < 760)
                    return;
                try
                {
                    split.Panel1MinSize = 380;
                    split.Panel2MinSize = 340;
                    split.SplitterDistance = Math.Max(430, (int)(split.Width * 0.48));
                    splitReady = true;
                }
                catch
                {
                }
            };
            root.Controls.Add(split, 0, 2);

            _groupsGrid = new DataGridView();
            _groupsGrid.Dock = DockStyle.Fill;
            _groupsGrid.AllowUserToAddRows = false;
            _groupsGrid.AllowUserToDeleteRows = false;
            _groupsGrid.ReadOnly = true;
            _groupsGrid.RowHeadersVisible = false;
            _groupsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _groupsGrid.MultiSelect = false;
            _groupsGrid.BackgroundColor = Palette.Paper;
            _groupsGrid.BorderStyle = BorderStyle.None;
            _groupsGrid.EnableHeadersVisualStyles = false;
            _groupsGrid.ColumnHeadersDefaultCellStyle.BackColor = Palette.Deep;
            _groupsGrid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            _groupsGrid.ColumnHeadersDefaultCellStyle.Font = Ui.BodyBold;
            _groupsGrid.ColumnHeadersHeight = 36;
            _groupsGrid.DefaultCellStyle.Font = Ui.BodySmall;
            _groupsGrid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(226, 236, 232);
            _groupsGrid.DefaultCellStyle.SelectionForeColor = Palette.Ink;
            _groupsGrid.RowTemplate.Height = 31;
            AddGroupGridColumnInstance("Group", 180, true);
            AddGroupGridColumnInstance("Pages", 90, false);
            AddGroupGridColumnInstance("Status", 95, false);
            AddGroupGridColumnInstance("LastRun", 128, false);
            _groupsGrid.SelectionChanged += GroupGridSelectionChanged;
            split.Panel1.Controls.Add(_groupsGrid);

            Panel editor = new Panel();
            editor.Dock = DockStyle.Fill;
            editor.BackColor = Palette.Card;
            editor.Padding = new Padding(16);
            split.Panel2.Controls.Add(editor);

            Label editorTitle = Ui.Label(L.T("Group settings", "分组设置"),
                Ui.Heading, Palette.Ink, 360);
            editorTitle.SetBounds(16, 13, 380, 31);
            editor.Controls.Add(editorTitle);

            _groupNameBox = GroupField(editor, L.T("Group name", "分组名称"), 54);
            _groupPagesBox = GroupField(editor,
                L.T("Pages (for example 1-8,12)", "页码（例如 1-8,12）"), 109);
            _groupTargetBox = GroupField(editor,
                L.T("Target language", "目标语言"), 164);
            _groupTargetBox.Text = _settings.TargetLanguage;

            Label concurrencyLabel = Ui.Label(L.T("Page concurrency", "页面并发"),
                Ui.BodySmall, Palette.Muted, 400);
            concurrencyLabel.SetBounds(16, 218, 400, 20);
            editor.Controls.Add(concurrencyLabel);
            _groupConcurrencyBox = new ComboBox();
            _groupConcurrencyBox.DropDownStyle = ComboBoxStyle.DropDownList;
            _groupConcurrencyBox.Items.AddRange(new object[]
            {
                "1 — Laptop / 笔记本",
                "2 — Standard / 标准",
                "4 — Workstation / 工作站"
            });
            _groupConcurrencyBox.SelectedIndex = 0;
            _groupConcurrencyBox.SetBounds(16, 239, 280, 28);
            editor.Controls.Add(_groupConcurrencyBox);

            Button saveGroup = Ui.Button(L.T("Create / update group", "新建 / 更新分组"), true);
            saveGroup.SetBounds(16, 280, 176, 36);
            saveGroup.Click += SaveGroupClick;
            editor.Controls.Add(saveGroup);
            Button deleteGroup = Ui.Button(L.T("Delete group", "删除分组"), false);
            deleteGroup.SetBounds(202, 280, 120, 36);
            deleteGroup.Click += DeleteGroupClick;
            editor.Controls.Add(deleteGroup);

            Button runSelected = Ui.Button(L.T("Run selected", "运行当前分组"), true);
            runSelected.SetBounds(16, 326, 136, 36);
            runSelected.Click += async delegate { await RunSelectedGroupAsync(); };
            editor.Controls.Add(runSelected);
            Button runAll = Ui.Button(L.T("Run all groups", "运行全部分组"), true);
            runAll.SetBounds(162, 326, 142, 36);
            runAll.Click += async delegate { await RunAllGroupsAsync(); };
            editor.Controls.Add(runAll);
            _groupPauseButton = Ui.Button(L.T("Pause", "暂停"), false);
            _groupPauseButton.SetBounds(314, 326, 88, 36);
            _groupPauseButton.Click += ToggleGroupPause;
            editor.Controls.Add(_groupPauseButton);
            Button cancel = Ui.Button(L.T("Stop", "停止"), false);
            cancel.SetBounds(412, 326, 82, 36);
            cancel.Click += delegate
            {
                if (_groupCancellation != null)
                    _groupCancellation.Cancel();
            };
            editor.Controls.Add(cancel);

            _groupsStatusLabel = Ui.Label(GroupsSummary(), Ui.BodySmall,
                Palette.Amber, 780);
            _groupsStatusLabel.SetBounds(16, 372, 800, 45);
            _groupsStatusLabel.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            editor.Controls.Add(_groupsStatusLabel);

            _groupOutputBox = new TextBox();
            _groupOutputBox.Multiline = true;
            _groupOutputBox.ReadOnly = true;
            _groupOutputBox.ScrollBars = ScrollBars.Both;
            _groupOutputBox.WordWrap = true;
            _groupOutputBox.BorderStyle = BorderStyle.FixedSingle;
            _groupOutputBox.Font = Ui.Body;
            _groupOutputBox.BackColor = Color.White;
            _groupOutputBox.ForeColor = Palette.Ink;
            _groupOutputBox.SetBounds(16, 425, 560, 200);
            _groupOutputBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom |
                AnchorStyles.Left | AnchorStyles.Right;
            editor.Controls.Add(_groupOutputBox);

            RefreshGroupsGrid();
            return root;
        }

        private static TextBox GroupField(Control parent, string caption, int y)
        {
            Label label = Ui.Label(caption, Ui.BodySmall, Palette.Muted, 700);
            label.SetBounds(16, y, 700, 20);
            parent.Controls.Add(label);
            TextBox box = Ui.TextBox("", false, false);
            box.SetBounds(16, y + 21, 540, 29);
            box.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            parent.Controls.Add(box);
            return box;
        }

        private void AddGroupGridColumnInstance(string name, int width, bool fill)
        {
            DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
            column.Name = name;
            column.HeaderText = L.T(name, name == "Group" ? "分组" :
                name == "Pages" ? "页码" : name == "Status" ? "状态" : "上次运行");
            column.Width = width;
            if (fill)
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            column.SortMode = DataGridViewColumnSortMode.NotSortable;
            _groupsGrid.Columns.Add(column);
        }

        private string GroupsSummary()
        {
            int groups = _processingProject == null ? 0 : _processingProject.Groups.Count;
            int completed = _processingProject == null ? 0 :
                _processingProject.Groups.Count(group => group.Status == "Completed");
            int failed = _processingProject == null ? 0 :
                _processingProject.Groups.Count(group => group.Status == "Failed");
            return String.Format(
                L.T("{0} imported lines · {1} groups · {2} completed · {3} failed\nProject file: {4}",
                    "已导入 {0} 行 · {1} 个分组 · {2} 个完成 · {3} 个失败\n项目文件：{4}"),
                _lines.Count, groups, completed, failed,
                ProcessingProjectStore.ProjectFile);
        }

        private void RefreshGroupsGrid()
        {
            if (_groupsGrid == null || _groupsGrid.IsDisposed || _processingProject == null)
                return;
            string selectedId = SelectedGroup() == null ? String.Empty : SelectedGroup().Id;
            _selectingGroupRow = true;
            try
            {
                _groupsGrid.Rows.Clear();
                foreach (ProcessingGroup group in _processingProject.Groups
                    .OrderBy(item => item.Name, StringComparer.CurrentCultureIgnoreCase))
                {
                    int index = _groupsGrid.Rows.Add(
                        group.Name,
                        group.PageLabel,
                        group.Status,
                        group.LastRunAt.HasValue
                            ? group.LastRunAt.Value.ToString("MM-dd HH:mm")
                            : "—");
                    _groupsGrid.Rows[index].Tag = group;
                    if (group.Id == selectedId)
                        _groupsGrid.Rows[index].Selected = true;
                }
            }
            finally
            {
                _selectingGroupRow = false;
            }
            if (_groupsStatusLabel != null)
                _groupsStatusLabel.Text = GroupsSummary();
        }

        private void GroupGridSelectionChanged(object sender, EventArgs e)
        {
            if (_selectingGroupRow)
                return;
            ProcessingGroup group = SelectedGroup();
            if (group == null)
                return;
            _groupNameBox.Text = group.Name;
            _groupPagesBox.Text = group.PageLabel;
            _groupTargetBox.Text = String.IsNullOrWhiteSpace(group.TargetLanguage)
                ? _settings.TargetLanguage
                : group.TargetLanguage;
            _groupConcurrencyBox.SelectedIndex = group.Concurrency >= 4 ? 2 :
                group.Concurrency == 2 ? 1 : 0;
            _groupOutputBox.Text = group.LastTranslation ?? String.Empty;
        }

        private ProcessingGroup SelectedGroup()
        {
            if (_groupsGrid == null || _groupsGrid.CurrentRow == null)
                return null;
            return _groupsGrid.CurrentRow.Tag as ProcessingGroup;
        }

        private void ClearGroupEditor()
        {
            if (_groupsGrid != null)
                _groupsGrid.ClearSelection();
            _groupNameBox.Text = String.Empty;
            _groupPagesBox.Text = String.Empty;
            _groupTargetBox.Text = _settings.TargetLanguage;
            _groupConcurrencyBox.SelectedIndex = 0;
            _groupOutputBox.Text = String.Empty;
            _groupNameBox.Focus();
        }

        private void SaveGroupClick(object sender, EventArgs e)
        {
            ParsedPages pages = ProcessingProjectStore.ParsePages(_groupPagesBox.Text);
            if (!String.IsNullOrWhiteSpace(pages.Error))
            {
                MessageBox.Show(pages.Error, L.T("Invalid pages", "页码无效"),
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ProcessingGroup group = SelectedGroup();
            if (group == null)
            {
                group = new ProcessingGroup();
                _processingProject.Groups.Add(group);
            }
            group.Name = String.IsNullOrWhiteSpace(_groupNameBox.Text)
                ? L.T("Group pages ", "分组页码 ") + ProcessingProjectStore.FormatPages(pages.Pages)
                : _groupNameBox.Text.Trim();
            group.Pages = pages.Pages;
            group.TargetLanguage = String.IsNullOrWhiteSpace(_groupTargetBox.Text)
                ? _settings.TargetLanguage
                : _groupTargetBox.Text.Trim();
            group.SourceLanguage = _settings.SourceLanguage;
            group.Concurrency = _groupConcurrencyBox.SelectedIndex == 2 ? 4 :
                _groupConcurrencyBox.SelectedIndex == 1 ? 2 : 1;
            if (group.Status != "Completed")
                group.Status = "Pending";
            SaveProcessingProject();
            RefreshGroupsGrid();
            SelectGroupById(group.Id);
        }

        private void SelectGroupById(string id)
        {
            if (_groupsGrid == null)
                return;
            foreach (DataGridViewRow row in _groupsGrid.Rows)
            {
                ProcessingGroup group = row.Tag as ProcessingGroup;
                if (group != null && group.Id == id)
                {
                    row.Selected = true;
                    _groupsGrid.CurrentCell = row.Cells[0];
                    return;
                }
            }
        }

        private void DeleteGroupClick(object sender, EventArgs e)
        {
            ProcessingGroup group = SelectedGroup();
            if (group == null)
                return;
            DialogResult answer = MessageBox.Show(
                L.T("Delete this group definition? Imported lines and files will not be deleted.",
                    "删除此分组定义吗？已导入的行和文件不会被删除。"),
                L.T("Delete group", "删除分组"),
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (answer != DialogResult.Yes)
                return;
            _processingProject.Groups.Remove(group);
            SaveProcessingProject();
            RefreshGroupsGrid();
            ClearGroupEditor();
        }

        private void AutoGroupByPageClick(object sender, EventArgs e)
        {
            if (_lines.Count == 0)
            {
                MessageBox.Show(
                    AiErrors.Create(AiErrorCode.NoInputLines, "Imported line count: 0").UserMessage,
                    AiErrorCode.NoInputLines + " · " + L.T("Nothing to group", "没有可分组文本"),
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int added = 0;
            foreach (int page in _lines.Select(line => line.Page).Distinct().OrderBy(page => page))
            {
                bool exists = _processingProject.Groups.Any(item =>
                    item.Pages.Count == 1 && item.Pages[0] == page);
                if (exists)
                    continue;
                ProcessingGroup group = new ProcessingGroup();
                group.Name = L.T("Page ", "第 ") + page + L.T(" group", " 页分组");
                group.Pages = new List<int> { page };
                group.SourceLanguage = _settings.SourceLanguage;
                group.TargetLanguage = _settings.TargetLanguage;
                group.Concurrency = 1;
                _processingProject.Groups.Add(group);
                added++;
            }
            SaveProcessingProject();
            RefreshGroupsGrid();
            if (_groupsStatusLabel != null)
                _groupsStatusLabel.Text = String.Format(
                    L.T("Created {0} page groups. {1}", "已创建 {0} 个按页分组。{1}"),
                    added, GroupsSummary());
        }

        private void SaveProcessingProject()
        {
            try
            {
                ProcessingProjectStore.Save(_processingProject);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, L.T("Project save failed", "项目保存失败"),
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async Task RunSelectedGroupAsync()
        {
            ProcessingGroup group = SelectedGroup();
            if (group == null)
                return;
            await RunGroupsAsync(new List<ProcessingGroup> { group });
        }

        private async Task RunAllGroupsAsync()
        {
            await RunGroupsAsync(_processingProject.Groups
                .OrderBy(group => group.Pages.FirstOrDefault())
                .ThenBy(group => group.Name)
                .ToList());
        }

        private async Task RunGroupsAsync(IList<ProcessingGroup> groups)
        {
            if (_groupBusy)
                return;
            if (_lines.Count == 0)
            {
                MessageBox.Show(
                    AiErrors.Create(AiErrorCode.NoInputLines, "Imported line count: 0").UserMessage,
                    AiErrorCode.NoInputLines + " · " + L.T("No input", "没有输入"),
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!_ai.IsConfigured(_settings))
            {
                AiRequestException error = AiErrors.Create(
                    AiErrorCode.ConfigurationRequired,
                    "Endpoint: " + _settings.AiEndpoint + "\nModel: " + _settings.AiModel);
                MessageBox.Show(error.UserMessage,
                    error.Code + " · " + L.T("AI configuration", "AI 配置"),
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _groupBusy = true;
            _groupPaused = false;
            _groupPauseButton.Text = L.T("Pause", "暂停");
            _groupCancellation = new CancellationTokenSource();
            CancellationToken token = _groupCancellation.Token;
            SetHeaderStatus(L.T("Processing groups…", "正在处理分组…"), Palette.Gold);
            try
            {
                foreach (ProcessingGroup group in groups)
                {
                    token.ThrowIfCancellationRequested();
                    while (_groupPaused)
                    {
                        UpdateGroupStatusThreadSafe(group, "Paused",
                            L.T("Paused after the current group; choose Resume to continue.",
                                "当前分组结束后暂停；点击“继续”恢复。"));
                        await Task.Delay(400, token);
                    }

                    List<TranscriptionLine> selectedLines = _lines
                        .Where(line => group.Pages.Contains(line.Page))
                        .ToList();
                    if (selectedLines.Count == 0)
                    {
                        UpdateGroupStatusThreadSafe(group, "Failed",
                            L.T("No imported line matches this group's pages.",
                                "此分组的页码没有匹配已导入的行。"));
                        SaveProcessingProject();
                        continue;
                    }

                    UpdateGroupStatusThreadSafe(group, "Running",
                        L.T("Processing page nodes…", "正在处理页面节点…"));
                    AppSettings groupSettings = _settings.Clone();
                    groupSettings.SourceLanguage = String.IsNullOrWhiteSpace(group.SourceLanguage)
                        ? _settings.SourceLanguage : group.SourceLanguage;
                    groupSettings.TargetLanguage = String.IsNullOrWhiteSpace(group.TargetLanguage)
                        ? _settings.TargetLanguage : group.TargetLanguage;
                    groupSettings.PageConcurrency = group.Concurrency;
                    try
                    {
                        ContextTranslationResult result = await _ai.TranslateDocumentAsync(
                            selectedLines,
                            groupSettings,
                            delegate(int completed, int total)
                            {
                                UpdateGroupStatusThreadSafe(group, "Running", String.Format(
                                    L.T("Page node {0} / {1}", "页面节点 {0} / {1}"),
                                    completed, total));
                            },
                            group.Concurrency,
                            token);
                        group.Status = "Completed";
                        group.LastMessage = String.Format(
                            L.T("Completed {0} page node(s), {1} line(s).",
                                "已完成 {0} 个页面节点、{1} 行。"),
                            result.ChunkCount, result.LineCount);
                        group.LastRunAt = DateTime.Now;
                        group.LastTranslation = result.Translation;
                        group.LastCleanse = result.CleanseText;
                    }
                    catch (OperationCanceledException)
                    {
                        group.Status = "Canceled";
                        group.LastMessage = L.T("Stopped by user.", "已由用户停止。");
                        throw;
                    }
                    catch (AiRequestException ex)
                    {
                        group.Status = "Failed";
                        group.LastMessage = ex.Code + " · " + ex.EnglishExplanation +
                            " / " + ex.ChineseExplanation;
                    }
                    catch (Exception ex)
                    {
                        group.Status = "Failed";
                        group.LastMessage = ex.Message;
                    }
                    SaveProcessingProject();
                    RefreshGroupsUiThreadSafe();
                }
                SetHeaderStatus(L.T("Group batch finished", "分组批处理结束"), Palette.Green);
            }
            catch (OperationCanceledException)
            {
                SetHeaderStatus(L.T("Group batch stopped", "分组批处理已停止"), Palette.Amber);
            }
            finally
            {
                _groupBusy = false;
                _groupPaused = false;
                if (_groupPauseButton != null)
                    _groupPauseButton.Text = L.T("Pause", "暂停");
                if (_groupCancellation != null)
                {
                    _groupCancellation.Dispose();
                    _groupCancellation = null;
                }
                SaveProcessingProject();
                RefreshGroupsUiThreadSafe();
            }
        }

        private void ToggleGroupPause(object sender, EventArgs e)
        {
            if (!_groupBusy)
                return;
            _groupPaused = !_groupPaused;
            _groupPauseButton.Text = _groupPaused
                ? L.T("Resume", "继续")
                : L.T("Pause", "暂停");
            if (_groupsStatusLabel != null)
                _groupsStatusLabel.Text = _groupPaused
                    ? L.T("Pause requested. The current group will finish, then the queue will wait.",
                        "已请求暂停。当前分组完成后队列将等待。")
                    : L.T("Resuming group queue.", "正在继续分组队列。");
        }

        private void UpdateGroupStatusThreadSafe(
            ProcessingGroup group, string status, string message)
        {
            group.Status = status;
            group.LastMessage = message;
            if (IsHandleCreated && InvokeRequired)
            {
                BeginInvoke(new Action(delegate
                {
                    if (_groupsStatusLabel != null)
                        _groupsStatusLabel.Text = group.Name + " · " + message + "\n" + GroupsSummary();
                }));
                return;
            }
            if (_groupsStatusLabel != null)
                _groupsStatusLabel.Text = group.Name + " · " + message + "\n" + GroupsSummary();
        }

        private void RefreshGroupsUiThreadSafe()
        {
            if (IsHandleCreated && InvokeRequired)
            {
                BeginInvoke(new Action(RefreshGroupsUiThreadSafe));
                return;
            }
            RefreshGroupsGrid();
            ProcessingGroup selected = SelectedGroup();
            if (selected != null && _groupOutputBox != null)
                _groupOutputBox.Text = selected.LastTranslation ?? String.Empty;
        }

        private Control BuildSettingsPage()
        {
            TableLayoutPanel root = VerticalRoot();
            AddFixedRows(root, 84, 430, 260, 110);
            root.Controls.Add(SectionTitle(
                L.T("Settings", "设置"),
                L.T("Configure the translation provider and inspect local connection details.",
                    "配置翻译服务，并查看本机连接信息。")), 0, 0);

            RoundedPanel aiCard = new RoundedPanel();
            aiCard.Dock = DockStyle.Fill;
            aiCard.MinimumSize = new Size(0, 315);
            aiCard.Margin = new Padding(0, 0, 0, 14);
            Label aiTitle = Ui.Label("AI TRANSLATION", Ui.BodyBold, Palette.Accent, 300);
            aiTitle.Font = new Font(Ui.BodyBold.FontFamily, 8.5f, FontStyle.Bold);
            aiTitle.SetBounds(20, 15, 300, 22);
            aiCard.Controls.Add(aiTitle);

            _aiEndpoint = SettingsField(aiCard, L.T("OpenAI-compatible endpoint", "OpenAI 兼容接口"), 48,
                _settings.AiEndpoint, false);
            _aiKey = SettingsField(aiCard, L.T("API key", "API Key"), 103,
                _settings.GetAiApiKey(), true);
            _aiModel = SettingsField(aiCard, L.T("Model", "模型"), 158, _settings.AiModel, false);
            _sourceLanguage = SettingsField(aiCard, L.T("Source language", "源语言"), 213,
                _settings.SourceLanguage, false);
            _targetLanguage = SettingsField(aiCard, L.T("Target language", "目标语言"), 268,
                _settings.TargetLanguage, false);
            _targetLanguage.Width = 600;
            _targetLanguage.Anchor = AnchorStyles.Top | AnchorStyles.Left;

            Label concurrencyCaption = Ui.Label(
                L.T("Page concurrency", "页面并发"),
                Ui.BodySmall,
                Palette.Muted,
                240);
            concurrencyCaption.SetBounds(650, 268, 240, 20);
            aiCard.Controls.Add(concurrencyCaption);
            _pageConcurrencyBox = new ComboBox();
            _pageConcurrencyBox.DropDownStyle = ComboBoxStyle.DropDownList;
            _pageConcurrencyBox.Items.AddRange(new object[]
            {
                "1 — Laptop / 笔记本",
                "2 — Standard / 标准",
                "4 — Workstation / 工作站"
            });
            _pageConcurrencyBox.SelectedIndex = _settings.PageConcurrency >= 4 ? 2 :
                _settings.PageConcurrency == 2 ? 1 : 0;
            _pageConcurrencyBox.SetBounds(650, 290, 240, 28);
            aiCard.Controls.Add(_pageConcurrencyBox);

            _showSecrets = new CheckBox();
            _showSecrets.Text = L.T("Show secret", "显示密钥");
            _showSecrets.Font = Ui.BodySmall;
            _showSecrets.AutoSize = true;
            _showSecrets.SetBounds(760, 103, 130, 24);
            _showSecrets.CheckedChanged += delegate { _aiKey.UseSystemPasswordChar = !_showSecrets.Checked; };
            aiCard.Controls.Add(_showSecrets);

            Button save = Ui.Button(L.T("Save settings", "保存设置"), true);
            save.SetBounds(20, 320, 136, 36);
            save.Click += delegate { CaptureSettingsFromControls(true); ToastSettingsSaved(); };
            aiCard.Controls.Add(save);
            Button test = Ui.Button(L.T("Test one line", "测试单行翻译"), false);
            test.SetBounds(168, 320, 148, 36);
            test.Click += TestAiClick;
            aiCard.Controls.Add(test);

            Label aiNotice = Ui.Label(
                L.T(
                    "API Key is your AI provider credential, not the eScriptorium password. AI errors are reported as AIC001–AIC017; AIC004 automatically tries the local Python/OpenSSL transport.",
                    "API Key 是 AI 服务商凭据，不是 eScriptorium 登录密码。AI 错误以 AIC001–AIC017 显示；出现 AIC004 时会自动尝试本机 Python/OpenSSL 通道。"),
                Ui.BodySmall,
                Palette.Amber,
                900);
            aiNotice.SetBounds(20, 366, 900, 50);
            aiNotice.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            aiCard.Controls.Add(aiNotice);
            root.Controls.Add(aiCard, 0, 1);

            RoundedPanel serverCard = new RoundedPanel();
            serverCard.Dock = DockStyle.Fill;
            serverCard.MinimumSize = new Size(0, 216);
            serverCard.Margin = new Padding(0, 0, 0, 14);
            Label serverTitle = Ui.Label(L.T("LOCAL SERVER", "本机服务"), Ui.BodyBold, Palette.Blue, 300);
            serverTitle.Font = new Font(Ui.BodyBold.FontFamily, 8.5f, FontStyle.Bold);
            serverTitle.SetBounds(20, 16, 300, 22);
            serverCard.Controls.Add(serverTitle);

            _dockerStatusLabel = Ui.Label(L.T("Docker: checking…", "Docker：检查中…"), Ui.Body, Palette.Ink, 460);
            _dockerStatusLabel.SetBounds(20, 49, 520, 25);
            serverCard.Controls.Add(_dockerStatusLabel);
            _serviceStatusLabel = Ui.Label(L.T("eScriptorium: checking…", "eScriptorium：检查中…"),
                Ui.Body, Palette.Ink, 460);
            _serviceStatusLabel.SetBounds(20, 79, 520, 25);
            serverCard.Controls.Add(_serviceStatusLabel);
            Label url = Ui.Label("http://localhost:8080/", Ui.BodyBold, Palette.Blue, 420);
            url.SetBounds(20, 113, 420, 25);
            serverCard.Controls.Add(url);

            Label passwordCaption = Ui.Label(
                L.T("Administrator: " + _settings.AdminUser + "   Password:",
                    "管理员：" + _settings.AdminUser + "   密码："),
                Ui.BodySmall,
                Palette.Muted,
                460);
            passwordCaption.SetBounds(20, 149, 470, 22);
            serverCard.Controls.Add(passwordCaption);
            _passwordValue = Ui.Label(MaskSecret(_settings.GetEscriptoriumPassword()),
                Ui.BodyBold, Palette.Ink, 380);
            _passwordValue.SetBounds(202, 146, 400, 26);
            serverCard.Controls.Add(_passwordValue);
            Button reveal = Ui.Button(L.T("Reveal", "显示"), false);
            reveal.SetBounds(20, 178, 88, 31);
            reveal.Click += delegate
            {
                _passwordValue.Text = String.IsNullOrEmpty(_settings.GetEscriptoriumPassword())
                    ? L.T("(not generated yet)", "（尚未生成）")
                    : _settings.GetEscriptoriumPassword();
            };
            serverCard.Controls.Add(reveal);
            Button copy = Ui.Button(L.T("Copy", "复制"), false);
            copy.SetBounds(118, 178, 80, 31);
            copy.Click += delegate
            {
                if (!String.IsNullOrEmpty(_settings.GetEscriptoriumPassword()))
                    Clipboard.SetText(_settings.GetEscriptoriumPassword());
            };
            serverCard.Controls.Add(copy);
            Button openServer = Ui.Button(L.T("Open server", "打开服务"), true);
            openServer.SetBounds(208, 178, 122, 31);
            openServer.Click += delegate { _engine.OpenService(); };
            serverCard.Controls.Add(openServer);

            Label serverNotice = Ui.Label(
                L.T(
                    "This account signs in to eScriptorium on localhost:8080. It is independent from the AI API key.",
                    "此账号仅用于登录 localhost:8080 的 eScriptorium，与 AI API Key 相互独立。"),
                Ui.BodySmall,
                Palette.Muted,
                900);
            serverNotice.SetBounds(20, 220, 900, 25);
            serverNotice.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            serverCard.Controls.Add(serverNotice);
            root.Controls.Add(serverCard, 0, 2);

            RoundedPanel privacy = new RoundedPanel();
            privacy.Dock = DockStyle.Fill;
            privacy.MinimumSize = new Size(0, 100);
            privacy.FillColor = Color.FromArgb(248, 241, 220);
            privacy.BorderColor = Color.FromArgb(225, 205, 157);
            Label privacyTitle = Ui.Label(L.T("Data and privacy", "数据与隐私"), Ui.BodyBold, Palette.Amber, 300);
            privacyTitle.SetBounds(20, 13, 300, 24);
            privacy.Controls.Add(privacyTitle);
            Label privacyText = Ui.Label(
                L.T(
                    "Manuscripts, coordinates and analysis are processed locally. Only the original/cleaned line text and your translation fields are sent to the AI endpoint when you press an AI action. For sensitive collections, use a local endpoint or leave AI unconfigured.",
                    "手稿、坐标和分析均在本机处理。只有在您点击 AI 操作时，原文/清洗文本及翻译字段才会发送到所配置的 AI 接口。敏感藏品建议使用本机模型接口，或不配置 AI。"),
                Ui.BodySmall,
                Palette.Muted,
                910);
            privacyText.SetBounds(20, 40, 910, 55);
            privacyText.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            privacy.Controls.Add(privacyText);
            root.Controls.Add(privacy, 0, 3);
            return root;
        }

        private static TableLayoutPanel VerticalRoot()
        {
            TableLayoutPanel root = new TableLayoutPanel();
            root.ColumnCount = 1;
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            root.RowCount = 4;
            root.Dock = DockStyle.Fill;
            root.AutoSize = true;
            root.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            root.BackColor = Palette.Parchment;
            root.Margin = new Padding(0);
            root.Padding = new Padding(0);
            return root;
        }

        private static void AddFixedRows(TableLayoutPanel root, params int[] heights)
        {
            root.RowStyles.Clear();
            foreach (int height in heights)
                root.RowStyles.Add(new RowStyle(SizeType.Absolute, height));
        }

        private static Control ScrollingPage(Control root)
        {
            Panel page = new Panel();
            page.BackColor = Palette.Parchment;
            page.Dock = DockStyle.Fill;
            page.AutoScroll = true;
            page.Padding = new Padding(0);
            root.Dock = DockStyle.Top;
            page.Controls.Add(root);
            return page;
        }

        private static Control SectionTitle(string title, string subtitle)
        {
            Panel panel = new Panel();
            panel.Dock = DockStyle.Fill;
            panel.Height = 72;
            panel.Margin = new Padding(0, 0, 0, 8);
            Label heading = Ui.Label(title, Ui.Heading, Palette.Ink, 860);
            heading.SetBounds(0, 0, 860, 34);
            panel.Controls.Add(heading);
            Label sub = Ui.Label(subtitle, Ui.Body, Palette.Muted, 900);
            sub.SetBounds(1, 35, 900, 27);
            panel.Controls.Add(sub);
            return panel;
        }

        private static RoundedPanel StatusCard(string eyebrow, string value, bool ok, string description)
        {
            RoundedPanel card = new RoundedPanel();
            card.Dock = DockStyle.Fill;
            card.Margin = new Padding(0, 0, 10, 0);
            card.FillColor = Palette.Card;
            card.BorderColor = Palette.Line;
            Label tag = Ui.Label(eyebrow, Ui.BodySmall, Palette.Muted, 260);
            tag.Font = new Font(Ui.BodySmall.FontFamily, 8.2f, FontStyle.Bold);
            tag.SetBounds(18, 15, 280, 20);
            card.Controls.Add(tag);
            Label valueLabel = Ui.Label(value, Ui.Heading, ok ? Palette.Green : Palette.Amber, 300);
            valueLabel.Font = new Font(Ui.Heading.FontFamily, 15f, FontStyle.Bold);
            valueLabel.SetBounds(18, 38, 300, 30);
            card.Controls.Add(valueLabel);
            Label descriptionLabel = Ui.Label(description, Ui.BodySmall, Palette.Muted, 315);
            descriptionLabel.SetBounds(18, 76, 260, 50);
            card.Controls.Add(descriptionLabel);
            card.Resize += delegate
            {
                int width = Math.Max(120, card.ClientSize.Width - 36);
                descriptionLabel.MaximumSize = new Size(width, 0);
                descriptionLabel.Width = width;
            };
            return card;
        }

        private static void AddWorkflowStep(
            Control parent, int x, int y, string number, string title, string detail)
        {
            Label num = Ui.Label(number, new Font(Ui.BodyBold.FontFamily, 10f, FontStyle.Bold),
                Palette.Accent, 35);
            num.SetBounds(x, y, 32, 22);
            parent.Controls.Add(num);
            Label heading = Ui.Label(title, Ui.BodyBold, Palette.Ink, 195);
            heading.SetBounds(x + 34, y - 2, 195, 24);
            parent.Controls.Add(heading);
            Label description = Ui.Label(detail, Ui.BodySmall, Palette.Muted, 195);
            description.SetBounds(x + 34, y + 23, 195, 45);
            parent.Controls.Add(description);
        }

        private static void AddStage(Control parent, int index, string title, string detail, bool ok)
        {
            int y = 18 + (index - 1) * 47;
            StepBadge badge = new StepBadge();
            badge.Number = index.ToString();
            badge.Done = ok;
            badge.Color = ok ? Palette.Green : Palette.Muted;
            badge.SetBounds(22, y, 32, 32);
            parent.Controls.Add(badge);
            Label heading = Ui.Label(title, Ui.BodyBold, Palette.Ink, 260);
            heading.SetBounds(68, y - 1, 260, 24);
            parent.Controls.Add(heading);
            Label desc = Ui.Label(detail, Ui.BodySmall, Palette.Muted, 620);
            desc.SetBounds(305, y, 620, 24);
            parent.Controls.Add(desc);
        }

        private static TextBox DetailBox(string caption, Control parent, int y)
        {
            Label label = Ui.Label(caption, Ui.BodySmall, Palette.Muted, 260);
            label.SetBounds(16, y, 260, 20);
            parent.Controls.Add(label);
            TextBox box = Ui.TextBox("", true, false);
            box.SetBounds(16, y + 21, 260, 66);
            box.ScrollBars = ScrollBars.Vertical;
            parent.Controls.Add(box);
            return box;
        }

        private void AddGridColumn(string property, string header, int width, bool fill)
        {
            DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = property;
            column.HeaderText = header;
            column.Width = width;
            column.MinimumWidth = Math.Min(width, 50);
            if (fill)
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            column.DefaultCellStyle.WrapMode = DataGridViewTriState.False;
            _linesGrid.Columns.Add(column);
        }

        private static TextBox SettingsField(
            Control parent, string caption, int y, string value, bool password)
        {
            Label label = Ui.Label(caption, Ui.BodySmall, Palette.Muted, 680);
            label.SetBounds(20, y, 680, 20);
            parent.Controls.Add(label);
            TextBox box = Ui.TextBox(value, false, password);
            box.SetBounds(20, y + 22, 900, 29);
            box.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            parent.Controls.Add(box);
            return box;
        }

        private void SetLanguage(bool chinese)
        {
            if (_page == "settings")
                CaptureSettingsFromControls(false);
            L.Zh = chinese;
            LocalizeLineStatuses();
            Text = L.T("eScriptorium Studio · EN / 中文", "eScriptorium 手稿工作台 · EN / 中文");
            if (_headerSubtitle != null)
                _headerSubtitle.Text = L.T(
                    "Early modern manuscript lab · install, transcribe, align, translate",
                    "早期现代手稿实验室 · 安装、转录、坐标对齐与翻译");
            if (_footerLabel != null)
                _footerLabel.Text = "LOCAL WORKSPACE\n" +
                    L.T("Data remains on this computer", "数据保存在本机");
            if (_mirrorView != null)
            {
                _mirrorView.Dispose();
                _mirrorView = null;
            }
            UpdateNavLabels();
            UpdateLanguageButtons();
            ShowPage(_page);
            RefreshEnvironmentLabels();
            if (_environment != null)
            {
                if (_environment.DockerRunning && _environment.ServiceReady)
                    SetHeaderStatus(L.T("Workspace online", "工作区在线"), Palette.Green);
                else if (_environment.DockerInstalled)
                    SetHeaderStatus(L.T("Setup available", "可继续配置"), Palette.Amber);
                else
                    SetHeaderStatus(L.T("New installation", "全新安装"), Palette.Muted);
            }
        }

        private void LocalizeLineStatuses()
        {
            foreach (TranscriptionLine line in _lines)
            {
                string status = line.Status ?? String.Empty;
                if (status == "Imported" || status == "已导入")
                    line.Status = L.T("Imported", "已导入");
                else if (status == "No coordinates" || status == "无坐标")
                    line.Status = L.T("No coordinates", "无坐标");
                else if (status == "Locally cleaned" || status == "本地已清洗")
                    line.Status = L.T("Locally cleaned", "本地已清洗");
                else if (status == "AI aligned" || status == "AI 已对齐")
                    line.Status = L.T("AI aligned", "AI 已对齐");
                else if (status == "Reviewed" || status == "已复核")
                    line.Status = L.T("Reviewed", "已复核");
            }
            if (_lineBinding != null)
                _lineBinding.ResetBindings();
        }

        private void UpdateNavLabels()
        {
            string[] keys = { "home", "install", "studio", "ocr", "mirror", "groups", "settings" };
            string[] icons = { "◆", "▦", "⌁", "▧", "◉", "▤", "⚙" };
            string[] en = { "Overview", "Install & run", "Manuscript studio", "Printed OCR", "eScriptorium mirror", "Processing groups", "Settings" };
            string[] zh = { "总览", "安装与运行", "手稿工作台", "印刷文本 OCR", "eScriptorium 镜像", "分组处理", "设置" };
            for (int i = 0; i < keys.Length; i++)
                _navButtons[keys[i]].Text = icons[i] + "  " + (L.Zh ? zh[i] : en[i]);
        }

        private void UpdateLanguageButtons()
        {
            if (_englishButton == null || _chineseButton == null)
                return;
            _englishButton.BackColor = L.Zh ? Palette.Deep : Palette.Accent;
            _englishButton.FlatAppearance.BorderColor = L.Zh ? Color.FromArgb(103, 129, 135) : Palette.Accent;
            _chineseButton.BackColor = L.Zh ? Palette.Accent : Palette.Deep;
            _chineseButton.FlatAppearance.BorderColor = L.Zh ? Palette.Accent : Color.FromArgb(103, 129, 135);
        }

        protected override async void OnShown(EventArgs e)
        {
            base.OnShown(e);
            await RefreshEnvironmentAsync();
            if (_autoInstall)
            {
                ShowPage("install");
                if (_dockerConsent != null)
                    _dockerConsent.Checked = true;
                await RunInstallAsync();
            }
        }

        private async Task RefreshEnvironmentAsync()
        {
            if (_busy)
                return;
            SetHeaderStatus(L.T("Checking local services…", "正在检查本机服务…"), Palette.Amber);
            try
            {
                _environment = await _engine.CheckAsync();
                if (_environment.DockerRunning && _environment.ServiceReady)
                    SetHeaderStatus(L.T("Workspace online", "工作区在线"), Palette.Green);
                else if (_environment.DockerInstalled)
                    SetHeaderStatus(L.T("Setup available", "可继续配置"), Palette.Amber);
                else
                    SetHeaderStatus(L.T("New installation", "全新安装"), Palette.Muted);
                RefreshEnvironmentLabels();
                if (_page == "home" || _page == "install")
                    ShowPage(_page);
            }
            catch (Exception ex)
            {
                AppendLog(L.T("Environment check failed: ", "环境检查失败：") + ex.Message);
                SetHeaderStatus(L.T("Check failed", "检查失败"), Palette.Red);
            }
        }

        private void RefreshEnvironmentLabels()
        {
            if (_dockerStatusLabel != null)
            {
                if (_environment == null)
                    _dockerStatusLabel.Text = L.T("Docker: checking…", "Docker：检查中…");
                else
                    _dockerStatusLabel.Text = _environment.DockerRunning
                        ? L.T("Docker: engine running", "Docker：引擎运行中")
                        : (_environment.DockerInstalled
                            ? L.T("Docker: installed, engine stopped", "Docker：已安装，引擎未运行")
                            : L.T("Docker: not installed", "Docker：未安装"));
            }
            if (_serviceStatusLabel != null)
            {
                if (_environment == null)
                    _serviceStatusLabel.Text = L.T("eScriptorium: checking…", "eScriptorium：检查中…");
                else
                    _serviceStatusLabel.Text = _environment.ServiceReady
                        ? L.T("eScriptorium: healthy at localhost:8080", "eScriptorium：localhost:8080 状态正常")
                        : L.T("eScriptorium: not online", "eScriptorium：尚未在线");
            }
            if (_compatibilityLabel != null)
            {
                if (_environment == null)
                {
                    _compatibilityLabel.Text = L.T(
                        "Compatibility: checking this device…",
                        "兼容性：正在检查此设备…");
                    _compatibilityLabel.ForeColor = Palette.Muted;
                }
                else
                {
                    List<string> warnings = new List<string>();
                    if (!_environment.IsWindows64)
                        warnings.Add(L.T("64-bit Windows is required.",
                            "需要 64 位 Windows。"));
                    if (_environment.ProcessorArchitecture.IndexOf(
                            "ARM", StringComparison.OrdinalIgnoreCase) >= 0)
                        warnings.Add(L.T(
                            "ARM Windows may be too slow for the amd64 eScriptorium images.",
                            "ARM Windows 运行 amd64 eScriptorium 镜像可能过慢。"));
                    if (!_environment.MemorySufficient)
                        warnings.Add(L.T(
                            "Less than 8 GB RAM: local Docker may fail or be very slow.",
                            "内存低于 8 GB：本机 Docker 可能失败或非常缓慢。"));
                    if (!_environment.DiskSufficient)
                        warnings.Add(L.T(
                            "Less than 20 GB free disk space.",
                            "可用磁盘空间低于 20 GB。"));
                    _compatibilityLabel.Text = warnings.Count == 0
                        ? L.T(
                            "Compatibility: 64-bit architecture and local Docker resources look suitable. First startup may still take 5–15 minutes.",
                            "兼容性：64 位架构和本机 Docker 资源符合要求。首次启动仍可能需要 5–15 分钟。")
                        : L.T("Tablet/PC warning: ", "平板/电脑警告：") +
                            String.Join(" ", warnings);
                    _compatibilityLabel.ForeColor =
                        warnings.Count == 0 ? Palette.Green : Palette.Red;
                }
            }
            if (_studioStats != null)
                UpdateStudioStats();
        }

        private void SetHeaderStatus(string text, Color color)
        {
            if (_headerStatus == null)
                return;
            _headerStatus.Text = text;
            _headerStatus.ForeColor = color;
        }

        private async void InstallAndStartClick(object sender, EventArgs e)
        {
            if (_busy)
                return;
            if (_dockerConsent == null || !_dockerConsent.Checked)
            {
                MessageBox.Show(
                    L.T(
                        "Please review and accept the Docker Subscription Service Agreement first. The link is on this page.",
                        "请先阅读并勾选接受 Docker 订阅服务协议。本页右侧提供了条款链接。"),
                    L.T("Consent required", "需要确认条款"),
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }
            await RunInstallAsync();
        }

        private async Task RunInstallAsync()
        {
            if (_busy)
                return;
            if (!InstallerEngine.IsAdministrator())
            {
                if (InstallerEngine.RelaunchElevated())
                {
                    Application.Exit();
                    return;
                }
                MessageBox.Show(
                    L.T(
                        "Windows administrator approval is required to install Docker Desktop and its WSL 2 components.",
                        "安装 Docker Desktop 及其 WSL 2 组件需要 Windows 管理员授权。"),
                    L.T("Administrator approval required", "需要管理员授权"),
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }
            await ExecuteBusyAsync(
                L.T("Installing the local manuscript lab…", "正在安装本机手稿实验室…"),
                async delegate
                {
                    await _engine.SetupAllAsync(_settings, true, InstallProgress);
                    _environment = await _engine.CheckAsync();
                    InstallProgress(L.T("Installation complete.", "安装完成。"));
                    _engine.OpenService();
                },
                delegate
                {
                    ShowPage("install");
                });
        }

        private async void RepairClick(object sender, EventArgs e)
        {
            if (_busy)
                return;
            await ExecuteBusyAsync(
                L.T("Starting and checking eScriptorium…", "正在启动并检查 eScriptorium…"),
                async delegate
                {
                    await _engine.RepairAsync(_settings, InstallProgress);
                    _environment = await _engine.CheckAsync();
                },
                delegate { ShowPage("install"); });
        }

        private async Task ExecuteBusyAsync(
            string status,
            Func<Task> action,
            Action completed)
        {
            _busy = true;
            _busyCancellation = new CancellationTokenSource();
            bool actionSucceeded = false;
            SetHeaderStatus(status, Palette.Gold);
            if (_installProgress != null)
                _installProgress.Style = ProgressBarStyle.Marquee;
            if (_installStatus != null)
                _installStatus.Text = status;
            try
            {
                await action();
                actionSucceeded = true;
            }
            catch (OperationCanceledException)
            {
                AppendLog(L.T("Operation cancelled.", "操作已取消。"));
            }
            catch (AiRequestException ex)
            {
                actionSucceeded = false;
                AppendLog("[" + ex.Code + "] " + ex.UserMessage);
                if (_installStatus != null)
                    _installStatus.Text = ex.Code + " · " +
                        L.T("See the AI error explanation.", "请查看 AI 报错码说明。");
                SetHeaderStatus(ex.Code + " · " + L.T("AI error", "AI 错误"), Palette.Red);
                MessageBox.Show(
                    ex.UserMessage,
                    ex.Code + " · " + L.T("AI error", "AI 错误"),
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                AppendLog(L.T("ERROR: ", "错误：") + ex.ToString());
                if (_installStatus != null)
                    _installStatus.Text = L.T("Action failed. See activity log.", "操作失败，请查看活动日志。");
                MessageBox.Show(
                    ex.Message,
                    L.T("Action failed", "操作失败"),
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                _busy = false;
                if (_installProgress != null)
                {
                    _installProgress.Style = ProgressBarStyle.Continuous;
                    _installProgress.Value = 0;
                }
                if (_environment != null)
                {
                    if (_environment.DockerRunning && _environment.ServiceReady)
                        SetHeaderStatus(L.T("Workspace online", "工作区在线"), Palette.Green);
                    else
                        SetHeaderStatus(L.T("Setup available", "可继续配置"), Palette.Amber);
                }
                if (_busyCancellation != null)
                {
                    _busyCancellation.Dispose();
                    _busyCancellation = null;
                }
                if (actionSucceeded && completed != null)
                    completed();
            }
        }

        private void InstallProgress(string message)
        {
            if (message == null)
                return;
            if (IsHandleCreated && InvokeRequired)
            {
                BeginInvoke(new Action<string>(InstallProgress), message);
                return;
            }
            AppendLog(message);
            if (_installStatus != null)
                _installStatus.Text = message;
            SetHeaderStatus(message.Length > 55 ? message.Substring(0, 52) + "…" : message, Palette.Gold);
        }

        private void AppendLog(string message)
        {
            AppPaths.Log(message);
            if (_installLog == null || _installLog.IsDisposed)
                return;
            if (_installLog.InvokeRequired)
            {
                _installLog.BeginInvoke(new Action<string>(AppendLog), message);
                return;
            }
            _installLog.AppendText(
                DateTime.Now.ToString("HH:mm:ss") + "  " +
                message.Replace("\r\n", "\n").Replace("\n", Environment.NewLine) +
                Environment.NewLine);
        }

        private void ImportClick(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = L.T("Import transcription with coordinates", "导入带坐标的转录文本");
                dialog.InitialDirectory = Directory.Exists(_settings.LastImportPath)
                    ? _settings.LastImportPath
                    : Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                dialog.Filter =
                    L.T("Transcription files", "转录文件") +
                    "|*.xml;*.alto;*.pagexml;*.txt;*.json|ALTO XML (*.xml;*.alto)|*.xml;*.alto|" +
                    "PAGE XML (*.xml;*.pagexml)|*.xml;*.pagexml|" +
                    L.T("Text files", "文本文件") + "|*.txt|" +
                    L.T("All files", "所有文件") + "|*.*";
                dialog.Multiselect = true;
                if (dialog.ShowDialog(this) == DialogResult.OK)
                    ImportPaths(dialog.FileNames);
            }
        }

        private void ImportPaths(IEnumerable<string> paths)
        {
            try
            {
                List<string> valid = paths.Where(File.Exists).ToList();
                if (valid.Count == 0)
                    return;
                List<TranscriptionLine> incoming = DocumentParser.ReadFiles(valid);
                int pageOffset = _lines.Count == 0 ? 0 : _lines.Max(line => line.Page);
                if (pageOffset > 0)
                {
                    foreach (TranscriptionLine line in incoming)
                        line.Page += pageOffset;
                }
                _lines.AddRange(incoming);
                _contextTranslation = null;
                if (_contextTranslationBox != null)
                    _contextTranslationBox.Clear();
                for (int index = 0; index < _lines.Count; index++)
                    _lines[index].Id = index + 1;
                if (_lineBinding != null)
                    _lineBinding.ResetBindings();
                _analysis = TextAnalyzer.Analyze(_lines);
                if (_analysisText != null)
                    _analysisText.Text = TextAnalyzer.Format(_analysis);
                if (_studioStatus != null)
                    _studioStatus.Text = String.Format(
                        L.T("Imported {0} line(s) from {1} file(s).",
                            "已导入 {0} 行，来自 {1} 个文件。"),
                        incoming.Count,
                        valid.Count);
                UpdateStudioStats();
                if (_linesGrid != null && !_linesGrid.IsDisposed && _linesGrid.Rows.Count > 0)
                    _linesGrid.Rows[0].Selected = true;
                _settings.LastImportPath = Path.GetDirectoryName(valid[0]);
                try { _settings.Save(); } catch { }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    L.T("Import failed", "导入失败"),
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void LocalCleanClick(object sender, EventArgs e)
        {
            if (_lines.Count == 0)
                return;
            foreach (TranscriptionLine line in _lines)
            {
                line.Cleaned = LocalCleaner.Clean(line.Original);
                line.Status = line.HasCoordinates
                    ? L.T("Locally cleaned", "本地已清洗")
                    : L.T("No coordinates", "无坐标");
            }
            RefreshLines();
            _analysis = TextAnalyzer.Analyze(_lines);
            if (_analysisText != null)
                _analysisText.Text = TextAnalyzer.Format(_analysis);
            SetStudioStatus(L.T("Local whitespace and Unicode cleaning applied.",
                "已应用本地空白与 Unicode 清洗。"));
        }

        private async void AiProcessClick(object sender, EventArgs e)
        {
            if (_lines.Count == 0)
            {
                MessageBox.Show(
                    AiErrors.Create(
                        AiErrorCode.NoInputLines,
                        "Imported line count: 0").UserMessage,
                    AiErrorCode.NoInputLines + " · " + L.T("AI error", "AI 错误"),
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }
            if (!_ai.IsConfigured(_settings))
            {
                AiRequestException configurationError = AiErrors.Create(
                    AiErrorCode.ConfigurationRequired,
                    "Endpoint: " + _settings.AiEndpoint + "\nModel: " + _settings.AiModel);
                MessageBox.Show(
                    configurationError.UserMessage,
                    configurationError.Code + " · " + L.T("AI configuration", "AI 配置"),
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            await ExecuteBusyAsync(
                L.T("AI is processing line-aligned text…", "AI 正在按行处理文本…"),
                async delegate
                {
                    if (_busyCancellation == null)
                        throw new InvalidOperationException();
                    await _ai.ProcessAsync(
                        _lines,
                        _settings,
                        delegate(int done, int total)
                        {
                            SetStudioStatusThreadSafe(String.Format(
                                L.T("AI aligned {0} / {1} lines.", "AI 已对齐 {0} / {1} 行。"),
                                done, total));
                        },
                        _busyCancellation.Token);
                    _analysis = TextAnalyzer.Analyze(_lines);
                },
                delegate
                {
                    ShowPage("studio");
                    SetStudioStatus(L.T("AI cleaning and aligned translation complete.",
                        "AI 清洗与对照翻译已完成。"));
                });
        }

        private async void TestAiClick(object sender, EventArgs e)
        {
            if (!CaptureSettingsFromControls(true))
                return;
            TranscriptionLine test = new TranscriptionLine
            {
                Id = 1,
                Original = "Hath ſhe no pity?",
                HasCoordinates = true,
                X = 10,
                Y = 20,
                Width = 200,
                Height = 30,
                SourceFile = "connection-test",
                Page = 1,
                Status = "Test"
            };
            List<TranscriptionLine> testLines = new List<TranscriptionLine> { test };
            await ExecuteBusyAsync(
                L.T("Testing the AI endpoint…", "正在测试 AI 接口…"),
                async delegate
                {
                    if (_busyCancellation == null)
                        throw new InvalidOperationException();
                    await _ai.ProcessAsync(
                        testLines,
                        _settings,
                        delegate { },
                        _busyCancellation.Token);
                },
                delegate
                {
                    MessageBox.Show(
                        L.T("Connection succeeded.\n\nCleaned: ", "连接成功。\n\n清洗：") + test.Cleaned +
                        L.T("\nTranslation: ", "\n翻译：") + test.Translation,
                        L.T("AI test passed", "AI 测试通过"),
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                });
        }

        private void AnalyzeClick(object sender, EventArgs e)
        {
            _analysis = TextAnalyzer.Analyze(_lines);
            if (_analysisText != null)
                _analysisText.Text = TextAnalyzer.Format(_analysis);
            UpdateStudioStats();
            SetStudioStatus(L.T("Analysis refreshed.", "文本分析已更新。"));
        }

        private void ExportClick(object sender, EventArgs e)
        {
            if (_lines.Count == 0)
                return;
            if (_analysis == null)
                _analysis = TextAnalyzer.Analyze(_lines);
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Title = L.T("Export bilingual research set", "导出双语研究成果");
                dialog.InitialDirectory = AppPaths.ExportsDirectory;
                dialog.FileName = "manuscript-bilingual-" + DateTime.Now.ToString("yyyyMMdd-HHmm") + ".tei.xml";
                dialog.Filter =
                    "TEI XML (*.tei.xml)|*.tei.xml|" +
                    "Word document (*.docx)|*.docx|" +
                    "Line-aligned JSON (*.json)|*.json|" +
                    "CSV, UTF-8 (*.csv)|*.csv|" +
                    L.T("Analysis report", "分析报告") + " (*.txt)|*.txt";
                if (dialog.ShowDialog(this) != DialogResult.OK)
                    return;
                try
                {
                    string extension = Path.GetExtension(dialog.FileName).ToLowerInvariant();
                    string full = dialog.FileName.ToLowerInvariant();
                    string contextText = _contextTranslationBox != null
                        ? _contextTranslationBox.Text
                        : (_contextTranslation == null ? String.Empty : _contextTranslation.Translation);
                    string cleanseText = _contextCleanseBox != null
                        ? _contextCleanseBox.Text
                        : (_contextTranslation == null ? String.Empty : _contextTranslation.CleanseText);
                    IList<ContextPageResult> contextPages = _contextTranslation == null
                        ? null
                        : _contextTranslation.Pages;
                    if (full.EndsWith(".tei.xml", StringComparison.Ordinal))
                        ExportService.ExportTei(
                            dialog.FileName, _lines, _analysis,
                            _settings.SourceLanguage, _settings.TargetLanguage,
                            contextText, cleanseText, contextPages);
                    else if (extension == ".docx")
                        WordExportService.ExportBilingualDocument(
                            dialog.FileName, _lines, _analysis,
                            _settings.SourceLanguage, _settings.TargetLanguage,
                            contextText, cleanseText, contextPages);
                    else if (extension == ".json")
                        ExportService.ExportJson(
                            dialog.FileName, _lines, _analysis,
                            contextText, cleanseText, contextPages);
                    else if (extension == ".csv")
                        ExportService.ExportCsv(dialog.FileName, _lines);
                    else
                        ExportService.ExportAnalysis(dialog.FileName, _analysis);
                    SetStudioStatus(L.T("Exported: ", "已导出：") + dialog.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message,
                        L.T("Export failed", "导出失败"),
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }

        private void ExportWordClick(object sender, EventArgs e)
        {
            if (_lines.Count == 0)
                return;
            if (_analysis == null)
                _analysis = TextAnalyzer.Analyze(_lines);

            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Title = L.T("Export bilingual Word document",
                    "导出双语 Word 文档");
                dialog.InitialDirectory = AppPaths.ExportsDirectory;
                dialog.FileName = "manuscript-bilingual-" +
                    DateTime.Now.ToString("yyyyMMdd-HHmm") + ".docx";
                dialog.DefaultExt = "docx";
                dialog.AddExtension = true;
                dialog.Filter = "Word document (*.docx)|*.docx";
                if (dialog.ShowDialog(this) != DialogResult.OK)
                    return;

                try
                {
                    string contextText = _contextTranslationBox != null
                        ? _contextTranslationBox.Text
                        : (_contextTranslation == null ? String.Empty : _contextTranslation.Translation);
                    string cleanseText = _contextCleanseBox != null
                        ? _contextCleanseBox.Text
                        : (_contextTranslation == null ? String.Empty : _contextTranslation.CleanseText);
                    IList<ContextPageResult> contextPages = _contextTranslation == null
                        ? null
                        : _contextTranslation.Pages;
                    WordExportService.ExportBilingualDocument(
                        dialog.FileName, _lines, _analysis,
                        _settings.SourceLanguage, _settings.TargetLanguage,
                        contextText, cleanseText, contextPages);
                    SetStudioStatus(L.T("Word exported: ", "Word 已导出：") +
                        dialog.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message,
                        L.T("Word export failed", "Word 导出失败"),
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }

        private void UpdateDetailPanel(object sender, EventArgs e)
        {
            TranscriptionLine line = SelectedLine();
            if (line == null)
                return;
            _detailOriginal.Text = line.Original;
            _detailCleaned.Text = line.Cleaned;
            _detailTranslation.Text = line.Translation;
            _detailCoordinates.Text = line.HasCoordinates
                ? L.T("Coordinates: ", "坐标：") + line.CoordinateText +
                    " · " + L.T("page ", "第 ") + line.Page
                : L.T("No coordinate box (plain text import).", "无坐标框（纯文本导入）。");
        }

        private void ApplyDetailEdits(object sender, EventArgs e)
        {
            TranscriptionLine line = SelectedLine();
            if (line == null)
                return;
            line.Cleaned = _detailCleaned.Text.Trim();
            line.Translation = _detailTranslation.Text.Trim();
            line.Status = L.T("Reviewed", "已复核");
            RefreshLines();
            _analysis = TextAnalyzer.Analyze(_lines);
            if (_analysisText != null)
                _analysisText.Text = TextAnalyzer.Format(_analysis);
            SetStudioStatus(L.T("Line edits applied.", "当前行修改已应用。"));
        }

        private TranscriptionLine SelectedLine()
        {
            if (_linesGrid == null || _linesGrid.CurrentRow == null)
                return null;
            return _linesGrid.CurrentRow.DataBoundItem as TranscriptionLine;
        }

        private void RefreshLines()
        {
            if (_lineBinding != null)
                _lineBinding.ResetBindings();
            UpdateStudioStats();
        }

        private void UpdateStudioStats()
        {
            if (_studioStats != null)
            {
                int coords = _lines.Count(line => line.HasCoordinates);
                int translated = _lines.Count(line =>
                    !String.IsNullOrWhiteSpace(line.Translation));
                _studioStats.Text = String.Format(
                    L.T("{0} lines · {1} with coordinates · {2} translated",
                        "{0} 行 · {1} 行有坐标 · {2} 行已翻译"),
                    _lines.Count, coords, translated);
            }
        }

        private void SetStudioStatus(string text)
        {
            if (_studioStatus != null)
                _studioStatus.Text = text;
            UpdateStudioStats();
        }

        private void SetStudioStatusThreadSafe(string text)
        {
            if (IsHandleCreated && InvokeRequired)
            {
                BeginInvoke(new Action<string>(SetStudioStatusThreadSafe), text);
                return;
            }
            SetStudioStatus(text);
        }

        private bool CaptureSettingsFromControls(bool save)
        {
            if (_aiEndpoint == null)
                return true;
            if (String.IsNullOrWhiteSpace(_aiEndpoint.Text))
            {
                AiRequestException invalidEndpoint = AiErrors.Create(
                    AiErrorCode.InvalidEndpoint,
                    "Endpoint is empty.");
                MessageBox.Show(
                    invalidEndpoint.UserMessage,
                    invalidEndpoint.Code + " · " + L.T("Invalid setting", "设置无效"),
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return false;
            }
            _settings.AiEndpoint = _aiEndpoint.Text.Trim();
            string currentKey = _settings.GetAiApiKey();
            if (_aiKey.Text != MaskSecret(currentKey))
                _settings.SetAiApiKey(_aiKey.Text.Trim());
            _settings.AiModel = _aiModel.Text.Trim();
            _settings.SourceLanguage = _sourceLanguage.Text.Trim();
            _settings.TargetLanguage = _targetLanguage.Text.Trim();
            if (_pageConcurrencyBox != null)
                _settings.PageConcurrency = _pageConcurrencyBox.SelectedIndex == 2 ? 4 :
                    _pageConcurrencyBox.SelectedIndex == 1 ? 2 : 1;
            if (save)
                _settings.Save();
            return true;
        }

        private void ToastSettingsSaved()
        {
            MessageBox.Show(
                L.T("Settings saved on this computer. API secrets are protected with Windows DPAPI.",
                    "设置已保存到本机。API 密钥使用 Windows DPAPI 保护。"),
                L.T("Saved", "已保存"),
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private static string MaskSecret(string value)
        {
            if (String.IsNullOrEmpty(value))
                return String.Empty;
            return new String('•', Math.Min(18, Math.Max(8, value.Length)));
        }

        private void FormDragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.Copy;
        }

        private void FormDragDrop(object sender, DragEventArgs e)
        {
            string[] files = e.Data.GetData(DataFormats.FileDrop) as string[];
            if (files == null || files.Length == 0)
                return;
            if (_page != "studio")
                ShowPage("studio");
            ImportPaths(files);
        }
    }
}
