using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web.Script.Serialization;

namespace EScriptoriumStudio
{
    internal sealed class AppSettings
    {
        public string AiEndpoint { get; set; }
        public string AiApiKeyProtected { get; set; }
        public string AiModel { get; set; }
        public string SourceLanguage { get; set; }
        public string TargetLanguage { get; set; }
        public string EscriptoriumPasswordProtected { get; set; }
        public string AdminUser { get; set; }
        public string InstallDirectory { get; set; }
        public string LastImportPath { get; set; }
        public int SettingsSchemaVersion { get; set; }
        public int PageConcurrency { get; set; }
        public int SelectedHtrModelPk { get; set; }
        public string SelectedHtrModelName { get; set; }
        public string OcrBackend { get; set; }
        public string OcrEndpoint { get; set; }
        public string OcrLanguageKey { get; set; }
        public string OcrParser { get; set; }
        public string OcrPdfMode { get; set; }
        public string UmiOcrPath { get; set; }
        public string TesseractPath { get; set; }
        public string TesseractLanguage { get; set; }
        public string LastOcrPath { get; set; }

        public AppSettings()
        {
            AiEndpoint = "https://api.openai.com/v1/chat/completions";
            AiModel = "gpt-4.1-mini";
            SourceLanguage = "Early modern European languages (auto-detect)";
            TargetLanguage = "English / 英语";
            AdminUser = "admin";
            SettingsSchemaVersion = 7;
            PageConcurrency = 1;
            SelectedHtrModelPk = 0;
            SelectedHtrModelName = String.Empty;
            OcrBackend = "Umi-OCR";
            OcrEndpoint = "http://127.0.0.1:1224";
            OcrLanguageKey = "models/config_en.txt";
            OcrParser = "single_line";
            OcrPdfMode = "mixed";
            UmiOcrPath = String.Empty;
            TesseractPath = String.Empty;
            TesseractLanguage = "eng";
            LastOcrPath = String.Empty;
        }

        public static AppSettings Load()
        {
            try
            {
                if (File.Exists(AppPaths.SettingsFile))
                {
                    string json = File.ReadAllText(AppPaths.SettingsFile, Encoding.UTF8);
                    AppSettings loaded = new JavaScriptSerializer().Deserialize<AppSettings>(json);
                    if (loaded != null)
                    {
                        loaded.Normalize();
                        return loaded;
                    }
                }
            }
            catch
            {
                // A damaged settings file should never prevent the installer from opening.
            }

            AppSettings fresh = new AppSettings();
            fresh.Normalize();
            return fresh;
        }

        public void Normalize()
        {
            if (String.IsNullOrWhiteSpace(AiEndpoint))
                AiEndpoint = "https://api.openai.com/v1/chat/completions";
            if (String.IsNullOrWhiteSpace(AiModel))
                AiModel = "gpt-4.1-mini";
            if (String.IsNullOrWhiteSpace(SourceLanguage))
                SourceLanguage = "Early modern European languages (auto-detect)";
            if (SettingsSchemaVersion < 6)
            {
                if (String.IsNullOrWhiteSpace(TargetLanguage) ||
                    TargetLanguage.IndexOf("简体中文", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    TargetLanguage.IndexOf("Simplified Chinese", StringComparison.OrdinalIgnoreCase) >= 0)
                    TargetLanguage = "English / 英语";
                SettingsSchemaVersion = 6;
            }
            if (SettingsSchemaVersion < 7)
                SettingsSchemaVersion = 7;
            if (String.IsNullOrWhiteSpace(TargetLanguage))
                TargetLanguage = "English / 英语";
            if (String.IsNullOrWhiteSpace(AdminUser))
                AdminUser = "admin";
            if (String.IsNullOrWhiteSpace(InstallDirectory))
                InstallDirectory = AppPaths.ServerDirectory;
            if (PageConcurrency < 1 || PageConcurrency > 4)
                PageConcurrency = 1;
            if (String.IsNullOrWhiteSpace(OcrBackend))
                OcrBackend = "Umi-OCR";
            if (String.IsNullOrWhiteSpace(OcrEndpoint))
                OcrEndpoint = "http://127.0.0.1:1224";
            if (String.IsNullOrWhiteSpace(OcrLanguageKey))
                OcrLanguageKey = "models/config_en.txt";
            if (String.IsNullOrWhiteSpace(OcrParser))
                OcrParser = "single_line";
            if (String.IsNullOrWhiteSpace(OcrPdfMode))
                OcrPdfMode = "mixed";
            if (String.IsNullOrWhiteSpace(TesseractLanguage))
                TesseractLanguage = "eng";
        }

        public string GetAiApiKey()
        {
            return SecretStore.Unprotect(AiApiKeyProtected);
        }

        public void SetAiApiKey(string value)
        {
            AiApiKeyProtected = SecretStore.Protect(value);
        }

        public string GetEscriptoriumPassword()
        {
            return SecretStore.Unprotect(EscriptoriumPasswordProtected);
        }

        public void SetEscriptoriumPassword(string value)
        {
            EscriptoriumPasswordProtected = SecretStore.Protect(value);
        }

        public void Save()
        {
            AppPaths.EnsureDirectories();
            string json = new JavaScriptSerializer().Serialize(this);
            File.WriteAllText(AppPaths.SettingsFile, json, new UTF8Encoding(false));
        }

        public AppSettings Clone()
        {
            string json = new JavaScriptSerializer().Serialize(this);
            AppSettings clone = new JavaScriptSerializer().Deserialize<AppSettings>(json);
            clone.Normalize();
            return clone;
        }
    }

    internal static class AppPaths
    {
        public static readonly string Root = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "eScriptoriumStudio");
        public static readonly string ServerDirectory = Path.Combine(Root, "server");
        public static readonly string ExportsDirectory = Path.Combine(Root, "exports");
        public static readonly string SettingsFile = Path.Combine(Root, "settings.json");
        public static readonly string LogFile = Path.Combine(Root, "studio.log");
        public static readonly string DownloadsDirectory = Path.Combine(Path.GetTempPath(), "eScriptoriumStudio");

        public static void EnsureDirectories()
        {
            Directory.CreateDirectory(Root);
            Directory.CreateDirectory(ServerDirectory);
            Directory.CreateDirectory(ExportsDirectory);
            Directory.CreateDirectory(DownloadsDirectory);
        }

        public static void Log(string message)
        {
            try
            {
                EnsureDirectories();
                File.AppendAllText(
                    LogFile,
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + message + Environment.NewLine,
                    new UTF8Encoding(false));
            }
            catch
            {
            }
        }
    }

    internal static class SecretStore
    {
        private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("eScriptorium-Studio-v1");

        public static string Protect(string plaintext)
        {
            if (String.IsNullOrEmpty(plaintext))
                return String.Empty;
            try
            {
                byte[] clear = Encoding.UTF8.GetBytes(plaintext);
                byte[] cipher = ProtectedData.Protect(clear, Entropy, DataProtectionScope.CurrentUser);
                return Convert.ToBase64String(cipher);
            }
            catch
            {
                // DPAPI is unavailable on some managed profiles. Keep the app functional.
                return "base64:" + Convert.ToBase64String(Encoding.UTF8.GetBytes(plaintext));
            }
        }

        public static string Unprotect(string protectedText)
        {
            if (String.IsNullOrEmpty(protectedText))
                return String.Empty;
            try
            {
                if (protectedText.StartsWith("base64:", StringComparison.Ordinal))
                    return Encoding.UTF8.GetString(Convert.FromBase64String(protectedText.Substring(7)));
                byte[] cipher = Convert.FromBase64String(protectedText);
                byte[] clear = ProtectedData.Unprotect(cipher, Entropy, DataProtectionScope.CurrentUser);
                return Encoding.UTF8.GetString(clear);
            }
            catch
            {
                return String.Empty;
            }
        }
    }

    internal sealed class TranscriptionLine
    {
        public int Id { get; set; }
        public int Page { get; set; }
        public int Order { get; set; }
        public string SourceFile { get; set; }
        public string Original { get; set; }
        public string Cleaned { get; set; }
        public string Translation { get; set; }
        public string Status { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }
        public bool HasCoordinates { get; set; }

        public string CoordinateText
        {
            get
            {
                if (!HasCoordinates)
                    return "—";
                return String.Format("{0:0}, {1:0}, {2:0}×{3:0}", X, Y, Width, Height);
            }
        }

        public string DisplayText
        {
            get { return String.IsNullOrEmpty(Cleaned) ? Original : Cleaned; }
        }
    }

    internal sealed class TextAnalysis
    {
        public int Lines { get; set; }
        public int Coordinates { get; set; }
        public int Tokens { get; set; }
        public int Types { get; set; }
        public double TypeTokenRatio { get; set; }
        public double AverageTokenLength { get; set; }
        public string LikelyLanguage { get; set; }
        public List<WordFrequency> TopWords { get; set; }

        public TextAnalysis()
        {
            TopWords = new List<WordFrequency>();
        }
    }

    internal sealed class ContextTranslationResult
    {
        public string Translation { get; set; }
        public string CleanseText { get; set; }
        public string TargetLanguage { get; set; }
        public int LineCount { get; set; }
        public int ChunkCount { get; set; }
        public DateTime CreatedAt { get; set; }
        public List<ContextPageResult> Pages { get; set; }

        public ContextTranslationResult()
        {
            Translation = String.Empty;
            CleanseText = String.Empty;
            TargetLanguage = String.Empty;
            CreatedAt = DateTime.Now;
            Pages = new List<ContextPageResult>();
        }
    }

    internal sealed class ContextPageResult
    {
        public int Page { get; set; }
        public string ContextualCleanse { get; set; }
        public string Translation { get; set; }
        public int LineCount { get; set; }
        public List<int> LineIds { get; set; }

        public ContextPageResult()
        {
            ContextualCleanse = String.Empty;
            Translation = String.Empty;
            LineIds = new List<int>();
        }
    }

    internal sealed class PageContextPayload
    {
        public int page { get; set; }
        public string contextual_cleanse { get; set; }
        public string translation { get; set; }
        public List<AiLineResult> lines { get; set; }
    }

    internal sealed class ContextTranslationPayload
    {
        public string translation { get; set; }
    }

    internal sealed class WordFrequency
    {
        public string Word { get; set; }
        public int Count { get; set; }
    }

    internal sealed class AiLineResult
    {
        public int id { get; set; }
        public string cleaned { get; set; }
        public string translation { get; set; }
    }

    internal sealed class AiEnvelope
    {
        public List<AiLineResult> lines { get; set; }
    }
}
