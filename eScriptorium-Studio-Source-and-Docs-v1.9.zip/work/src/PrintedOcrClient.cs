using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace EScriptoriumStudio
{
    internal sealed class PrintedOcrOptions
    {
        public string Backend { get; set; }
        public string Endpoint { get; set; }
        public string LanguageKey { get; set; }
        public string Parser { get; set; }
        public string TesseractPath { get; set; }
        public string TesseractLanguage { get; set; }
        public string PdfExtractionMode { get; set; }
        public int PdfPageStart { get; set; }
        public int PdfPageEnd { get; set; }
        public bool CorrectOrientation { get; set; }
        public int LimitSideLength { get; set; }

        public PrintedOcrOptions()
        {
            Backend = "Umi-OCR";
            Endpoint = "http://127.0.0.1:1224";
            LanguageKey = "models/config_en.txt";
            Parser = "single_line";
            PdfExtractionMode = "mixed";
            PdfPageStart = 1;
            PdfPageEnd = -1;
            CorrectOrientation = true;
            LimitSideLength = 4320;
        }
    }

    internal sealed class OcrLanguageOption
    {
        public string Value { get; set; }
        public string Label { get; set; }

        public override string ToString()
        {
            return String.IsNullOrWhiteSpace(Label) ? Value : Label + " · " + Value;
        }
    }

    internal static class PrintedOcrClient
    {
        private static readonly HttpClient Client = CreateClient();

        public static IList<string> FindUmiCandidates()
        {
            List<string> candidates = new List<string>();
            string profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string downloads = Path.Combine(profile, "Downloads");
            if (Directory.Exists(downloads))
            {
                try
                {
                    candidates.AddRange(Directory.GetDirectories(downloads, "Umi-OCR*")
                        .Select(directory => Path.Combine(directory, "Umi-OCR.exe"))
                        .Where(File.Exists));
                }
                catch
                {
                }
            }
            candidates.Add(Path.Combine(Environment.GetFolderPath(
                Environment.SpecialFolder.LocalApplicationData),
                "Programs", "Umi-OCR", "Umi-OCR.exe"));
            candidates.Add(Path.Combine(Environment.GetFolderPath(
                Environment.SpecialFolder.ProgramFiles), "Umi-OCR", "Umi-OCR.exe"));
            return candidates.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        public static string FindUmiOcr()
        {
            return FindUmiCandidates().FirstOrDefault(File.Exists);
        }

        public static string FindTesseract()
        {
            string[] candidates =
            {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                    "Tesseract-OCR", "tesseract.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Programs", "Tesseract-OCR", "tesseract.exe")
            };
            return candidates.FirstOrDefault(File.Exists) ?? String.Empty;
        }

        public static async Task<List<OcrLanguageOption>> GetUmiLanguagesAsync(
            string endpoint,
            CancellationToken cancellationToken)
        {
            Uri uri = BuildUri(endpoint, "/api/ocr/get_options");
            using (HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, uri))
            using (HttpResponseMessage response = await Client.SendAsync(
                request, HttpCompletionOption.ResponseContentRead, cancellationToken))
            {
                string body = await response.Content.ReadAsStringAsync();
                if (!response.IsSuccessStatusCode)
                    throw new InvalidOperationException(
                        "Umi-OCR options request failed: HTTP " +
                        (int)response.StatusCode + " " + Limit(body, 500));

                object parsed = new JavaScriptSerializer().DeserializeObject(body);
                IDictionary<string, object> options = AsDictionary(parsed);
                if (options == null)
                    throw new InvalidOperationException("Umi-OCR returned an invalid options dictionary.");

                List<OcrLanguageOption> languages = new List<OcrLanguageOption>();
                object languageDefinition;
                if (options.TryGetValue("ocr.language", out languageDefinition))
                {
                    IDictionary<string, object> definition = AsDictionary(languageDefinition);
                    object choices;
                    if (definition != null && definition.TryGetValue("optionsList", out choices))
                    {
                        foreach (object item in AsItems(choices))
                        {
                            IList<object> pair = AsItems(item).ToList();
                            if (pair.Count >= 2)
                            {
                                languages.Add(new OcrLanguageOption
                                {
                                    Value = Convert.ToString(pair[0], CultureInfo.InvariantCulture),
                                    Label = Convert.ToString(pair[1], CultureInfo.InvariantCulture)
                                });
                            }
                        }
                    }
                }
                return languages;
            }
        }

        public static async Task<List<string>> GetTesseractLanguagesAsync(
            string executable,
            CancellationToken cancellationToken)
        {
            if (String.IsNullOrWhiteSpace(executable) || !File.Exists(executable))
                throw new FileNotFoundException(
                    "Tesseract was not found. Set the tesseract.exe path first.", executable);

            ProcessStartInfo start = new ProcessStartInfo
            {
                FileName = executable,
                Arguments = "--list-langs",
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8
            };
            using (Process process = new Process { StartInfo = start })
            {
                if (!process.Start())
                    throw new InvalidOperationException("Tesseract could not be started.");
                Task<string> outputTask = process.StandardOutput.ReadToEndAsync();
                Task<string> errorTask = process.StandardError.ReadToEndAsync();
                while (!process.HasExited)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    await Task.Delay(80, cancellationToken);
                }
                string output = await outputTask;
                string error = await errorTask;
                if (process.ExitCode != 0)
                    throw new InvalidOperationException(
                        "Tesseract language query failed: " + Limit(error, 700));
                return (output ?? String.Empty)
                    .Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(line => line.Trim())
                    .Where(line => !String.IsNullOrWhiteSpace(line) &&
                        line.IndexOf("available languages", StringComparison.OrdinalIgnoreCase) < 0)
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToList();
            }
        }

        public static async Task<List<TranscriptionLine>> RecognizeImageAsync(
            string imagePath,
            int pageNumber,
            PrintedOcrOptions options,
            CancellationToken cancellationToken)
        {
            if (!File.Exists(imagePath))
                throw new FileNotFoundException("OCR image not found.", imagePath);
            if (options == null)
                throw new ArgumentNullException("options");

            if (String.Equals(options.Backend, "Tesseract", StringComparison.OrdinalIgnoreCase))
                return await RecognizeWithTesseractAsync(
                    imagePath, pageNumber, options, cancellationToken);
            return await RecognizeWithUmiAsync(imagePath, pageNumber, options, cancellationToken);
        }

        public static async Task<List<TranscriptionLine>> RecognizePdfWithUmiAsync(
            string pdfPath,
            int startPage,
            PrintedOcrOptions options,
            Action<int, int> progress,
            CancellationToken cancellationToken)
        {
            if (!File.Exists(pdfPath))
                throw new FileNotFoundException("PDF not found.", pdfPath);
            if (!String.Equals(options.Backend, "Umi-OCR", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException(
                    "PDF document OCR requires Umi-OCR 2.1.4 or later. " +
                    "Select Umi-OCR or use page images with Tesseract.");

            Dictionary<string, object> taskOptions = new Dictionary<string, object>
            {
                { "data.format", "dict" },
                { "tbpu.parser", String.IsNullOrWhiteSpace(options.Parser) ? "single_line" : options.Parser },
                { "ocr.cls", options.CorrectOrientation },
                { "ocr.limit_side_len", options.LimitSideLength > 0 ? options.LimitSideLength : 4320 },
                { "ocr.language", String.IsNullOrWhiteSpace(options.LanguageKey)
                    ? "models/config_en.txt" : options.LanguageKey },
                { "doc.extractionMode", String.IsNullOrWhiteSpace(options.PdfExtractionMode)
                    ? "mixed" : options.PdfExtractionMode },
                { "pageRangeStart", options.PdfPageStart > 0 ? options.PdfPageStart : 1 },
                { "pageRangeEnd", options.PdfPageEnd == 0 ? -1 : options.PdfPageEnd }
            };
            string taskId = null;
            try
            {
                using (MultipartFormDataContent form = new MultipartFormDataContent())
                {
                    ByteArrayContent fileContent = new ByteArrayContent(File.ReadAllBytes(pdfPath));
                    fileContent.Headers.ContentType =
                        new System.Net.Http.Headers.MediaTypeHeaderValue("application/pdf");
                    form.Add(fileContent, "file", "document.pdf");
                    form.Add(new StringContent(
                        new JavaScriptSerializer().Serialize(taskOptions),
                        Encoding.UTF8,
                        "application/json"), "json");
                    using (HttpResponseMessage response = await Client.PostAsync(
                        BuildUri(options.Endpoint, "/api/doc/upload"), form, cancellationToken))
                    {
                        string body = await response.Content.ReadAsStringAsync();
                        if (!response.IsSuccessStatusCode)
                            throw new InvalidOperationException(
                                "Umi PDF upload failed: HTTP " + (int)response.StatusCode +
                                " " + Limit(body, 700));
                        IDictionary<string, object> envelope = AsDictionary(
                            new JavaScriptSerializer().DeserializeObject(body));
                        int code = ToInt(GetValue(envelope, "code"));
                        object id = GetValue(envelope, "data");
                        if (code != 100 || id == null)
                            throw new InvalidOperationException(
                                "Umi PDF upload code " + code + ": " +
                                Convert.ToString(id, CultureInfo.InvariantCulture));
                        taskId = Convert.ToString(id, CultureInfo.InvariantCulture);
                    }
                }

                object latestData = null;
                int pagesCount = 0;
                DateTime deadline = DateTime.UtcNow.AddHours(2);
                while (DateTime.UtcNow < deadline)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    Dictionary<string, object> query = new Dictionary<string, object>
                    {
                        { "id", taskId },
                        { "is_data", true },
                        { "is_unread", false },
                        { "format", "dict" }
                    };
                    using (StringContent content = new StringContent(
                        new JavaScriptSerializer().Serialize(query),
                        Encoding.UTF8,
                        "application/json"))
                    using (HttpResponseMessage response = await Client.PostAsync(
                        BuildUri(options.Endpoint, "/api/doc/result"), content, cancellationToken))
                    {
                        string body = await response.Content.ReadAsStringAsync();
                        if (!response.IsSuccessStatusCode)
                            throw new InvalidOperationException(
                                "Umi PDF result failed: HTTP " + (int)response.StatusCode +
                                " " + Limit(body, 700));
                        IDictionary<string, object> envelope = AsDictionary(
                            new JavaScriptSerializer().DeserializeObject(body));
                        int code = ToInt(GetValue(envelope, "code"));
                        if (code != 100)
                            throw new InvalidOperationException(
                                "Umi PDF result code " + code + ": " +
                                Convert.ToString(GetValue(envelope, "data"), CultureInfo.InvariantCulture));
                        int processed = ToInt(GetValue(envelope, "processed_count"));
                        pagesCount = ToInt(GetValue(envelope, "pages_count"));
                        if (progress != null)
                            progress(processed, pagesCount);
                        object data = GetValue(envelope, "data");
                        if (data != null &&
                            (!(data is string) || !String.IsNullOrWhiteSpace((string)data)))
                            latestData = data;

                        bool done = ToBool(GetValue(envelope, "is_done"));
                        string state = Convert.ToString(GetValue(envelope, "state"),
                            CultureInfo.InvariantCulture);
                        if (!done)
                        {
                            await Task.Delay(900, cancellationToken);
                            continue;
                        }
                        if (!String.Equals(state, "success", StringComparison.OrdinalIgnoreCase))
                            throw new InvalidOperationException(
                                "Umi PDF OCR failed: " +
                                Convert.ToString(GetValue(envelope, "message"),
                                    CultureInfo.InvariantCulture));
                        break;
                    }
                }

                List<TranscriptionLine> result = ParseUmiDocumentData(
                    latestData, pdfPath, startPage, Math.Max(1, pagesCount));
                if (result.Count == 0)
                    throw new InvalidOperationException(
                        "Umi completed PDF OCR but returned no text blocks.");
                return result;
            }
            finally
            {
                if (!String.IsNullOrWhiteSpace(taskId))
                {
                    try
                    {
                        using (HttpResponseMessage clear = Client.GetAsync(
                            BuildUri(options.Endpoint, "/api/doc/clear/" +
                                Uri.EscapeDataString(taskId))).GetAwaiter().GetResult())
                        {
                        }
                    }
                    catch
                    {
                    }
                }
            }
        }

        private static async Task<List<TranscriptionLine>> RecognizeWithUmiAsync(
            string imagePath,
            int pageNumber,
            PrintedOcrOptions options,
            CancellationToken cancellationToken)
        {
            string base64 = Convert.ToBase64String(File.ReadAllBytes(imagePath));
            Dictionary<string, object> requestBody = new Dictionary<string, object>
            {
                { "base64", base64 },
                {
                    "options",
                    new Dictionary<string, object>
                    {
                        { "data.format", "dict" },
                        { "tbpu.parser", String.IsNullOrWhiteSpace(options.Parser) ? "single_line" : options.Parser },
                        { "ocr.cls", options.CorrectOrientation },
                        { "ocr.limit_side_len", options.LimitSideLength > 0 ? options.LimitSideLength : 4320 },
                        { "ocr.language", String.IsNullOrWhiteSpace(options.LanguageKey)
                            ? "models/config_en.txt" : options.LanguageKey }
                    }
                }
            };
            string json = new JavaScriptSerializer().Serialize(requestBody);
            using (StringContent content = new StringContent(json, Encoding.UTF8, "application/json"))
            using (HttpResponseMessage response = await Client.PostAsync(
                BuildUri(options.Endpoint, "/api/ocr"), content, cancellationToken))
            {
                string responseText = await response.Content.ReadAsStringAsync();
                if (!response.IsSuccessStatusCode)
                    throw new InvalidOperationException(
                        "Umi-OCR request failed: HTTP " + (int)response.StatusCode +
                        " " + Limit(responseText, 600));

                return ParseUmiResponse(responseText, imagePath, pageNumber);
            }
        }

        internal static List<TranscriptionLine> ParseUmiResponse(
            string responseText,
            string imagePath,
            int pageNumber)
        {
            IDictionary<string, object> envelope = AsDictionary(
                new JavaScriptSerializer().DeserializeObject(responseText));
            if (envelope == null)
                throw new InvalidOperationException("Umi-OCR returned an invalid response.");

            int code = ToInt(GetValue(envelope, "code"));
            object data = GetValue(envelope, "data");
            if (code == 101)
                return new List<TranscriptionLine>();
            if (code != 100)
                throw new InvalidOperationException(
                    "Umi-OCR code " + code + ": " + Convert.ToString(data, CultureInfo.InvariantCulture));

            List<TranscriptionLine> lines = new List<TranscriptionLine>();
            int order = 1;
            foreach (object item in AsItems(data))
            {
                IDictionary<string, object> block = AsDictionary(item);
                if (block == null)
                    continue;
                string text = Convert.ToString(GetValue(block, "text"), CultureInfo.InvariantCulture);
                if (String.IsNullOrWhiteSpace(text))
                    continue;

                double left, top, width, height;
                bool hasCoordinates = TryBounds(GetValue(block, "box"),
                    out left, out top, out width, out height);
                double score = ToDouble(GetValue(block, "score"));
                lines.Add(new TranscriptionLine
                {
                    Id = order,
                    Page = pageNumber,
                    Order = order,
                    SourceFile = Path.GetFileName(imagePath),
                    Original = text,
                    Cleaned = LocalCleaner.Clean(text),
                    Translation = String.Empty,
                    Status = "Printed OCR · Umi-OCR" +
                        (score > 0 ? " · " + score.ToString("0.00", CultureInfo.InvariantCulture) : String.Empty),
                    X = left,
                    Y = top,
                    Width = width,
                    Height = height,
                    HasCoordinates = hasCoordinates
                });
                order++;
            }
            return lines
                .OrderBy(line => line.Y)
                .ThenBy(line => line.X)
                .Select((line, index) =>
                {
                    line.Order = index + 1;
                    line.Id = index + 1;
                    return line;
                })
                .ToList();
        }

        internal static List<TranscriptionLine> ParseUmiDocumentData(
            object data,
            string pdfPath,
            int startPage,
            int pagesCount)
        {
            List<TranscriptionLine> result = new List<TranscriptionLine>();
            string sourceFile = Path.GetFileName(pdfPath);
            if (data is string)
            {
                string text = (string)data;
                string[] pages = text.Split(new[] { '\f' },
                    StringSplitOptions.RemoveEmptyEntries);
                for (int index = 0; index < pages.Length; index++)
                {
                    string pageText = pages[index].Trim();
                    if (String.IsNullOrWhiteSpace(pageText))
                        continue;
                    result.Add(new TranscriptionLine
                    {
                        Page = startPage + index,
                        SourceFile = sourceFile,
                        Original = pageText,
                        Cleaned = LocalCleaner.Clean(pageText),
                        Translation = String.Empty,
                        Status = "Printed OCR · Umi-OCR PDF"
                    });
                }
            }
            else
            {
                List<object> topLevel = AsItems(data).ToList();
                for (int index = 0; index < topLevel.Count; index++)
                {
                    int pageNumber = startPage + index;
                    ExtractDocumentBlocks(
                        topLevel[index], ref pageNumber, sourceFile, startPage, result, 0);
                }
            }

            result = result
                .OrderBy(line => line.Page)
                .ThenBy(line => line.Y)
                .ThenBy(line => line.X)
                .Select((line, index) =>
                {
                    line.Order = index + 1;
                    line.Id = index + 1;
                    if (String.IsNullOrWhiteSpace(line.Status))
                        line.Status = "Printed OCR · Umi-OCR PDF";
                    return line;
                })
                .ToList();
            return result;
        }

        private static void ExtractDocumentBlocks(
            object node,
            ref int currentPage,
            string sourceFile,
            int startPage,
            List<TranscriptionLine> result,
            int depth)
        {
            if (node == null || depth > 8)
                return;
            IDictionary<string, object> dictionary = AsDictionary(node);
            if (dictionary != null)
            {
                int explicitPage = FirstPositive(
                    GetValue(dictionary, "page"),
                    GetValue(dictionary, "page_num"),
                    GetValue(dictionary, "pageNumber"),
                    GetValue(dictionary, "pageIndex"));
                if (explicitPage > 0)
                    currentPage = startPage + explicitPage - 1;

                bool hasNestedText = dictionary.Values.Any(value =>
                    ContainsTextBlock(value, 0));
                string text = Convert.ToString(
                    GetValue(dictionary, "text"), CultureInfo.InvariantCulture);
                if (!hasNestedText && !String.IsNullOrWhiteSpace(text))
                {
                    double left, top, width, height;
                    bool hasCoordinates = TryBounds(GetValue(dictionary, "box"),
                        out left, out top, out width, out height);
                    double score = ToDouble(GetValue(dictionary, "score"));
                    result.Add(new TranscriptionLine
                    {
                        Page = currentPage,
                        SourceFile = sourceFile,
                        Original = text,
                        Cleaned = LocalCleaner.Clean(text),
                        Translation = String.Empty,
                        Status = "Printed OCR · Umi-OCR PDF" +
                            (score > 0
                                ? " · " + score.ToString("0.00", CultureInfo.InvariantCulture)
                                : String.Empty),
                        X = left,
                        Y = top,
                        Width = width,
                        Height = height,
                        HasCoordinates = hasCoordinates
                    });
                }
                foreach (object child in dictionary.Values)
                    ExtractDocumentBlocks(child, ref currentPage, sourceFile,
                        startPage, result, depth + 1);
                return;
            }

            foreach (object child in AsItems(node))
                ExtractDocumentBlocks(child, ref currentPage, sourceFile,
                    startPage, result, depth + 1);
        }

        private static bool ContainsTextBlock(object value, int depth)
        {
            if (value == null || depth > 5 || value is string)
                return false;
            IDictionary<string, object> dictionary = AsDictionary(value);
            if (dictionary != null)
            {
                if (dictionary.ContainsKey("text") &&
                    dictionary.ContainsKey("box"))
                    return true;
                return dictionary.Values.Any(child => ContainsTextBlock(child, depth + 1));
            }
            return AsItems(value).Any(child => ContainsTextBlock(child, depth + 1));
        }

        private static int FirstPositive(params object[] values)
        {
            foreach (object value in values)
            {
                int number = ToInt(value);
                if (number > 0)
                    return number;
            }
            return 0;
        }

        private static async Task<List<TranscriptionLine>> RecognizeWithTesseractAsync(
            string imagePath,
            int pageNumber,
            PrintedOcrOptions options,
            CancellationToken cancellationToken)
        {
            string executable = String.IsNullOrWhiteSpace(options.TesseractPath)
                ? FindTesseract() : options.TesseractPath.Trim('"');
            if (!File.Exists(executable))
                throw new FileNotFoundException(
                    "Tesseract was not found. Set the tesseract.exe path first.", executable);

            string language = String.IsNullOrWhiteSpace(options.TesseractLanguage)
                ? "eng" : options.TesseractLanguage.Trim();
            ProcessStartInfo start = new ProcessStartInfo
            {
                FileName = executable,
                Arguments = Quote(imagePath) + " stdout -l " + QuoteArgument(language) + " --psm 3 tsv",
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8
            };
            using (Process process = new Process { StartInfo = start })
            {
                if (!process.Start())
                    throw new InvalidOperationException("Tesseract could not be started.");
                Task<string> outputTask = process.StandardOutput.ReadToEndAsync();
                Task<string> errorTask = process.StandardError.ReadToEndAsync();
                while (!process.HasExited)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    await Task.Delay(80, cancellationToken);
                }
                string output = await outputTask;
                string error = await errorTask;
                if (process.ExitCode != 0)
                    throw new InvalidOperationException(
                        "Tesseract failed with exit code " + process.ExitCode + ": " + Limit(error, 700));
                return ParseTesseractTsv(output, imagePath, pageNumber);
            }
        }

        internal static List<TranscriptionLine> ParseTesseractTsv(
            string tsv,
            string imagePath,
            int pageNumber)
        {
            List<TesseractWord> words = new List<TesseractWord>();
            foreach (string rawLine in (tsv ?? String.Empty).Split(new[] { '\r', '\n' },
                StringSplitOptions.RemoveEmptyEntries))
            {
                string[] columns = rawLine.Split('\t');
                if (columns.Length < 12 ||
                    String.Equals(columns[0], "level", StringComparison.OrdinalIgnoreCase))
                    continue;
                int level;
                if (!Int32.TryParse(columns[0], NumberStyles.Integer,
                    CultureInfo.InvariantCulture, out level) || level != 5)
                    continue;
                string text = columns[11].Trim();
                if (String.IsNullOrWhiteSpace(text))
                    continue;

                words.Add(new TesseractWord
                {
                    Block = columns[2],
                    Paragraph = columns[3],
                    Line = columns[4],
                    Left = ToDouble(columns[6]),
                    Top = ToDouble(columns[7]),
                    Width = ToDouble(columns[8]),
                    Height = ToDouble(columns[9]),
                    Confidence = ToDouble(columns[10]),
                    Text = text
                });
            }

            List<TranscriptionLine> result = new List<TranscriptionLine>();
            foreach (var group in words
                .GroupBy(word => new { word.Block, word.Paragraph, word.Line })
                .OrderBy(group => group.Min(word => word.Top))
                .ThenBy(group => group.Min(word => word.Left)))
            {
                List<TesseractWord> rowWords = group.OrderBy(word => word.Left).ToList();
                double left = rowWords.Min(word => word.Left);
                double top = rowWords.Min(word => word.Top);
                double right = rowWords.Max(word => word.Left + word.Width);
                double bottom = rowWords.Max(word => word.Top + word.Height);
                double confidence = rowWords.Where(word => word.Confidence >= 0)
                    .Select(word => word.Confidence).DefaultIfEmpty(0).Average() / 100.0;
                string text = String.Join(" ", rowWords.Select(word => word.Text));
                result.Add(new TranscriptionLine
                {
                    Id = result.Count + 1,
                    Page = pageNumber,
                    Order = result.Count + 1,
                    SourceFile = Path.GetFileName(imagePath),
                    Original = text,
                    Cleaned = LocalCleaner.Clean(text),
                    Translation = String.Empty,
                    Status = "Printed OCR · Tesseract" +
                        (confidence > 0
                            ? " · " + confidence.ToString("0.00", CultureInfo.InvariantCulture)
                            : String.Empty),
                    X = left,
                    Y = top,
                    Width = Math.Max(0, right - left),
                    Height = Math.Max(0, bottom - top),
                    HasCoordinates = true
                });
            }
            return result;
        }

        private static HttpClient CreateClient()
        {
            HttpClient client = new HttpClient();
            client.Timeout = TimeSpan.FromMinutes(4);
            client.DefaultRequestHeaders.UserAgent.ParseAdd("eScriptorium-Studio/1.9");
            return client;
        }

        private static Uri BuildUri(string endpoint, string path)
        {
            string value = String.IsNullOrWhiteSpace(endpoint)
                ? "http://127.0.0.1:1224" : endpoint.Trim();
            if (!value.StartsWith("http://", StringComparison.OrdinalIgnoreCase) &&
                !value.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
                value = "http://" + value;
            value = value.TrimEnd('/');
            if (value.EndsWith("/api/ocr", StringComparison.OrdinalIgnoreCase))
                value = value.Substring(0, value.Length - "/api/ocr".Length);
            return new Uri(value + path, UriKind.Absolute);
        }

        private static object GetValue(IDictionary<string, object> dictionary, string key)
        {
            object value;
            return dictionary != null && dictionary.TryGetValue(key, out value) ? value : null;
        }

        private static IDictionary<string, object> AsDictionary(object value)
        {
            return value as IDictionary<string, object>;
        }

        private static IEnumerable<object> AsItems(object value)
        {
            if (value == null)
                return new object[0];
            object[] array = value as object[];
            if (array != null)
                return array;
            IEnumerable enumerable = value as IEnumerable;
            if (enumerable == null || value is string)
                return new object[0];
            return enumerable.Cast<object>();
        }

        private static bool TryBounds(
            object value,
            out double left,
            out double top,
            out double width,
            out double height)
        {
            left = top = width = height = 0;
            List<PointF> points = new List<PointF>();
            foreach (object item in AsItems(value))
            {
                IList<object> pair = AsItems(item).ToList();
                if (pair.Count >= 2)
                    points.Add(new PointF((float)ToDouble(pair[0]), (float)ToDouble(pair[1])));
            }
            if (points.Count < 2)
                return false;
            left = points.Min(point => point.X);
            top = points.Min(point => point.Y);
            double right = points.Max(point => point.X);
            double bottom = points.Max(point => point.Y);
            width = Math.Max(0, right - left);
            height = Math.Max(0, bottom - top);
            return true;
        }

        private static int ToInt(object value)
        {
            if (value == null)
                return 0;
            int result;
            if (Int32.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture),
                NumberStyles.Integer, CultureInfo.InvariantCulture, out result))
                return result;
            return 0;
        }

        private static bool ToBool(object value)
        {
            if (value is bool)
                return (bool)value;
            bool result;
            if (Boolean.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture),
                out result))
                return result;
            return ToInt(value) != 0;
        }

        private static double ToDouble(object value)
        {
            if (value == null)
                return 0;
            double result;
            if (Double.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture),
                NumberStyles.Float, CultureInfo.InvariantCulture, out result))
                return result;
            return 0;
        }

        private static string Quote(string value)
        {
            return "\"" + (value ?? String.Empty).Replace("\"", "\\\"") + "\"";
        }

        private static string QuoteArgument(string value)
        {
            return (value ?? String.Empty).Replace("\"", String.Empty);
        }

        private static string Limit(string value, int length)
        {
            string text = value ?? String.Empty;
            return text.Length <= length ? text : text.Substring(0, length) + "…";
        }

        private sealed class TesseractWord
        {
            public string Block { get; set; }
            public string Paragraph { get; set; }
            public string Line { get; set; }
            public double Left { get; set; }
            public double Top { get; set; }
            public double Width { get; set; }
            public double Height { get; set; }
            public double Confidence { get; set; }
            public string Text { get; set; }
        }
    }
}
