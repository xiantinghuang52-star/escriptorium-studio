using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;

namespace EScriptoriumStudio
{
    internal sealed class ProcessingProject
    {
        public string Name { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public List<ProcessingGroup> Groups { get; set; }

        public ProcessingProject()
        {
            Name = "Unnamed manuscript project";
            CreatedAt = DateTime.Now;
            UpdatedAt = DateTime.Now;
            Groups = new List<ProcessingGroup>();
        }
    }

    internal sealed class ProcessingGroup
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public List<int> Pages { get; set; }
        public string SourceLanguage { get; set; }
        public string TargetLanguage { get; set; }
        public int Concurrency { get; set; }
        public string Status { get; set; }
        public string LastMessage { get; set; }
        public DateTime? LastRunAt { get; set; }
        public string LastTranslation { get; set; }
        public string LastCleanse { get; set; }

        public ProcessingGroup()
        {
            Id = Guid.NewGuid().ToString("N");
            Name = String.Empty;
            Pages = new List<int>();
            SourceLanguage = String.Empty;
            TargetLanguage = String.Empty;
            Concurrency = 1;
            Status = "Pending";
            LastMessage = String.Empty;
            LastTranslation = String.Empty;
            LastCleanse = String.Empty;
        }

        public string PageLabel
        {
            get { return ProcessingProjectStore.FormatPages(Pages); }
        }
    }

    internal static class ProcessingProjectStore
    {
        public static string ProjectFile
        {
            get { return Path.Combine(AppPaths.Root, "processing-project.json"); }
        }

        public static ProcessingProject LoadOrCreate()
        {
            try
            {
                if (File.Exists(ProjectFile))
                {
                    string json = File.ReadAllText(ProjectFile, Encoding.UTF8);
                    ProcessingProject project =
                        new JavaScriptSerializer().Deserialize<ProcessingProject>(json);
                    if (project != null)
                    {
                        if (project.Groups == null)
                            project.Groups = new List<ProcessingGroup>();
                        foreach (ProcessingGroup group in project.Groups)
                        {
                            if (group.Pages == null)
                                group.Pages = new List<int>();
                            if (group.Concurrency < 1 || group.Concurrency > 4)
                                group.Concurrency = 1;
                        }
                        return project;
                    }
                }
            }
            catch
            {
            }
            return new ProcessingProject();
        }

        public static void Save(ProcessingProject project)
        {
            AppPaths.EnsureDirectories();
            project.UpdatedAt = DateTime.Now;
            File.WriteAllText(
                ProjectFile,
                new JavaScriptSerializer().Serialize(project),
                new UTF8Encoding(false));
        }

        public static ParsedPages ParsePages(string text)
        {
            ParsedPages result = new ParsedPages();
            if (String.IsNullOrWhiteSpace(text))
            {
                result.Error = L.T("Enter page numbers, for example: 1-3,5,8.",
                    "请输入页码，例如：1-3,5,8。");
                return result;
            }

            foreach (string rawPart in text.Split(new[] { ',', ';', '，', '；' },
                StringSplitOptions.RemoveEmptyEntries))
            {
                string part = rawPart.Trim();
                if (part.Length == 0)
                    continue;
                int single;
                if (Int32.TryParse(part, out single))
                {
                    if (single < 1)
                    {
                        result.Error = L.T("Page numbers must be positive.",
                            "页码必须是正整数。");
                        return result;
                    }
                    result.Pages.Add(single);
                    continue;
                }

                string[] range = part.Split('-');
                int start;
                int end;
                if (range.Length == 2 &&
                    Int32.TryParse(range[0].Trim(), out start) &&
                    Int32.TryParse(range[1].Trim(), out end) &&
                    start > 0 && end >= start && end - start <= 500)
                {
                    for (int page = start; page <= end; page++)
                        result.Pages.Add(page);
                    continue;
                }

                result.Error = L.T("Invalid page range: ", "页码范围无效：") + part;
                return result;
            }

            result.Pages = result.Pages.Distinct().OrderBy(page => page).ToList();
            if (result.Pages.Count == 0)
                result.Error = L.T("No valid page numbers were entered.",
                    "没有输入有效页码。");
            return result;
        }

        public static string FormatPages(IEnumerable<int> pages)
        {
            List<int> ordered = (pages ?? Enumerable.Empty<int>())
                .Distinct()
                .OrderBy(page => page)
                .ToList();
            if (ordered.Count == 0)
                return "—";

            List<string> segments = new List<string>();
            int start = ordered[0];
            int previous = start;
            for (int index = 1; index <= ordered.Count; index++)
            {
                bool endOfRun = index == ordered.Count ||
                    ordered[index] != previous + 1;
                if (endOfRun)
                {
                    segments.Add(start == previous
                        ? start.ToString()
                        : start + "-" + previous);
                    if (index < ordered.Count)
                        start = ordered[index];
                }
                if (index < ordered.Count)
                    previous = ordered[index];
            }
            return String.Join(",", segments);
        }
    }

    internal sealed class ParsedPages
    {
        public List<int> Pages { get; set; }
        public string Error { get; set; }

        public ParsedPages()
        {
            Pages = new List<int>();
            Error = String.Empty;
        }
    }
}
