using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using System.Xml;

namespace EScriptoriumStudio
{
    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            AppDomain.CurrentDomain.AssemblyResolve += ResolveEmbeddedAssembly;
            if (args != null && Array.IndexOf(args, "--self-test") >= 0)
                return RunSelfTest();
            if (args != null && Array.IndexOf(args, "--check") >= 0)
                return RunSelfTest();
            if (args != null && args.Any(value =>
                value == "--dump-deployment" ||
                value.StartsWith("--dump-deployment=", StringComparison.OrdinalIgnoreCase)))
                return DumpDeployment(args);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.ThreadException += delegate(object sender, ThreadExceptionEventArgs e)
            {
                AppPaths.Log("Unhandled UI exception: " + e.Exception);
                MessageBox.Show(
                    e.Exception.Message,
                    L.T("Unexpected error", "发生意外错误"),
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            };
            bool autoInstall = args != null && Array.IndexOf(args, "--auto-install") >= 0;
            Application.Run(new MainForm(autoInstall));
            return 0;
        }

        private static Assembly ResolveEmbeddedAssembly(object sender, ResolveEventArgs args)
        {
            AssemblyName requested = new AssemblyName(args.Name);
            string resourceName = null;
            if (String.Equals(requested.Name, "Microsoft.Web.WebView2.Core",
                StringComparison.OrdinalIgnoreCase))
                resourceName = "EScriptoriumStudio.Resources.Microsoft.Web.WebView2.Core.dll";
            else if (String.Equals(requested.Name, "Microsoft.Web.WebView2.WinForms",
                StringComparison.OrdinalIgnoreCase))
                resourceName = "EScriptoriumStudio.Resources.Microsoft.Web.WebView2.WinForms.dll";
            if (resourceName == null)
                return null;

            using (Stream stream = Assembly.GetExecutingAssembly()
                .GetManifestResourceStream(resourceName))
            {
                if (stream == null)
                    return null;
                byte[] data = new byte[stream.Length];
                int read = 0;
                while (read < data.Length)
                {
                    int count = stream.Read(data, read, data.Length - read);
                    if (count <= 0)
                        break;
                    read += count;
                }
                return Assembly.Load(data);
            }
        }

        private static int RunSelfTest()
        {
            try
            {
                string temp = Path.Combine(Path.GetTempPath(), "escriptorium-studio-self-test-" +
                    Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(temp);
                string altoPath = Path.Combine(temp, "sample.xml");
                string alto = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                    "<alto><Layout><Page><PrintSpace><Compositor><TextBlock>" +
                    "<TextLine HPOS=\"10\" VPOS=\"20\" WIDTH=\"300\" HEIGHT=\"40\">" +
                    "<String CONTENT=\"Hath ſhe no pity?\" HPOS=\"10\" VPOS=\"20\" WIDTH=\"300\" HEIGHT=\"40\"/>" +
                    "</TextLine></TextBlock></Compositor></PrintSpace></Page></Layout></alto>";
                File.WriteAllText(altoPath, alto, new UTF8Encoding(false));
                List<TranscriptionLine> lines = DocumentParser.ReadFile(altoPath);
                if (lines.Count != 1 || !lines[0].HasCoordinates || lines[0].X != 10)
                    return 10;
                string multiPageAlto = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                    "<alto><Layout><Page ID=\"p1\"><PrintSpace><TextBlock>" +
                    "<TextLine HPOS=\"1\" VPOS=\"2\" WIDTH=\"100\" HEIGHT=\"20\">" +
                    "<String CONTENT=\"Page one\"/></TextLine></TextBlock></PrintSpace></Page>" +
                    "<Page ID=\"p2\"><PrintSpace><TextBlock>" +
                    "<TextLine HPOS=\"1\" VPOS=\"2\" WIDTH=\"100\" HEIGHT=\"20\">" +
                    "<String CONTENT=\"Page two\"/></TextLine></TextBlock></PrintSpace></Page>" +
                    "</Layout></alto>";
                string multiPagePath = Path.Combine(temp, "two-pages.alto.xml");
                File.WriteAllText(multiPagePath, multiPageAlto, new UTF8Encoding(false));
                List<TranscriptionLine> multiPageLines = DocumentParser.ReadFile(multiPagePath);
                if (multiPageLines.Count != 2 ||
                    multiPageLines[0].Page != 1 ||
                    multiPageLines[1].Page != 2)
                    return 18;
                if (HistoricalSpellingResolver.ApplyKnownCorrections(
                        "lhe lhall luch thil", "English") != "she shall such this")
                    return 19;
                if (HistoricalSpellingResolver.ApplyKnownCorrections(
                        "fich ift folch", "German") != "sich ist solch")
                    return 20;
                ParsedPages parsedPages = ProcessingProjectStore.ParsePages("1-3,5");
                if (!String.IsNullOrWhiteSpace(parsedPages.Error) ||
                    ProcessingProjectStore.FormatPages(parsedPages.Pages) != "1-3,5")
                    return 21;
                if (new AppSettings().PageConcurrency != 1)
                    return 22;
                if (EscriptoriumApiClient.DocumentIdFromUrl(
                        "http://localhost:8080/document/123/images/") != 123)
                    return 23;
                string cleaned = LocalCleaner.Clean(lines[0].Original);
                if (String.IsNullOrWhiteSpace(cleaned))
                    return 11;
                lines[0].Cleaned = cleaned;
                lines[0].Translation = "她不可怜吗？";
                TextAnalysis analysis = TextAnalyzer.Analyze(lines);
                if (analysis.Tokens < 4)
                    return 12;
                AiRequestException codedError = AiErrors.Create(
                    AiErrorCode.WindowsTlsCredentials,
                    "SELFTEST_SEC_E_NO_CREDENTIALS");
                if (!codedError.UserMessage.Contains("AIC004") ||
                    !codedError.UserMessage.Contains("Windows TLS") ||
                    !codedError.UserMessage.Contains("Windows TLS 无法"))
                    return 13;
                if (AiErrors.FromHttpStatus(HttpStatusCode.Unauthorized, "test").Code != AiErrorCode.Unauthorized ||
                    AiErrors.FromHttpStatus(HttpStatusCode.NotFound, "test").Code != AiErrorCode.EndpointOrModelNotFound ||
                    AiErrors.FromHttpStatus((HttpStatusCode)429, "test").Code != AiErrorCode.RateLimitOrQuota ||
                    AiErrors.FromHttpStatus(HttpStatusCode.BadGateway, "test").Code != AiErrorCode.ProviderServerError)
                    return 14;
                if (!AiErrors.BilingualReference().Contains("AIC016"))
                    return 15;
                AppSettings freshSettings = new AppSettings();
                if (freshSettings.TargetLanguage.IndexOf("English", StringComparison.OrdinalIgnoreCase) < 0)
                    return 16;
                string contextText = "She has no pity. This is the final contextual translation.";
                List<ContextPageResult> contextPages = new List<ContextPageResult>
                {
                    new ContextPageResult
                    {
                        Page = 1,
                        ContextualCleanse = "Hath she no pity?",
                        Translation = contextText,
                        LineCount = 1,
                        LineIds = new List<int> { 1 }
                    }
                };
                ExportService.ExportCsv(Path.Combine(temp, "sample.csv"), lines);
                ExportService.ExportJson(
                    Path.Combine(temp, "sample.json"), lines, analysis,
                    contextText, "Hath she no pity?", contextPages);
                ExportService.ExportTei(
                    Path.Combine(temp, "sample.tei.xml"),
                    lines,
                    analysis,
                    "Early modern English",
                    "English",
                    contextText,
                    "Hath she no pity?",
                    contextPages);
                if (!File.ReadAllText(Path.Combine(temp, "sample.json")).Contains("context_translation") ||
                    !File.ReadAllText(Path.Combine(temp, "sample.json")).Contains("context_pages") ||
                    !File.ReadAllText(Path.Combine(temp, "sample.tei.xml")).Contains("pageContextNode"))
                    return 17;
                string wordPath = Path.Combine(temp, "sample.docx");
                WordExportService.ExportBilingualDocument(
                    wordPath,
                    lines,
                    analysis,
                    "Early modern English",
                    "English",
                    contextText,
                    "Hath she no pity?",
                    contextPages);
                using (ZipArchive word = ZipFile.OpenRead(wordPath))
                {
                    ZipArchiveEntry documentEntry = word.GetEntry("word/document.xml");
                    if (documentEntry == null)
                        return 24;
                    string wordXml;
                    using (StreamReader reader = new StreamReader(
                        documentEntry.Open(), Encoding.UTF8, true))
                        wordXml = reader.ReadToEnd();
                    if (!wordXml.Contains("Original / 原文") ||
                        !wordXml.Contains("Cleanse / 清洗文") ||
                        !wordXml.Contains("Translation / 译文") ||
                        !wordXml.Contains("她不可怜吗？"))
                        return 25;
                }
                string umiJson =
                    "{\"code\":100,\"data\":[{\"text\":\"Printed ſhe\",\"score\":0.97," +
                    "\"box\":[[10,20],[110,20],[110,45],[10,45]]}]," +
                    "\"time\":0.2,\"timestamp\":0}";
                List<TranscriptionLine> umiLines = PrintedOcrClient.ParseUmiResponse(
                    umiJson, "printed.png", 3);
                if (umiLines.Count != 1 ||
                    !umiLines[0].HasCoordinates ||
                    umiLines[0].X != 10 ||
                    umiLines[0].Y != 20 ||
                    umiLines[0].Page != 3)
                    return 26;
                string tsv =
                    "level\tpage_num\tblock_num\tpar_num\tline_num\tword_num\tleft\ttop\twidth\theight\tconf\ttext\n" +
                    "5\t1\t1\t1\t1\t1\t10\t20\t55\t20\t96\tPrinted\n" +
                    "5\t1\t1\t1\t1\t2\t70\t20\t45\t20\t94\ttext\n";
                List<TranscriptionLine> tesseractLines = PrintedOcrClient.ParseTesseractTsv(
                    tsv, "printed.png", 4);
                if (tesseractLines.Count != 1 ||
                    tesseractLines[0].Original != "Printed text" ||
                    !tesseractLines[0].HasCoordinates ||
                    tesseractLines[0].Page != 4)
                    return 27;
                object pdfData = new JavaScriptSerializer().DeserializeObject(
                    "[{\"page\":1,\"blocks\":[" +
                    "{\"text\":\"Printed PDF line\",\"score\":0.96," +
                    "\"box\":[[20,30],[220,30],[220,60],[20,60]]}]}]");
                List<TranscriptionLine> pdfLines = PrintedOcrClient.ParseUmiDocumentData(
                    pdfData, "printed.pdf", 7, 1);
                if (pdfLines.Count != 1 ||
                    pdfLines[0].Page != 7 ||
                    !pdfLines[0].HasCoordinates ||
                    pdfLines[0].Original != "Printed PDF line")
                    return 29;
                if (new AppSettings().OcrBackend != "Umi-OCR")
                    return 28;
                try { Directory.Delete(temp, true); } catch { }
                AppPaths.Log("SELF-TEST PASS");
                return 0;
            }
            catch (Exception ex)
            {
                AppPaths.Log("SELF-TEST FAIL: " + ex);
                return 2;
            }
        }

        private static int DumpDeployment(string[] args)
        {
            try
            {
                int index = Array.IndexOf(args, "--dump-deployment");
                string inline = args.FirstOrDefault(value =>
                    value.StartsWith("--dump-deployment=", StringComparison.OrdinalIgnoreCase));
                string target = inline != null
                    ? inline.Substring("--dump-deployment=".Length).Trim('"')
                    : (index >= 0 && index + 1 < args.Length
                        ? args[index + 1].Trim('"')
                        : Path.Combine(Path.GetTempPath(), "escriptorium-studio-deployment"));
                Directory.CreateDirectory(target);
                AppSettings settings = AppSettings.Load();
                settings.InstallDirectory = target;
                if (String.IsNullOrEmpty(settings.GetEscriptoriumPassword()))
                    settings.SetEscriptoriumPassword("SelfTest-Manuscript-7K9Q");
                InstallerEngine.WriteDeploymentFiles(settings, target);
                return 0;
            }
            catch (Exception ex)
            {
                try
                {
                    string targetDirectory = Path.Combine(Path.GetTempPath(), "escriptorium-studio-dump-error");
                    Directory.CreateDirectory(targetDirectory);
                    File.WriteAllText(Path.Combine(targetDirectory, "error.txt"), ex.ToString());
                }
                catch
                {
                }
                AppPaths.Log("DUMP-DEPLOYMENT FAIL: " + ex);
                return 3;
            }
        }
    }
}
