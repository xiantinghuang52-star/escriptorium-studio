using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace EScriptoriumStudio
{
    internal static class L
    {
        public static bool Zh;

        public static string T(string en, string zh)
        {
            return Zh ? zh : en;
        }
    }

    internal static class Palette
    {
        public static readonly Color Ink = Color.FromArgb(25, 37, 45);
        public static readonly Color Deep = Color.FromArgb(14, 36, 48);
        public static readonly Color Deep2 = Color.FromArgb(22, 50, 62);
        public static readonly Color Parchment = Color.FromArgb(246, 242, 232);
        public static readonly Color Paper = Color.FromArgb(255, 253, 248);
        public static readonly Color Card = Color.FromArgb(255, 252, 245);
        public static readonly Color Line = Color.FromArgb(218, 210, 196);
        public static readonly Color Muted = Color.FromArgb(99, 103, 99);
        public static readonly Color Accent = Color.FromArgb(167, 58, 42);
        public static readonly Color AccentHover = Color.FromArgb(189, 69, 48);
        public static readonly Color Gold = Color.FromArgb(193, 148, 64);
        public static readonly Color Green = Color.FromArgb(51, 126, 91);
        public static readonly Color Amber = Color.FromArgb(180, 120, 29);
        public static readonly Color Red = Color.FromArgb(176, 50, 46);
        public static readonly Color Blue = Color.FromArgb(49, 109, 145);
    }

    internal static class Ui
    {
        public static readonly Font Body;
        public static readonly Font BodySmall;
        public static readonly Font BodyBold;
        public static readonly Font Heading;
        public static readonly Font Display;
        public static readonly Font Mono;

        static Ui()
        {
            string uiFamily = FirstInstalled("Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI");
            string monoFamily = FirstInstalled("Cascadia Mono", "Consolas", "Courier New");
            Body = new Font(uiFamily, 9.5f, FontStyle.Regular, GraphicsUnit.Point);
            BodySmall = new Font(uiFamily, 8.4f, FontStyle.Regular, GraphicsUnit.Point);
            BodyBold = new Font(uiFamily, 9.5f, FontStyle.Bold, GraphicsUnit.Point);
            Heading = new Font(uiFamily, 16f, FontStyle.Bold, GraphicsUnit.Point);
            Display = new Font(uiFamily, 27f, FontStyle.Bold, GraphicsUnit.Point);
            Mono = new Font(monoFamily, 8.7f, FontStyle.Regular, GraphicsUnit.Point);
        }

        private static string FirstInstalled(params string[] names)
        {
            foreach (string name in names)
            {
                try
                {
                    Font test = new Font(name, 9f);
                    bool exact = String.Equals(test.Name, name, StringComparison.OrdinalIgnoreCase);
                    test.Dispose();
                    if (exact)
                        return name;
                }
                catch
                {
                }
            }
            return SystemFonts.MessageBoxFont.Name;
        }

        public static Button Button(string text, bool primary)
        {
            Button button = new Button();
            button.Text = text;
            button.AutoSize = false;
            button.Height = 38;
            button.Width = 152;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = primary ? 0 : 1;
            button.FlatAppearance.BorderColor = Palette.Line;
            button.BackColor = primary ? Palette.Accent : Palette.Card;
            button.ForeColor = primary ? Color.White : Palette.Ink;
            button.Font = BodyBold;
            button.UseMnemonic = false;
            button.Cursor = Cursors.Hand;
            button.Margin = new Padding(0, 0, 10, 0);
            button.FlatAppearance.MouseOverBackColor = primary ? Palette.AccentHover : Color.FromArgb(240, 235, 225);
            return button;
        }

        public static Label Label(string text, Font font, Color color, int maxWidth)
        {
            Label label = new Label();
            label.Text = text;
            label.Font = font;
            label.ForeColor = color;
            label.BackColor = Color.Transparent;
            label.AutoSize = true;
            label.MaximumSize = new Size(maxWidth, 0);
            label.UseMnemonic = false;
            return label;
        }

        public static Label MutedLabel(string text, int maxWidth)
        {
            return Label(text, Body, Palette.Muted, maxWidth);
        }

        public static TextBox TextBox(string text, bool multiline, bool password)
        {
            TextBox box = new TextBox();
            box.Text = text ?? String.Empty;
            box.Multiline = multiline;
            box.UseSystemPasswordChar = password;
            box.BorderStyle = BorderStyle.FixedSingle;
            box.Font = Body;
            box.BackColor = Color.White;
            box.ForeColor = Palette.Ink;
            box.Height = multiline ? 78 : 30;
            return box;
        }

        public static Panel Spacer(int width, int height)
        {
            Panel panel = new Panel();
            panel.Width = width;
            panel.Height = height;
            panel.Margin = Padding.Empty;
            return panel;
        }

        public static Color StatusColor(bool ok, bool warning)
        {
            if (ok)
                return Palette.Green;
            return warning ? Palette.Amber : Palette.Red;
        }
    }

    internal sealed class RoundedPanel : Panel
    {
        private int _radius = 12;
        private Color _border = Color.Transparent;
        private Color _fill = Palette.Card;

        public int Radius
        {
            get { return _radius; }
            set { _radius = value; Invalidate(); }
        }

        public Color BorderColor
        {
            get { return _border; }
            set { _border = value; Invalidate(); }
        }

        public Color FillColor
        {
            get { return _fill; }
            set { _fill = value; Invalidate(); }
        }

        public RoundedPanel()
        {
            DoubleBuffered = true;
            BackColor = Color.Transparent;
            Padding = new Padding(18);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle rect = new Rectangle(0, 0, Width - 1, Height - 1);
            using (GraphicsPath path = RoundedPath(rect, _radius))
            using (SolidBrush fill = new SolidBrush(_fill))
            using (Pen pen = new Pen(_border))
            {
                e.Graphics.FillPath(fill, path);
                if (_border != Color.Transparent)
                    e.Graphics.DrawPath(pen, path);
            }
            base.OnPaint(e);
        }

        private static GraphicsPath RoundedPath(Rectangle bounds, int radius)
        {
            int diameter = Math.Max(2, radius * 2);
            GraphicsPath path = new GraphicsPath();
            path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
            path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
            path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();
            return path;
        }
    }

    internal sealed class StepBadge : Control
    {
        private string _number = "1";
        private Color _color = Palette.Muted;
        private bool _done;

        public string Number
        {
            get { return _number; }
            set { _number = value; Invalidate(); }
        }

        public Color Color
        {
            get { return _color; }
            set { _color = value; Invalidate(); }
        }

        public bool Done
        {
            get { return _done; }
            set { _done = value; Invalidate(); }
        }

        public StepBadge()
        {
            Width = 34;
            Height = 34;
            DoubleBuffered = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using (SolidBrush fill = new SolidBrush(_color))
                e.Graphics.FillEllipse(fill, 1, 1, Width - 3, Height - 3);
            TextRenderer.DrawText(
                e.Graphics,
                _done ? "✓" : _number,
                Ui.BodyBold,
                ClientRectangle,
                Color.White,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
        }
    }

    internal sealed class TopAccentPanel : Panel
    {
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using (LinearGradientBrush brush = new LinearGradientBrush(
                ClientRectangle,
                Palette.Deep,
                Palette.Deep2,
                LinearGradientMode.Horizontal))
            {
                e.Graphics.FillRectangle(brush, ClientRectangle);
            }
            using (SolidBrush gold = new SolidBrush(Palette.Gold))
                e.Graphics.FillRectangle(gold, 0, Height - 3, Width, 3);
            base.OnPaint(e);
        }
    }
}
