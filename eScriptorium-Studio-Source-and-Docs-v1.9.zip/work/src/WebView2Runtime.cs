using System;
using System.IO;
using System.Reflection;
using Microsoft.Web.WebView2.Core;

namespace EScriptoriumStudio
{
    internal static class WebView2Runtime
    {
        private static bool _loaderReady;
        private static readonly object Lock = new object();

        public static void EnsureLoader()
        {
            lock (Lock)
            {
                if (_loaderReady)
                    return;
                string directory = Path.Combine(AppPaths.Root, "WebView2");
                Directory.CreateDirectory(directory);
                string loaderPath = Path.Combine(directory, "WebView2Loader.dll");
                if (!File.Exists(loaderPath) ||
                    new FileInfo(loaderPath).Length < 100000)
                {
                    using (Stream input = Assembly.GetExecutingAssembly()
                        .GetManifestResourceStream(
                            "EScriptoriumStudio.Resources.WebView2Loader.dll"))
                    {
                        if (input == null)
                            throw new FileNotFoundException(
                                "Embedded WebView2Loader.dll is missing.");
                        using (FileStream output = File.Create(loaderPath))
                            input.CopyTo(output);
                    }
                }
                CoreWebView2Environment.SetLoaderDllFolderPath(directory);
                _loaderReady = true;
            }
        }
    }
}
