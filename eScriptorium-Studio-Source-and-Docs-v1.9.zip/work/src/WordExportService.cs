using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Xml;

namespace EScriptoriumStudio
{
    internal static class WordExportService
    {
        private const string WordNamespace =
            "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
        private const string RelationshipNamespace =
            "http://schemas.openxmlformats.org/package/2006/relationships";

        public static void ExportBilingualDocument(
            string path,
            IList<TranscriptionLine> lines,
            TextAnalysis analysis,
            string sourceLanguage,
            string targetLanguage,
            string contextTranslation,
            string contextCleanse,
            IList<ContextPageResult> contextPages)
        {
            if (String.IsNullOrWhiteSpace(path))
                throw new ArgumentException("A Word document path is required.");
            if (lines == null || lines.Count == 0)
                throw new InvalidOperationException("There are no transcribed lines to export.");

            string fullPath = Path.GetFullPath(path);
            string directory = Path.GetDirectoryName(fullPath);
            if (!String.IsNullOrWhiteSpace(directory))
                Directory.CreateDirectory(directory);

            string temporaryPath = fullPath + ".tmp-" + Guid.NewGuid().ToString("N");
            try
            {
                using (FileStream stream = new FileStream(
                    temporaryPath, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.None))
                using (ZipArchive archive = new ZipArchive(stream, ZipArchiveMode.Create))
                {
                    WriteContentTypes(archive);
                    WritePackageRelationships(archive);
                    WriteDocumentRelationships(archive);
                    WriteDocument(archive, lines, analysis, sourceLanguage, targetLanguage,
                        contextTranslation, contextCleanse, contextPages);
                    WriteStyles(archive);
                WriteSettings(archive);
                    WriteCoreProperties(archive);
                    WriteExtendedProperties(archive);
                }

                if (File.Exists(fullPath))
                    File.Delete(fullPath);
                File.Move(temporaryPath, fullPath);
            }
            finally
            {
                if (File.Exists(temporaryPath))
                {
                    try { File.Delete(temporaryPath); }
                    catch { }
                }
            }
        }

        private static void WriteContentTypes(ZipArchive archive)
        {
            WriteXml(archive, "[Content_Types].xml", writer =>
            {
                writer.WriteStartElement("Types", "http://schemas.openxmlformats.org/package/2006/content-types");
                WriteContentTypeDefault(writer, "rels",
                    "application/vnd.openxmlformats-package.relationships+xml");
                WriteContentTypeDefault(writer, "xml", "application/xml");
                WriteContentTypeOverride(writer, "/word/document.xml",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml");
                WriteContentTypeOverride(writer, "/word/styles.xml",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml");
                WriteContentTypeOverride(writer, "/word/settings.xml",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml");
                WriteContentTypeOverride(writer, "/docProps/core.xml",
                    "application/vnd.openxmlformats-package.core-properties+xml");
                WriteContentTypeOverride(writer, "/docProps/app.xml",
                    "application/vnd.openxmlformats-officedocument.extended-properties+xml");
                writer.WriteEndElement();
            });
        }

        private static void WriteContentTypeDefault(XmlWriter writer, string extension, string type)
        {
            writer.WriteStartElement("Default", "http://schemas.openxmlformats.org/package/2006/content-types");
            writer.WriteAttributeString("Extension", extension);
            writer.WriteAttributeString("ContentType", type);
            writer.WriteEndElement();
        }

        private static void WriteContentTypeOverride(XmlWriter writer, string partName, string type)
        {
            writer.WriteStartElement("Override", "http://schemas.openxmlformats.org/package/2006/content-types");
            writer.WriteAttributeString("PartName", partName);
            writer.WriteAttributeString("ContentType", type);
            writer.WriteEndElement();
        }

        private static void WritePackageRelationships(ZipArchive archive)
        {
            WriteXml(archive, "_rels/.rels", writer =>
            {
                writer.WriteStartElement("Relationships", RelationshipNamespace);
                WriteRelationship(writer, "rId1",
                    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument",
                    "word/document.xml");
                WriteRelationship(writer, "rId2",
                    "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties",
                    "docProps/core.xml");
                WriteRelationship(writer, "rId3",
                    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties",
                    "docProps/app.xml");
                writer.WriteEndElement();
            });
        }

        private static void WriteDocumentRelationships(ZipArchive archive)
        {
            WriteXml(archive, "word/_rels/document.xml.rels", writer =>
            {
                writer.WriteStartElement("Relationships", RelationshipNamespace);
                WriteRelationship(writer, "rId1",
                    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles",
                    "styles.xml");
                WriteRelationship(writer, "rId2",
                    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings",
                    "settings.xml");
                writer.WriteEndElement();
            });
        }

        private static void WriteRelationship(
            XmlWriter writer,
            string id,
            string type,
            string target)
        {
            writer.WriteStartElement("Relationship", RelationshipNamespace);
            writer.WriteAttributeString("Id", id);
            writer.WriteAttributeString("Type", type);
            writer.WriteAttributeString("Target", target);
            writer.WriteEndElement();
        }

        private static void WriteDocument(
            ZipArchive archive,
            IList<TranscriptionLine> lines,
            TextAnalysis analysis,
            string sourceLanguage,
            string targetLanguage,
            string contextTranslation,
            string contextCleanse,
            IList<ContextPageResult> contextPages)
        {
            WriteXml(archive, "word/document.xml", writer =>
            {
                writer.WriteStartElement("w", "document", WordNamespace);
                writer.WriteAttributeString("xmlns", "r",
                    null, "http://schemas.openxmlformats.org/officeDocument/2006/relationships");
                writer.WriteStartElement("w", "body", WordNamespace);

                WriteParagraph(writer, "eScriptorium Studio — Bilingual Transcription / 双语对照转写",
                    true, 32, "1F4E79", "center", 0, 120);
                WriteParagraph(writer,
                    "Source / 源语言: " + SafeText(sourceLanguage) +
                    "    Target / 目标语言: " + SafeText(targetLanguage),
                    false, 19, "666666", "center", 0, 180);

                List<int> pages = lines.Select(line => Math.Max(1, line.Page)).Distinct().OrderBy(page => page).ToList();
                for (int pageIndex = 0; pageIndex < pages.Count; pageIndex++)
                {
                    int pageNumber = pages[pageIndex];
                    List<TranscriptionLine> pageLines = lines
                        .Where(line => Math.Max(1, line.Page) == pageNumber)
                        .OrderBy(line => line.Order)
                        .ThenBy(line => line.Id)
                        .ToList();

                    WriteParagraph(writer,
                        "Page " + pageNumber.ToString(CultureInfo.InvariantCulture) +
                        " / 第 " + pageNumber.ToString(CultureInfo.InvariantCulture) + " 页",
                        true, 28, "1F4E79", "left", 120, 100);
                    WriteBilingualTable(writer, pageNumber, pageLines);

                    ContextPageResult pageContext = contextPages == null
                        ? null
                        : contextPages.FirstOrDefault(item => item.Page == pageNumber);
                    if (pageContext != null &&
                        (!String.IsNullOrWhiteSpace(pageContext.ContextualCleanse) ||
                         !String.IsNullOrWhiteSpace(pageContext.Translation)))
                    {
                        WriteParagraph(writer, "Page contextual cleanse / 页面语境清洗",
                            true, 21, "333333", "left", 140, 60);
                        WriteParagraph(writer, SafeText(pageContext.ContextualCleanse),
                            false, 20, "000000", "left", 0, 100);
                        WriteParagraph(writer, "Page contextual translation / 页面整段译文",
                            true, 21, "333333", "left", 80, 60);
                        WriteParagraph(writer, SafeText(pageContext.Translation),
                            false, 20, "000000", "left", 0, 120);
                    }

                    if (pageIndex < pages.Count - 1)
                        WritePageBreak(writer);
                }

                bool hasLegacyContext =
                    (contextPages == null || contextPages.Count == 0) &&
                    (!String.IsNullOrWhiteSpace(contextCleanse) ||
                     !String.IsNullOrWhiteSpace(contextTranslation));
                if (hasLegacyContext)
                {
                    WritePageBreak(writer);
                    WriteParagraph(writer, "Document contextual cleanse / 全文语境清洗",
                        true, 24, "1F4E79", "left", 0, 80);
                    WriteParagraph(writer, SafeText(contextCleanse),
                        false, 20, "000000", "left", 0, 120);
                    WriteParagraph(writer, "Document contextual translation / 全文语境译文",
                        true, 24, "1F4E79", "left", 0, 80);
                    WriteParagraph(writer, SafeText(contextTranslation),
                        false, 20, "000000", "left", 0, 120);
                }

                if (analysis != null)
                    WriteAnalysis(writer, analysis);

                WriteParagraph(writer,
                    "AI-assisted text is a working draft. Verify names, abbreviations, spelling and " +
                    "uncertain readings against the manuscript image. / " +
                    "AI 输出是工作稿；人名、缩写、拼写与不确定读法必须对照原图复核。",
                    false, 18, "666666", "left", 180, 80);

                writer.WriteStartElement("w", "sectPr", WordNamespace);
                WritePageSize(writer);
                writer.WriteEndElement();

                writer.WriteEndElement();
                writer.WriteEndElement();
            });
        }

        private static void WriteBilingualTable(
            XmlWriter writer,
            int pageNumber,
            IList<TranscriptionLine> lines)
        {
            int[] widths = { 660, 660, 4100, 4100, 4900 };
            writer.WriteStartElement("w", "tbl", WordNamespace);
            writer.WriteStartElement("w", "tblPr", WordNamespace);
            writer.WriteStartElement("w", "tblW", WordNamespace);
            writer.WriteAttributeString("w", "w", WordNamespace, "14420");
            writer.WriteAttributeString("w", "type", WordNamespace, "dxa");
            writer.WriteEndElement();
            writer.WriteStartElement("w", "tblBorders", WordNamespace);
            foreach (string side in new[] { "top", "left", "bottom", "right", "insideH", "insideV" })
            {
                writer.WriteStartElement("w", side, WordNamespace);
                writer.WriteAttributeString("w", "val", WordNamespace, "single");
                writer.WriteAttributeString("w", "sz", WordNamespace, "6");
                writer.WriteAttributeString("w", "space", WordNamespace, "0");
                writer.WriteAttributeString("w", "color", WordNamespace, "A6A6A6");
                writer.WriteEndElement();
            }
            writer.WriteEndElement();
            writer.WriteStartElement("w", "tblLayout", WordNamespace);
            writer.WriteAttributeString("w", "type", WordNamespace, "fixed");
            writer.WriteEndElement();
            writer.WriteEndElement();

            writer.WriteStartElement("w", "tblGrid", WordNamespace);
            foreach (int width in widths)
            {
                writer.WriteStartElement("w", "gridCol", WordNamespace);
                writer.WriteAttributeString("w", "w", WordNamespace,
                    width.ToString(CultureInfo.InvariantCulture));
                writer.WriteEndElement();
            }
            writer.WriteEndElement();

            WriteTableRow(writer,
                new[] { "Page / 页", "Line / 行", "Original / 原文",
                    "Cleanse / 清洗文", "Translation / 译文" },
                widths, true);

            foreach (TranscriptionLine line in lines)
            {
                WriteTableRow(writer, new[]
                {
                    pageNumber.ToString(CultureInfo.InvariantCulture),
                    line.Id.ToString(CultureInfo.InvariantCulture),
                    SafeText(line.Original),
                    SafeText(line.Cleaned),
                    SafeText(line.Translation)
                }, widths, false);
            }

            writer.WriteEndElement();
            WriteParagraph(writer, String.Empty, false, 12, "000000", "left", 0, 40);
        }

        private static void WriteTableRow(
            XmlWriter writer,
            IList<string> values,
            IList<int> widths,
            bool header)
        {
            writer.WriteStartElement("w", "tr", WordNamespace);
            writer.WriteStartElement("w", "trPr", WordNamespace);
            writer.WriteElementString("w", "cantSplit", WordNamespace, String.Empty);
            if (header)
                writer.WriteElementString("w", "tblHeader", WordNamespace, String.Empty);
            writer.WriteEndElement();

            for (int index = 0; index < values.Count; index++)
            {
                writer.WriteStartElement("w", "tc", WordNamespace);
                writer.WriteStartElement("w", "tcPr", WordNamespace);
                writer.WriteStartElement("w", "tcW", WordNamespace);
                writer.WriteAttributeString("w", "w", WordNamespace,
                    widths[index].ToString(CultureInfo.InvariantCulture));
                writer.WriteAttributeString("w", "type", WordNamespace, "dxa");
                writer.WriteEndElement();
                if (header)
                {
                    writer.WriteStartElement("w", "shd", WordNamespace);
                    writer.WriteAttributeString("w", "val", WordNamespace, "clear");
                    writer.WriteAttributeString("w", "color", WordNamespace, "auto");
                    writer.WriteAttributeString("w", "fill", WordNamespace, "D9EAF7");
                    writer.WriteEndElement();
                }
                writer.WriteEndElement();
                WriteParagraph(writer, values[index], header, header ? 18 : 17,
                    header ? "1F1F1F" : "000000", "left", 0, 0);
                writer.WriteEndElement();
            }
            writer.WriteEndElement();
        }

        private static void WriteAnalysis(XmlWriter writer, TextAnalysis analysis)
        {
            WritePageBreak(writer);
            WriteParagraph(writer, "Text analysis / 文本分析",
                true, 26, "1F4E79", "left", 0, 100);
            WriteParagraph(writer,
                "Lines / 行数: " + analysis.Lines.ToString(CultureInfo.InvariantCulture) +
                "    Coordinates / 坐标框: " + analysis.Coordinates.ToString(CultureInfo.InvariantCulture) +
                "    Tokens / 词次: " + analysis.Tokens.ToString(CultureInfo.InvariantCulture) +
                "    Types / 词型: " + analysis.Types.ToString(CultureInfo.InvariantCulture),
                false, 19, "333333", "left", 0, 80);
            WriteParagraph(writer,
                "Type-token ratio / 词型词次比: " +
                analysis.TypeTokenRatio.ToString("0.0000", CultureInfo.InvariantCulture) +
                "    Average token length / 平均词长: " +
                analysis.AverageTokenLength.ToString("0.00", CultureInfo.InvariantCulture) +
                "    Likely language / 语言提示: " + SafeText(analysis.LikelyLanguage),
                false, 19, "333333", "left", 0, 100);
            if (analysis.TopWords != null && analysis.TopWords.Count > 0)
            {
                WriteParagraph(writer, "Frequent words / 高频词",
                    true, 21, "333333", "left", 40, 50);
                WriteParagraph(writer,
                    String.Join(" · ", analysis.TopWords.Take(20)
                        .Select(item => item.Word + " (" + item.Count.ToString(CultureInfo.InvariantCulture) + ")")),
                    false, 19, "000000", "left", 0, 100);
            }
        }

        private static void WriteParagraph(
            XmlWriter writer,
            string text,
            bool bold,
            int halfPointSize,
            string color,
            string alignment,
            int spaceBefore,
            int spaceAfter)
        {
            writer.WriteStartElement("w", "p", WordNamespace);
            writer.WriteStartElement("w", "pPr", WordNamespace);
            if (spaceBefore > 0 || spaceAfter > 0)
            {
                writer.WriteStartElement("w", "spacing", WordNamespace);
                writer.WriteAttributeString("w", "before", WordNamespace,
                    spaceBefore.ToString(CultureInfo.InvariantCulture));
                writer.WriteAttributeString("w", "after", WordNamespace,
                    spaceAfter.ToString(CultureInfo.InvariantCulture));
                writer.WriteAttributeString("w", "line", WordNamespace, "276");
                writer.WriteAttributeString("w", "lineRule", WordNamespace, "auto");
                writer.WriteEndElement();
            }
            if (!String.IsNullOrWhiteSpace(alignment))
            {
                writer.WriteStartElement("w", "jc", WordNamespace);
                writer.WriteAttributeString("w", "val", WordNamespace, alignment);
                writer.WriteEndElement();
            }
            writer.WriteEndElement();

            writer.WriteStartElement("w", "r", WordNamespace);
            writer.WriteStartElement("w", "rPr", WordNamespace);
            writer.WriteStartElement("w", "rFonts", WordNamespace);
            writer.WriteAttributeString("w", "ascii", WordNamespace, "Aptos");
            writer.WriteAttributeString("w", "hAnsi", WordNamespace, "Aptos");
            writer.WriteAttributeString("w", "eastAsia", WordNamespace, "Microsoft YaHei");
            writer.WriteEndElement();
            if (bold)
                writer.WriteElementString("w", "b", WordNamespace, String.Empty);
            if (!String.IsNullOrWhiteSpace(color))
            {
                writer.WriteStartElement("w", "color", WordNamespace);
                writer.WriteAttributeString("w", "val", WordNamespace, color);
                writer.WriteEndElement();
            }
            writer.WriteStartElement("w", "sz", WordNamespace);
            writer.WriteAttributeString("w", "val", WordNamespace,
                halfPointSize.ToString(CultureInfo.InvariantCulture));
            writer.WriteEndElement();
            writer.WriteStartElement("w", "szCs", WordNamespace);
            writer.WriteAttributeString("w", "val", WordNamespace,
                halfPointSize.ToString(CultureInfo.InvariantCulture));
            writer.WriteEndElement();
            writer.WriteEndElement();

            writer.WriteStartElement("w", "t", WordNamespace);
            writer.WriteAttributeString("xml", "space",
                "http://www.w3.org/XML/1998/namespace", "preserve");
            writer.WriteString(text ?? String.Empty);
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.WriteEndElement();
        }

        private static void WritePageBreak(XmlWriter writer)
        {
            writer.WriteStartElement("w", "p", WordNamespace);
            writer.WriteStartElement("w", "r", WordNamespace);
            writer.WriteStartElement("w", "br", WordNamespace);
            writer.WriteAttributeString("w", "type", WordNamespace, "page");
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.WriteEndElement();
        }

        private static void WritePageSize(XmlWriter writer)
        {
            writer.WriteStartElement("w", "pgSz", WordNamespace);
            writer.WriteAttributeString("w", "w", WordNamespace, "16838");
            writer.WriteAttributeString("w", "h", WordNamespace, "11906");
            writer.WriteAttributeString("w", "orient", WordNamespace, "landscape");
            writer.WriteEndElement();
            writer.WriteStartElement("w", "pgMar", WordNamespace);
            writer.WriteAttributeString("w", "top", WordNamespace, "720");
            writer.WriteAttributeString("w", "right", WordNamespace, "720");
            writer.WriteAttributeString("w", "bottom", WordNamespace, "720");
            writer.WriteAttributeString("w", "left", WordNamespace, "720");
            writer.WriteAttributeString("w", "header", WordNamespace, "360");
            writer.WriteAttributeString("w", "footer", WordNamespace, "360");
            writer.WriteAttributeString("w", "gutter", WordNamespace, "0");
            writer.WriteEndElement();
        }

        private static void WriteStyles(ZipArchive archive)
        {
            WriteXml(archive, "word/styles.xml", writer =>
            {
                writer.WriteStartElement("w", "styles", WordNamespace);
                writer.WriteStartElement("w", "docDefaults", WordNamespace);
                writer.WriteStartElement("w", "rPrDefault", WordNamespace);
                writer.WriteStartElement("w", "rPr", WordNamespace);
                writer.WriteStartElement("w", "rFonts", WordNamespace);
                writer.WriteAttributeString("w", "ascii", WordNamespace, "Aptos");
                writer.WriteAttributeString("w", "hAnsi", WordNamespace, "Aptos");
                writer.WriteAttributeString("w", "eastAsia", WordNamespace, "Microsoft YaHei");
                writer.WriteEndElement();
                writer.WriteStartElement("w", "sz", WordNamespace);
                writer.WriteAttributeString("w", "val", WordNamespace, "20");
                writer.WriteEndElement();
                writer.WriteEndElement();
                writer.WriteEndElement();
                writer.WriteEndElement();
                writer.WriteStartElement("w", "style", WordNamespace);
                writer.WriteAttributeString("w", "type", WordNamespace, "paragraph");
                writer.WriteAttributeString("w", "default", WordNamespace, "1");
                writer.WriteAttributeString("w", "styleId", WordNamespace, "Normal");
                writer.WriteStartElement("w", "name", WordNamespace);
                writer.WriteAttributeString("w", "val", WordNamespace, "Normal");
                writer.WriteEndElement();
                writer.WriteEndElement();
                writer.WriteEndElement();
            });
        }

        private static void WriteCoreProperties(ZipArchive archive)
        {
            WriteXml(archive, "docProps/core.xml", writer =>
            {
                string core = "http://schemas.openxmlformats.org/package/2006/metadata/core-properties";
                string dc = "http://purl.org/dc/elements/1.1/";
                string dcterms = "http://purl.org/dc/terms/";
                string xsi = "http://www.w3.org/2001/XMLSchema-instance";
                writer.WriteStartElement("cp", "coreProperties", core);
                writer.WriteAttributeString("xmlns", "dc", null, dc);
                writer.WriteAttributeString("xmlns", "dcterms", null, dcterms);
                writer.WriteAttributeString("xmlns", "xsi", null, xsi);
                writer.WriteElementString("dc", "title", dc, "eScriptorium Studio bilingual transcription");
                writer.WriteElementString("dc", "creator", dc, "eScriptorium Studio");
                writer.WriteElementString("cp", "lastModifiedBy", core, "eScriptorium Studio");
                writer.WriteStartElement("dcterms", "created", dcterms);
                writer.WriteAttributeString("xsi", "type", xsi, "dcterms:W3CDTF");
                writer.WriteString(DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ", CultureInfo.InvariantCulture));
                writer.WriteEndElement();
                writer.WriteEndElement();
            });
        }

        private static void WriteSettings(ZipArchive archive)
        {
            WriteXml(archive, "word/settings.xml", writer =>
            {
                writer.WriteStartElement("w", "settings", WordNamespace);
                writer.WriteStartElement("w", "compat", WordNamespace);
                writer.WriteStartElement("w", "compatSetting", WordNamespace);
                writer.WriteAttributeString("w", "name", WordNamespace, "compatibilityMode");
                writer.WriteAttributeString("w", "uri", WordNamespace,
                    "http://schemas.microsoft.com/office/word");
                writer.WriteAttributeString("w", "val", WordNamespace, "15");
                writer.WriteEndElement();
                writer.WriteEndElement();
                writer.WriteEndElement();
            });
        }

        private static void WriteExtendedProperties(ZipArchive archive)
        {
            WriteXml(archive, "docProps/app.xml", writer =>
            {
                string properties =
                    "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties";
                writer.WriteStartElement("Properties", properties);
                writer.WriteElementString("Application", properties, "eScriptorium Studio");
                writer.WriteElementString("AppVersion", properties, "1.9");
                writer.WriteEndElement();
            });
        }

        private static void WriteXml(
            ZipArchive archive,
            string entryName,
            Action<XmlWriter> writeBody)
        {
            ZipArchiveEntry entry = archive.CreateEntry(entryName, CompressionLevel.Optimal);
            using (Stream stream = entry.Open())
            using (XmlWriter writer = XmlWriter.Create(stream, new XmlWriterSettings
            {
                Encoding = new UTF8Encoding(false),
                Indent = false,
                OmitXmlDeclaration = false,
                CloseOutput = false
            }))
            {
                writer.WriteStartDocument();
                writeBody(writer);
                writer.WriteEndDocument();
            }
        }

        private static string SafeText(string value)
        {
            return value ?? String.Empty;
        }
    }
}
