from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "assets" / "escriptorium-studio.ico"
FONT_CANDIDATES = [
    Path(r"C:\Windows\Fonts\arialbd.ttf"),
    Path(r"C:\Windows\Fonts\seguisb.ttf"),
]


def rounded_rectangle(draw, box, radius, fill):
    draw.rounded_rectangle(box, radius=radius, fill=fill)


def make_master():
    size = 1024
    image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)

    rounded_rectangle(draw, (34, 34, 990, 990), 188, (14, 36, 48, 255))
    draw.rounded_rectangle(
        (55, 55, 969, 969),
        radius=169,
        outline=(193, 148, 64, 255),
        width=13,
    )

    # A single parchment leaf, with a folded corner.
    page = [(210, 152), (734, 152), (842, 260), (842, 872), (210, 872)]
    draw.polygon(page, fill=(255, 249, 232, 255))
    draw.polygon([(734, 152), (734, 260), (842, 260)], fill=(225, 205, 157, 255))
    draw.line(page + [page[0]], fill=(193, 148, 64, 255), width=10, joint="curve")

    font_path = next((path for path in FONT_CANDIDATES if path.exists()), None)
    if font_path:
        font = ImageFont.truetype(str(font_path), 470)
    else:
        font = ImageFont.load_default()
    letter = "E"
    bbox = draw.textbbox((0, 0), letter, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    draw.text(
        ((210 + 842 - text_width) / 2, 235 - bbox[1]),
        letter,
        font=font,
        fill=(167, 58, 42, 255),
    )

    for y, width in [(678, 410), (760, 330)]:
        draw.rounded_rectangle(
            (276, y, 276 + width, y + 25),
            radius=12,
            fill=(50, 81, 88, 210),
        )
    draw.rounded_rectangle(
        (276, 838, 756, 864),
        radius=13,
        fill=(193, 148, 64, 255),
    )
    return image


def main():
    TARGET.parent.mkdir(parents=True, exist_ok=True)
    master = make_master()
    master.save(
        TARGET,
        format="ICO",
        sizes=[(16, 16), (20, 20), (24, 24), (32, 32), (40, 40), (48, 48), (64, 64), (128, 128), (256, 256)],
    )
    print(TARGET)


if __name__ == "__main__":
    main()
