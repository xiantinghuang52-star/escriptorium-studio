import zipfile
import shutil
from pathlib import Path
from xml.etree import ElementTree as ET


DOWNLOADS = Path.home() / "Downloads"
INPUTS = [
    DOWNLOADS / "bvb1.xml",
    DOWNLOADS / "BVB2.xml",
    DOWNLOADS / "BVB3.xml",
    DOWNLOADS / "BVB4.xml",
]
OUTPUT = (
    Path(__file__).resolve().parents[2]
    / "outputs"
    / "Transkribus-PAGE-BVB1-4-schema.zip"
)
ASCII_IMAGES = (
    Path(__file__).resolve().parents[2] / "outputs" / "Transkribus-BVB-Images"
)
ASCII_ZIP = (
    Path(__file__).resolve().parents[2]
    / "outputs"
    / "Transkribus-PAGE-BVB1-4-ASCII.zip"
)
SOURCE_IMAGES = [
    DOWNLOADS / "Brief von Bartholomaus1.jpeg",
    DOWNLOADS / "Brief von Bartholomaus2.jpeg",
    DOWNLOADS / "Brief von Bartholomaus3.jpeg",
    DOWNLOADS / "Brief von Bartholomaus4.jpeg",
]
ASCII_NAMES = ["BVB1.jpeg", "BVB2.jpeg", "BVB3.jpeg", "BVB4.jpeg"]

PAGE_NS = "http://schema.primaresearch.org/PAGE/gts/pagecontent/2013-07-15"
XSI_NS = "http://www.w3.org/2001/XMLSchema-instance"
SCHEMA_URL = "https://schema.primaresearch.org/PAGE/gts/pagecontent/2013-07-15/pagecontent.xsd"


def main():
    ET.register_namespace("", PAGE_NS)
    ET.register_namespace("xsi", XSI_NS)

    with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for source in INPUTS:
            tree = ET.parse(source)
            root = tree.getroot()
            root.set(f"{{{XSI_NS}}}schemaLocation", f"{PAGE_NS} {SCHEMA_URL}")
            xml = ET.tostring(root, encoding="utf-8", xml_declaration=True)
            archive_name = "BVB1.xml" if source.name.lower() == "bvb1.xml" else source.name
            archive.writestr(archive_name, xml)

        archive.writestr(
            "IMPORT-README.txt",
            (
                "Images must already be uploaded to the same eScriptorium document.\n"
                "The PAGE XML imageFilename values must match the image names in eScriptorium exactly.\n"
                "Current expected names:\n"
                "Brief von Bartholomaus1.jpeg\n"
                "Brief von Bartholomaus2.jpeg\n"
                "Brief von Bartholomaus3.jpeg\n"
                "Brief von Bartholomaus4.jpeg\n"
            ),
        )

    ASCII_IMAGES.mkdir(parents=True, exist_ok=True)
    for source, target_name in zip(SOURCE_IMAGES, ASCII_NAMES):
        shutil.copy2(source, ASCII_IMAGES / target_name)

    with zipfile.ZipFile(ASCII_ZIP, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for source, target_name in zip(INPUTS, ASCII_NAMES):
            tree = ET.parse(source)
            root = tree.getroot()
            root.set(f"{{{XSI_NS}}}schemaLocation", f"{PAGE_NS} {SCHEMA_URL}")
            page = root.find(f".//{{{PAGE_NS}}}Page")
            if page is not None:
                page.set("imageFilename", target_name)
            xml = ET.tostring(root, encoding="utf-8", xml_declaration=True)
            archive.writestr(Path(target_name).stem + ".xml", xml)
        archive.writestr(
            "IMPORT-README.txt",
            (
                "Upload BVB1.jpeg through BVB4.jpeg to the same eScriptorium document.\n"
                "Then upload this XML ZIP under Images > Import > Transcriptions (XML).\n"
            ),
        )

    print(OUTPUT)


if __name__ == "__main__":
    main()
